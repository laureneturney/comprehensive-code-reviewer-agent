"""
Storage backend service for file upload operations.

This module provides a service class for handling file uploads to custom
storage backends (e.g., Azure Blob Storage) and managing associated metadata.
"""

import base64
import time
from collections.abc import Sequence
from typing import Any, Final, cast

from litellm._logging import verbose_proxy_logger
from litellm._uuid import uuid as uuid_module
from litellm.llms.base_llm.files.storage_backend import BaseFileStorageBackend
from litellm.llms.base_llm.files.storage_backend_factory import get_storage_backend
from litellm.llms.base_llm.files.transformation import BaseFileEndpoints
from litellm.proxy._types import ProxyException, UserAPIKeyAuth
from litellm.proxy.utils import PrismaClient, ProxyLogging
from litellm.types.llms.openai import OpenAIFileObject, OpenAIFilesPurpose
from litellm.types.utils import ExtractedFileData, SpecialEnums


class StorageBackendFileService:
    """
    Service for handling file uploads to storage backends.

    This service encapsulates the logic for:
    - Uploading files to storage backends
    - Creating file objects with storage metadata
    - Generating unified file IDs for managed files
    - Storing files in the managed files system
    """

    @staticmethod
    async def upload_file_to_storage_backend(
        file_data: ExtractedFileData,
        target_storage: str,
        target_model_names: Sequence[str],
        purpose: OpenAIFilesPurpose,
        proxy_logging_obj: ProxyLogging,
        user_api_key_dict: UserAPIKeyAuth,
        prisma_client: PrismaClient | None = None,
    ) -> OpenAIFileObject:
        """
        Upload a file to a storage backend and create a file object.

        Args:
            file_data: File data dictionary from extract_file_data()
            target_storage: Storage backend name (e.g., "azure_storage", "litellm_db")
            target_model_names: List of model names for managed files
            purpose: File purpose (e.g., "user_data", "batch")
            proxy_logging_obj: Proxy logging object for accessing hooks
            user_api_key_dict: User API key authentication data
            prisma_client: The proxy's database client, required by the "litellm_db" backend

        Returns:
            OpenAIFileObject: Created file object with storage metadata

        Raises:
            ProxyException: If storage backend is invalid or upload fails
        """
        # Get storage backend instance
        try:
            storage_backend: Final = get_storage_backend(target_storage, prisma_client=prisma_client)
        except ValueError as e:
            raise ProxyException(
                message=str(e),
                type="invalid_request_error",
                param="target_storage",
                code=400,
            )

        if target_model_names:
            managed_files_hook: Final = proxy_logging_obj.get_proxy_hook("managed_files")
            if not isinstance(managed_files_hook, BaseFileEndpoints):
                raise ProxyException(
                    message="Uploading with target_model_names requires a database-connected proxy, and this proxy has no database configured",
                    type="invalid_request_error",
                    param="target_model_names",
                    code=400,
                )

        # Extract file information
        file_content: Final = file_data["content"]
        filename: Final = file_data.get("filename", "file")
        content_type: Final = file_data.get("content_type", "application/octet-stream")

        # Upload to storage backend
        storage_url: Final = await storage_backend.upload_file(
            file_content=file_content,
            filename=filename,
            content_type=content_type,
            path_prefix="",
            file_naming_strategy="uuid",
        )

        verbose_proxy_logger.debug("Storage backend upload complete: backend=%s, url=%s", target_storage, storage_url)

        # Create file object with storage metadata
        file_object: Final = StorageBackendFileService._create_file_object_with_storage_metadata(
            file_content=file_content,
            filename=filename,
            purpose=purpose,
            target_storage=target_storage,
            storage_url=storage_url,
        )

        if not target_model_names:
            return file_object
        try:
            await StorageBackendFileService._store_in_managed_files(
                file_object=file_object,
                file_data=file_data,
                target_model_names=target_model_names,
                target_storage=target_storage,
                storage_url=storage_url,
                proxy_logging_obj=proxy_logging_obj,
                user_api_key_dict=user_api_key_dict,
            )
        except Exception:
            await StorageBackendFileService._discard_orphaned_content(storage_backend, storage_url, target_storage)
            raise
        return file_object

    @staticmethod
    async def _discard_orphaned_content(
        storage_backend: BaseFileStorageBackend, storage_url: str, target_storage: str
    ) -> None:
        try:
            await storage_backend.delete_file(storage_url)
        except Exception as e:  # noqa: BLE001  # the metadata failure is what surfaces; a failed cleanup is only logged
            verbose_proxy_logger.warning(
                "Could not delete orphaned content at %s on %s after its metadata write failed: %s",
                storage_url,
                target_storage,
                e,
            )

    @staticmethod
    def _create_file_object_with_storage_metadata(
        file_content: bytes,
        filename: str,
        purpose: OpenAIFilesPurpose,
        target_storage: str,
        storage_url: str,
    ) -> OpenAIFileObject:
        """
        Create an OpenAIFileObject with storage backend metadata.

        Args:
            file_content: File content bytes
            filename: Original filename
            purpose: File purpose
            target_storage: Storage backend name
            storage_url: URL where file is stored

        Returns:
            OpenAIFileObject: File object with storage metadata in _hidden_params
        """
        file_id: Final = f"file-{uuid_module.uuid4().hex[:24]}"
        file_object: Final = OpenAIFileObject(
            id=file_id,
            object="file",
            purpose=purpose,
            created_at=int(time.time()),
            bytes=len(file_content),
            filename=filename,
            status="uploaded",
        )

        # Store storage metadata in hidden params
        if not hasattr(file_object, "_hidden_params") or file_object._hidden_params is None:
            file_object._hidden_params = {}
        file_object._hidden_params.update(
            {
                "storage_backend": target_storage,
                "storage_url": storage_url,
            }
        )

        return file_object

    @staticmethod
    def _create_unified_file_id(
        file_type: str | None,
        target_model_names: Sequence[str],
        file_id: str,
    ) -> str:
        """
        Create a base64-encoded unified file ID for managed files.

        Args:
            file_type: MIME type of the file
            target_model_names: List of model names
            file_id: Original file ID

        Returns:
            str: Base64-encoded unified file ID
        """
        unified_file_id_str: Final = SpecialEnums.LITELLM_MANAGED_FILE_COMPLETE_STR.value.format(
            file_type,
            str(uuid_module.uuid4()),
            ",".join(target_model_names),
            file_id,
            None,
        )

        base64_unified_file_id: Final = base64.urlsafe_b64encode(unified_file_id_str.encode()).decode().rstrip("=")

        return base64_unified_file_id

    @staticmethod
    async def _store_in_managed_files(
        file_object: OpenAIFileObject,
        file_data: ExtractedFileData,
        target_model_names: Sequence[str],
        target_storage: str,
        storage_url: str,
        proxy_logging_obj: ProxyLogging,
        user_api_key_dict: UserAPIKeyAuth,
    ) -> None:
        """
        Store file in managed files system with unified file ID.

        Args:
            file_object: File object to store
            file_data: File data dictionary
            target_model_names: List of model names
            target_storage: Storage backend name
            storage_url: URL where file is stored
            proxy_logging_obj: Proxy logging object
            user_api_key_dict: User API key authentication data
        """
        managed_files_obj = proxy_logging_obj.get_proxy_hook("managed_files")
        if not managed_files_obj or not isinstance(managed_files_obj, BaseFileEndpoints):
            verbose_proxy_logger.warning("Managed files hook not available, skipping managed files storage")
            return
        managed_files_obj = cast(Any, managed_files_obj)

        # Create model mappings using storage URL
        model_mappings: Final = {model_name: storage_url for model_name in target_model_names}

        # Create unified file ID
        file_type: Final = file_data.get("content_type", "application/octet-stream")
        base64_unified_file_id: Final = StorageBackendFileService._create_unified_file_id(
            file_type=file_type,
            target_model_names=target_model_names,
            file_id=file_object.id,
        )

        # Update file object ID to unified ID
        file_object.id = base64_unified_file_id

        verbose_proxy_logger.debug(
            "Storing file in managed files: unified_id=%s, storage_backend=%s, storage_url=%s",
            base64_unified_file_id,
            target_storage,
            storage_url,
        )

        # Store in managed files
        await managed_files_obj.store_unified_file_id(
            file_id=base64_unified_file_id,
            file_object=file_object,
            litellm_parent_otel_span=user_api_key_dict.parent_otel_span,
            model_mappings=model_mappings,
            user_api_key_dict=user_api_key_dict,
        )
