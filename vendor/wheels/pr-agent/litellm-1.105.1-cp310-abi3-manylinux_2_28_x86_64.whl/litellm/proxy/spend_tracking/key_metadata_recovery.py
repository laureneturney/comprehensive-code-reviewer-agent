import asyncio
from collections.abc import Awaitable, Callable, Mapping, Sequence
from collections.abc import Set as AbstractSet
from dataclasses import dataclass
from datetime import datetime, timedelta
from types import MappingProxyType
from typing import Final, Literal, TypeVar

from pydantic import BaseModel, TypeAdapter
from typing_extensions import ReadOnly, TypedDict

from litellm._logging import verbose_proxy_logger
from litellm.caching.in_memory_cache import InMemoryCache
from litellm.constants import (
    CLI_SESSION_KEY_PREFIX,
    SPEND_LOG_KEY_METADATA_CACHE_MAX_ITEMS,
    SPEND_LOG_KEY_METADATA_CACHE_TTL,
    SPEND_LOG_KEY_METADATA_MISS_CACHE_TTL,
    SPEND_LOG_KEY_METADATA_QUERY_TIMEOUT_MS,
    SPEND_LOG_KEY_METADATA_ROWS_PER_PROBE,
)
from litellm.litellm_core_utils.litellm_logging import is_valid_sha256_hash
from litellm.proxy.utils import PrismaClient
from litellm.repositories.chunked_in import find_many_in
from litellm.repositories.user_repository import UserRepository

_T = TypeVar("_T")

_ACTIVE_TOKEN_DIGEST_SQL: Final = """
SELECT encode(sha256(convert_to(token, 'UTF8')), 'hex') AS digest, key_alias, team_id, user_id
FROM "LiteLLM_VerificationToken"
WHERE encode(sha256(convert_to(token, 'UTF8')), 'hex') = ANY($1::text[])
"""

_DELETED_TOKEN_DIGEST_SQL: Final = """
SELECT DISTINCT ON (token)
    encode(sha256(convert_to(token, 'UTF8')), 'hex') AS digest, key_alias, team_id, user_id
FROM "LiteLLM_DeletedVerificationToken"
WHERE encode(sha256(convert_to(token, 'UTF8')), 'hex') = ANY($1::text[])
ORDER BY token, deleted_at DESC
"""


def _named_spend_log_edge_row_sql(
    direction: Literal["ASC", "DESC"], since: Literal["$2::timestamp", "oldest_probe.stopped_at"]
) -> str:
    return f"""
    SELECT "startTime", key_alias, team_id, user_id
    FROM (
        SELECT "startTime",
            NULLIF(metadata->>'user_api_key_alias', '') AS key_alias,
            COALESCE(NULLIF(team_id, ''), NULLIF(metadata->>'user_api_key_team_id', '')) AS team_id,
            COALESCE(NULLIF("user", ''), NULLIF(metadata->>'user_api_key_user_id', '')) AS user_id
        FROM (
            SELECT "startTime", metadata, team_id, "user"
            FROM "LiteLLM_SpendLogs"
            WHERE api_key = keys.digest
              AND "startTime" >= {since}
              AND "startTime" < $3::timestamp
            ORDER BY "startTime" {direction}
            LIMIT {SPEND_LOG_KEY_METADATA_ROWS_PER_PROBE}
        ) edge
    ) named
    WHERE COALESCE(key_alias, user_id, team_id) IS NOT NULL
    ORDER BY "startTime" {direction}
    LIMIT 1
    """


_OLDEST_PROBE_STOPPED_AT_SQL: Final = f"""
    SELECT COALESCE(first_row."startTime", (
        SELECT "startTime"
        FROM "LiteLLM_SpendLogs"
        WHERE api_key = keys.digest
          AND "startTime" >= $2::timestamp
          AND "startTime" < $3::timestamp
        ORDER BY "startTime" ASC
        OFFSET {SPEND_LOG_KEY_METADATA_ROWS_PER_PROBE - 1}
        LIMIT 1
    )) AS stopped_at
"""

_SPEND_LOG_ALIAS_SQL: Final = f"""
SELECT keys.digest,
    first_row.key_alias AS first_alias,
    last_row.key_alias AS last_alias,
    first_row.team_id AS first_team,
    last_row.team_id AS last_team,
    first_row.user_id AS first_owner,
    last_row.user_id AS last_owner
FROM unnest($1::text[]) AS keys(digest)
LEFT JOIN LATERAL ({_named_spend_log_edge_row_sql("ASC", "$2::timestamp")}) first_row ON true
LEFT JOIN LATERAL ({_OLDEST_PROBE_STOPPED_AT_SQL}) oldest_probe ON true
LEFT JOIN LATERAL ({_named_spend_log_edge_row_sql("DESC", "oldest_probe.stopped_at")}) last_row ON true
"""

_DAILY_USER_SPEND_OWNER_SQL: Final = """
SELECT api_key, MIN(user_id) AS first_owner, MAX(user_id) AS last_owner
FROM "LiteLLM_DailyUserSpend"
WHERE api_key = ANY($1::text[]) AND user_id IS NOT NULL AND user_id <> ''
GROUP BY api_key
"""

_SPEND_LOG_STATEMENT_TIMEOUT_SQL: Final = f"SET LOCAL statement_timeout = {SPEND_LOG_KEY_METADATA_QUERY_TIMEOUT_MS}"
_SPEND_LOG_NO_BITMAP_SCAN_SQL: Final = "SET LOCAL enable_bitmapscan = off"
_SPEND_LOG_TRANSACTION_TIMEOUT: Final = timedelta(milliseconds=2 * SPEND_LOG_KEY_METADATA_QUERY_TIMEOUT_MS)

_HASHED_JWT_PREFIX: Final = "hashed-jwt-"
_CLI_SESSION_KEY_PREFIX: Final = f"{CLI_SESSION_KEY_PREFIX}-"


class KeyMetadataDict(TypedDict, total=False):
    key_alias: ReadOnly[str | None]
    team_id: ReadOnly[str | None]
    user_id: ReadOnly[str | None]
    user_email: ReadOnly[str | None]
    key_exists: ReadOnly[bool]


class _TokenDigestRow(BaseModel):
    digest: str
    key_alias: str | None = None
    team_id: str | None = None
    user_id: str | None = None


def _unanimous(first: str | None, last: str | None) -> str | None:
    if first is None:
        return last
    return first if last is None or first == last else None


class _SpendLogDigestRow(BaseModel):
    digest: str
    first_alias: str | None = None
    last_alias: str | None = None
    first_team: str | None = None
    last_team: str | None = None
    first_owner: str | None = None
    last_owner: str | None = None

    def metadata(self) -> KeyMetadataDict:
        return KeyMetadataDict(
            key_alias=_unanimous(self.first_alias, self.last_alias),
            team_id=_unanimous(self.first_team, self.last_team),
            user_id=_unanimous(self.first_owner, self.last_owner),
        )


class _DailyUserSpendOwnerRow(BaseModel):
    api_key: str
    first_owner: str | None = None
    last_owner: str | None = None


_TOKEN_DIGEST_ROWS: Final = TypeAdapter(tuple[_TokenDigestRow, ...])
_SPEND_LOG_DIGEST_ROWS: Final = TypeAdapter(tuple[_SpendLogDigestRow, ...])
_DAILY_USER_SPEND_OWNER_ROWS: Final = TypeAdapter(tuple[_DailyUserSpendOwnerRow, ...])
_CACHED_KEY_METADATA: Final = TypeAdapter(KeyMetadataDict)
_SPEND_LOG_METADATA_CACHE: Final = InMemoryCache(
    max_size_in_memory=SPEND_LOG_KEY_METADATA_CACHE_MAX_ITEMS,
    default_ttl=SPEND_LOG_KEY_METADATA_CACHE_TTL,
)
_SPEND_LOG_QUERY_LOCK: Final = asyncio.Lock()
_EMPTY_KEY_METADATA: Final[Mapping[str, KeyMetadataDict]] = MappingProxyType({})
_EMPTY_KEY_OWNERS: Final[Mapping[str, str]] = MappingProxyType({})


async def _db_or_empty(
    load: Callable[[], Awaitable[_T]],
    warning: str,
    count: int,
) -> _T | None:
    from prisma.errors import PrismaError

    try:
        return await load()
    except PrismaError as e:
        verbose_proxy_logger.warning(warning, count, e)
        return None


async def _rows_within_the_statement_timeout(
    prisma_client: PrismaClient,
    sql: str,
    *params: object,
    planner_settings: tuple[str, ...] = (),
) -> Sequence[Mapping[str, object]]:
    async with prisma_client.db.tx(timeout=_SPEND_LOG_TRANSACTION_TIMEOUT) as transaction:
        await transaction.execute_raw(_SPEND_LOG_STATEMENT_TIMEOUT_SQL)
        for setting in planner_settings:
            await transaction.execute_raw(setting)
        return await transaction.query_raw(sql, *params)


async def _reverse_hash_key_metadata(
    prisma_client: PrismaClient,
    sql: str,
    wanted: AbstractSet[str],
    *,
    warning: str,
) -> Mapping[str, KeyMetadataDict]:
    rows: Final = await _db_or_empty(
        lambda: prisma_client.db.query_raw(sql, sorted(wanted)),
        warning,
        len(wanted),
    )
    if rows is None:
        return _EMPTY_KEY_METADATA
    return MappingProxyType(
        {
            row.digest: KeyMetadataDict(key_alias=row.key_alias, team_id=row.team_id, user_id=row.user_id)
            for row in _TOKEN_DIGEST_ROWS.validate_python(rows)
            if row.digest in wanted
        }
    )


async def recover_key_owner_from_daily_spend(
    prisma_client: PrismaClient,
    keys: AbstractSet[str],
) -> Mapping[str, str]:
    if not keys:
        return _EMPTY_KEY_OWNERS
    rows: Final = await _db_or_empty(
        lambda: _rows_within_the_statement_timeout(prisma_client, _DAILY_USER_SPEND_OWNER_SQL, sorted(keys)),
        "Failed daily-spend key owner recovery for %d keys: %s",
        len(keys),
    )
    if rows is None:
        return _EMPTY_KEY_OWNERS
    return MappingProxyType(
        {
            row.api_key: owner
            for row in _DAILY_USER_SPEND_OWNER_ROWS.validate_python(rows)
            for owner in (_unanimous(row.first_owner, row.last_owner),)
            if row.api_key in keys and owner is not None
        }
    )


@dataclass(frozen=True, slots=True)
class _UserDetails:
    email: str | None
    only_team: str | None


_EMPTY_USER_DETAILS: Final[Mapping[str, _UserDetails]] = MappingProxyType({})


async def _details_for_user_ids(
    prisma_client: PrismaClient,
    user_ids: AbstractSet[str],
) -> Mapping[str, _UserDetails]:
    if not user_ids:
        return _EMPTY_USER_DETAILS
    users: Final = await _db_or_empty(
        lambda: find_many_in(UserRepository(prisma_client).table, "user_id", user_ids),
        "Failed user detail recovery for %d user ids: %s",
        len(user_ids),
    )
    if users is None:
        return _EMPTY_USER_DETAILS
    return MappingProxyType(
        {
            user.user_id: _UserDetails(
                email=getattr(user, "user_email", None) or None,
                only_team=_only_team(getattr(user, "teams", None)),
            )
            for user in users
            if getattr(user, "user_id", None)
        }
    )


def _only_team(teams: object) -> str | None:
    if not isinstance(teams, list) or len(teams) != 1:
        return None
    team: Final = teams[0]
    return team if isinstance(team, str) and team else None


def _is_cli_session_key(api_key: str) -> bool:
    return api_key.startswith(_CLI_SESSION_KEY_PREFIX) and len(api_key) > len(_CLI_SESSION_KEY_PREFIX)


def _meta_with_user_details(
    api_key: str, meta: KeyMetadataDict, details: Mapping[str, _UserDetails]
) -> KeyMetadataDict:
    user_id: Final = meta.get("user_id")
    if not isinstance(user_id, str) or user_id not in details:
        return meta
    user: Final = details[user_id]
    email: Final = meta.get("user_email") or user.email
    team_id: Final = meta.get("team_id") or (user.only_team if _is_cli_session_key(api_key) else None)
    updated: Final[KeyMetadataDict] = {
        **meta,
        **({"user_email": email} if email else {}),
        **({"team_id": team_id} if team_id else {}),
    }
    return updated


def _user_id_needing_details(api_key: str, meta: KeyMetadataDict) -> str | None:
    user_id: Final = meta.get("user_id")
    if not isinstance(user_id, str) or not user_id:
        return None
    if meta.get("user_email") and not (_is_cli_session_key(api_key) and not meta.get("team_id")):
        return None
    return user_id


async def attach_user_details(
    prisma_client: PrismaClient,
    recovered: Mapping[str, KeyMetadataDict],
) -> Mapping[str, KeyMetadataDict]:
    needing_details: Final = frozenset(
        user_id
        for user_id in (_user_id_needing_details(api_key, meta) for api_key, meta in recovered.items())
        if user_id is not None
    )
    details: Final = await _details_for_user_ids(prisma_client, needing_details)
    if not details:
        return recovered
    return MappingProxyType(
        {api_key: _meta_with_user_details(api_key, meta, details) for api_key, meta in recovered.items()}
    )


async def recover_cli_session_key_metadata(
    prisma_client: PrismaClient,
    missing_keys: AbstractSet[str],
) -> Mapping[str, KeyMetadataDict]:
    candidates: Final = MappingProxyType(
        {key: key.removeprefix(_CLI_SESSION_KEY_PREFIX) for key in missing_keys if _is_cli_session_key(key)}
    )
    if not candidates:
        return _EMPTY_KEY_METADATA
    known_users: Final = await _details_for_user_ids(prisma_client, frozenset(candidates.values()))
    return MappingProxyType(
        {
            key: KeyMetadataDict(key_alias=key, user_id=user_id)
            for key, user_id in candidates.items()
            if user_id in known_users
        }
    )


async def recover_double_hashed_key_metadata(
    prisma_client: PrismaClient,
    missing_keys: AbstractSet[str],
) -> Mapping[str, KeyMetadataDict]:
    sha_missing: Final = frozenset(key for key in missing_keys if is_valid_sha256_hash(key))
    if not sha_missing:
        return _EMPTY_KEY_METADATA

    from_active: Final = await _reverse_hash_key_metadata(
        prisma_client,
        _ACTIVE_TOKEN_DIGEST_SQL,
        sha_missing,
        warning="Failed reverse-hash recovery against active keys for %d missing keys: %s",
    )
    still_missing: Final = sha_missing - frozenset(from_active)
    if not still_missing:
        return from_active
    from_deleted: Final = await _reverse_hash_key_metadata(
        prisma_client,
        _DELETED_TOKEN_DIGEST_SQL,
        still_missing,
        warning="Failed reverse-hash recovery against deleted keys for %d missing keys: %s",
    )
    return MappingProxyType({**from_active, **from_deleted})


def _is_spend_log_digest(key: str) -> bool:
    return is_valid_sha256_hash(key.removeprefix(_HASHED_JWT_PREFIX))


def _spend_log_cache_key(digest: str, window: tuple[datetime, datetime]) -> str:
    start, end = window
    return f"spend_log_key_metadata:{digest}:{start.isoformat()}:{end.isoformat()}"


def _cached_spend_log_metadata(
    cache: InMemoryCache,
    digests: AbstractSet[str],
    window: tuple[datetime, datetime],
) -> Mapping[str, KeyMetadataDict]:
    return MappingProxyType(
        {
            digest: _CACHED_KEY_METADATA.validate_python(cached)
            for digest in digests
            for cached in (cache.get_cache(_spend_log_cache_key(digest, window)),)
            if cached is not None
        }
    )


async def _query_spend_log_metadata(
    prisma_client: PrismaClient,
    digests: AbstractSet[str],
    window: tuple[datetime, datetime],
) -> Mapping[str, KeyMetadataDict] | None:
    start, end = window
    rows: Final = await _db_or_empty(
        lambda: _rows_within_the_statement_timeout(
            prisma_client,
            _SPEND_LOG_ALIAS_SQL,
            sorted(digests),
            start,
            end,
            planner_settings=(_SPEND_LOG_NO_BITMAP_SCAN_SQL,),
        ),
        "Failed spend-log alias recovery for %d missing keys: %s",
        len(digests),
    )
    if rows is None:
        return None
    return MappingProxyType(
        {
            row.digest: meta
            for row in _SPEND_LOG_DIGEST_ROWS.validate_python(rows)
            for meta in (row.metadata(),)
            if row.digest in digests and any(meta.values())
        }
    )


def _remember_spend_log_metadata(
    cache: InMemoryCache, digest: str, window: tuple[datetime, datetime], meta: KeyMetadataDict | None
) -> None:
    key: Final = _spend_log_cache_key(digest, window)
    if meta is not None:
        cache.set_cache(key, meta)
        return
    missed_before: Final = f"{key}:missed-before"
    if cache.get_cache(missed_before) is not None:
        cache.set_cache(key, KeyMetadataDict())
        return
    cache.set_cache(key, KeyMetadataDict(), ttl=SPEND_LOG_KEY_METADATA_MISS_CACHE_TTL)
    cache.set_cache(missed_before, True)


async def _spend_log_metadata_one_query_at_a_time(
    prisma_client: PrismaClient,
    cache: InMemoryCache,
    lock: asyncio.Lock,
    digests: AbstractSet[str],
    window: tuple[datetime, datetime],
) -> Mapping[str, KeyMetadataDict]:
    async with lock:
        settled: Final = _cached_spend_log_metadata(cache, digests, window)
        pending: Final = digests - frozenset(settled)
        fresh: Final = (
            await _query_spend_log_metadata(prisma_client, pending, window) if pending else _EMPTY_KEY_METADATA
        )
        found: Final = fresh if fresh is not None else _EMPTY_KEY_METADATA
        for digest in pending:
            _remember_spend_log_metadata(cache, digest, window, found.get(digest))
        return MappingProxyType({**settled, **found})


async def recover_key_metadata_from_spend_logs(
    prisma_client: PrismaClient,
    missing_keys: AbstractSet[str],
    window: tuple[datetime, datetime],
    cache: InMemoryCache = _SPEND_LOG_METADATA_CACHE,
    lock: asyncio.Lock = _SPEND_LOG_QUERY_LOCK,
) -> Mapping[str, KeyMetadataDict]:
    digests: Final = frozenset(key for key in missing_keys if _is_spend_log_digest(key))
    if not digests:
        return _EMPTY_KEY_METADATA
    cached: Final = _cached_spend_log_metadata(cache, digests, window)
    uncached: Final = digests - frozenset(cached)
    settled: Final = (
        await _spend_log_metadata_one_query_at_a_time(prisma_client, cache, lock, uncached, window)
        if uncached
        else _EMPTY_KEY_METADATA
    )
    return MappingProxyType({digest: meta for digest, meta in (*cached.items(), *settled.items()) if meta})


def _row_with_recovered_fields(
    row: Mapping[str, object],
    recovered: Mapping[str, KeyMetadataDict],
    *,
    api_key_field: str,
    alias_field: str,
    team_id_field: str,
    user_email_field: str,
) -> Mapping[str, object]:
    api_key: Final = row.get(api_key_field)
    if not isinstance(api_key, str) or api_key not in recovered:
        return row
    meta: Final = recovered[api_key]
    return MappingProxyType(
        {
            **row,
            alias_field: meta.get("key_alias") or row.get(alias_field),
            team_id_field: meta.get("team_id") or row.get(team_id_field),
            user_email_field: row.get(user_email_field) or meta.get("user_email"),
        }
    )


async def fill_missing_api_key_aliases(
    prisma_client: PrismaClient,
    rows: Sequence[Mapping[str, object]],
    *,
    api_key_field: str = "api_key",
    alias_field: str = "api_key_alias",
    team_id_field: str = "team_id",
    user_email_field: str = "user_email",
) -> tuple[Mapping[str, object], ...]:
    """
    Fill null api_key_alias / team_id / user_email on export rows whose api_key
    was double-hashed.

    Used by CloudZero and Focus, which join DailyUserSpend.api_key to
    VerificationToken.token and otherwise export null aliases for those rows.
    """
    missing_keys: Final = frozenset(
        key
        for row in rows
        for key in (row.get(api_key_field),)
        if isinstance(key, str) and key and row.get(alias_field) in (None, "")
    )
    if not missing_keys:
        return tuple(rows)

    from_session_keys: Final = await recover_cli_session_key_metadata(prisma_client, missing_keys)
    recovered: Final = await attach_user_details(
        prisma_client,
        MappingProxyType(
            {
                **from_session_keys,
                **await recover_double_hashed_key_metadata(prisma_client, missing_keys - frozenset(from_session_keys)),
            }
        ),
    )
    if not recovered:
        return tuple(rows)

    return tuple(
        _row_with_recovered_fields(
            row,
            recovered,
            api_key_field=api_key_field,
            alias_field=alias_field,
            team_id_field=team_id_field,
            user_email_field=user_email_field,
        )
        for row in rows
    )
