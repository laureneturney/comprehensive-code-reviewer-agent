"""Store for the enterprise IdP identity assertion captured at SSO login (EMA).

The ``oauth2_id_jag`` egress arm needs the user's IdP ``id_token`` as its RFC 8693
``subject_token``. A front-door client holds an identity-only ``llm_session_`` bearer, not an
IdP assertion, so the assertion captured at the one SSO login is the only usable subject
source for it. This module owns both sides of that state: the SSO callback persists here
(write-through to the DB so a login on one pod is visible to every pod) and the resolver
seam reads back by ``user_id``. Retention is gated on an ``oauth2_id_jag`` server actually
being registered, so a gateway with no EMA upstream never stores bearer material.

The row is one encrypted payload per user, latest login wins. ``expires_at`` mirrors the
id_token ``exp`` claim and is judged by the reader, never enforced by deletion here: an
expired assertion with a refresh token is still renewable, and the DB row is the source of
truth, the same contract as the per-user OAuth credential store. Reads use a per-process cache with
TTL ``MCP_SSO_ASSERTION_CACHE_TTL_SECONDS``; invalidation also guards against stale in-flight reads.
"""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Final, Protocol

import jwt
from pydantic import BaseModel, ConfigDict, SecretStr, TypeAdapter, ValidationError

from litellm._logging import verbose_proxy_logger
from litellm.caching.in_memory_cache import InMemoryCache
from litellm.constants import MCP_OAUTH2_TOKEN_CACHE_MAX_SIZE, MCP_SSO_ASSERTION_CACHE_TTL_SECONDS

if TYPE_CHECKING:
    from prisma.models import LiteLLM_SSOIdentityAssertion

    from litellm.proxy.utils import PrismaClient

_ASSERTION_DECRYPT_LOG_KEY: Final = "sso_identity_assertion"
_STR_ADAPTER: Final[TypeAdapter[str]] = TypeAdapter(str)
_MAYBE_STR_ADAPTER: Final[TypeAdapter[str | None]] = TypeAdapter(str | None)


class _SSOAssertionTable(Protocol):
    """The ``LiteLLM_SSOIdentityAssertion`` table operations this store calls."""

    async def find_unique(self, *, where: Mapping[str, str]) -> LiteLLM_SSOIdentityAssertion | None: ...

    async def find_many(self) -> Sequence[LiteLLM_SSOIdentityAssertion]: ...

    async def upsert(self, *, where: Mapping[str, str], data: Mapping[str, Mapping[str, str]]) -> object: ...

    async def update(self, *, where: Mapping[str, str], data: Mapping[str, str]) -> object: ...


class _MCPServerTable(Protocol):
    """The ``LiteLLM_MCPServerTable`` lookup the retention gate calls."""

    async def find_first(self, *, where: Mapping[str, str]) -> object | None: ...


def _assertion_table(prisma_client: PrismaClient) -> _SSOAssertionTable:
    """The SSO assertion table, typed so the untyped prisma client surface stops here."""
    return prisma_client.db.litellm_ssoidentityassertion


def _mcp_server_table(prisma_client: PrismaClient) -> _MCPServerTable:
    """The MCP server table, typed so the untyped prisma client surface stops here."""
    return prisma_client.db.litellm_mcpservertable


class SSOIdentityAssertion(BaseModel):
    """The IdP material an EMA exchange needs: ``id_token`` is the RFC 8693 subject token,
    ``expires_at`` bounds its usefulness, and the refresh token renews it without re-login."""

    model_config = ConfigDict(frozen=True)

    id_token: SecretStr
    refresh_token: SecretStr | None = None
    issuer: str | None = None
    expires_at: datetime | None = None


class SSOAssertionCache:
    """Process-local read cache. ``invalidate`` bumps a process-wide epoch so a fetch that started
    before a login cannot repopulate the old assertion after it."""

    def __init__(self, ttl_seconds: int = MCP_SSO_ASSERTION_CACHE_TTL_SECONDS) -> None:
        self._entries = InMemoryCache(
            max_size_in_memory=MCP_OAUTH2_TOKEN_CACHE_MAX_SIZE,
            default_ttl=ttl_seconds,
        )
        self._epoch: int = 0

    def epoch(self) -> int:
        return self._epoch

    def get(self, user_id: str) -> SSOIdentityAssertion | None:
        cached: Final = self._entries.get_cache(  # pyright: ignore[reportUnknownMemberType]  # InMemoryCache is untyped
            user_id
        )
        return cached if isinstance(cached, SSOIdentityAssertion) else None

    def set_if_unchanged(self, user_id: str, assertion: SSOIdentityAssertion, seen_epoch: int) -> None:
        if self._epoch != seen_epoch:
            return
        self._entries.set_cache(  # pyright: ignore[reportUnknownMemberType]  # InMemoryCache is untyped
            user_id, assertion
        )

    def invalidate(self, user_id: str) -> None:
        self._epoch += 1
        self._entries.delete_cache(  # pyright: ignore[reportUnknownMemberType]  # InMemoryCache is untyped
            user_id
        )

    def flush(self) -> None:
        self._entries.flush_cache()  # pyright: ignore[reportUnknownMemberType]  # InMemoryCache is untyped


_ASSERTION_CACHE: Final = SSOAssertionCache()


class _IdTokenClaims(BaseModel):
    exp: float | None = None
    iss: str | None = None


class _StoredAssertionPayload(BaseModel):
    id_token: str
    refresh_token: str | None = None
    issuer: str | None = None
    expires_at: datetime | None = None


def assertion_from_sso_login(id_token: object, refresh_token: object) -> SSOIdentityAssertion | None:
    """The typed carrier built where the raw token response exists; ``None`` when the provider
    sent no id_token or sent one that is not a decodable JWT, since neither is exchangeable
    under EMA. Inputs are ``object`` because they come straight from the provider's untyped
    token response; this is the one boundary that validates them. The token arrived over TLS
    from the IdP's own token endpoint, so claims are read without signature verification,
    matching how the SSO callback already decodes it for identity."""
    raw_id_token: Final = id_token if isinstance(id_token, str) and id_token else None
    if raw_id_token is None:
        return None
    raw_refresh_token: Final = refresh_token if isinstance(refresh_token, str) and refresh_token else None
    try:
        claims: Final = _IdTokenClaims.model_validate(jwt.decode(raw_id_token, options={"verify_signature": False}))
        expires_at: Final = datetime.fromtimestamp(claims.exp, tz=timezone.utc) if claims.exp is not None else None
    except Exception:  # noqa: BLE001  # decode failure = not retainable; never raise into login
        verbose_proxy_logger.warning(
            "SSO id_token could not be decoded or its claims were unusable; not retaining it for EMA egress."
        )
        return None
    return SSOIdentityAssertion(
        id_token=SecretStr(raw_id_token),
        refresh_token=SecretStr(raw_refresh_token) if raw_refresh_token else None,
        issuer=claims.iss,
        expires_at=expires_at,
    )


def assertion_expired(assertion: SSOIdentityAssertion, now: datetime) -> bool:
    """Whether the assertion's ``exp`` has passed at ``now``. An assertion carrying no expiry is
    treated as usable and left for the IdP to reject, since the store records what the id_token
    claimed rather than imposing a lifetime of its own. A naive ``expires_at`` is read as UTC so a
    stored value that lost its offset compares instead of raising.

    Lives beside the model rather than in either reader so the egress guard and the renewal
    trigger judge the same field the same way; passing a ``now`` in the future is how a caller
    asks "is this about to expire" without a second, driftable predicate.
    """
    expires_at: Final = assertion.expires_at
    if expires_at is None:
        return False
    normalized: Final = expires_at if expires_at.tzinfo is not None else expires_at.replace(tzinfo=timezone.utc)
    return normalized <= now


async def ema_assertion_retention_enabled() -> bool:
    """Whether any MCP server uses ``oauth2_id_jag``, evaluated per login so the gateway only
    retains bearer material while an EMA upstream exists to spend it on. Judged against the two
    configuration authorities: the pod-local config declaration and the shared DB row. The
    in-memory registry is deliberately not consulted in either direction; it is a per-process
    snapshot of the DB state that can be stale both ways (a server added on another pod would
    silently drop the write, one removed on another pod would keep retaining bearer material),
    and a gate guarding a shared-DB write must judge against that storage's authority."""
    from litellm.proxy._experimental.mcp_server.mcp_server_manager import (  # noqa: PLC0415  # avoids import cycle
        global_mcp_server_manager,
    )
    from litellm.proxy.proxy_server import prisma_client  # noqa: PLC0415  # runtime global
    from litellm.types.mcp import MCPAuth  # noqa: PLC0415  # runtime global

    config_servers: Final = global_mcp_server_manager.config_mcp_servers.values()
    if any(server.auth_type == MCPAuth.oauth2_id_jag for server in config_servers):
        return True
    if prisma_client is None:
        return False
    row: Final = await _mcp_server_table(prisma_client).find_first(where={"auth_type": MCPAuth.oauth2_id_jag.value})
    return row is not None


async def persist_sso_identity_assertion(
    user_id: str, assertion: SSOIdentityAssertion, cache: SSOAssertionCache = _ASSERTION_CACHE
) -> None:
    from litellm.proxy.common_utils.encrypt_decrypt_utils import encrypt_value_helper  # noqa: PLC0415  # runtime global
    from litellm.proxy.proxy_server import prisma_client  # noqa: PLC0415  # runtime global

    if prisma_client is None:
        return
    payload: Final = {
        "id_token": assertion.id_token.get_secret_value(),
        **({"refresh_token": assertion.refresh_token.get_secret_value()} if assertion.refresh_token else {}),
        **({"issuer": assertion.issuer} if assertion.issuer else {}),
        **({"expires_at": assertion.expires_at.isoformat()} if assertion.expires_at else {}),
    }
    encoded: Final = _STR_ADAPTER.validate_python(encrypt_value_helper(json.dumps(payload)))
    await _assertion_table(prisma_client).upsert(
        where={"user_id": user_id},
        data={
            "create": {"user_id": user_id, "assertion_b64": encoded},
            "update": {"assertion_b64": encoded},
        },
    )
    cache.invalidate(user_id)


async def _read_assertion_from_db(user_id: str) -> SSOIdentityAssertion | None:
    from litellm.proxy.common_utils.encrypt_decrypt_utils import decrypt_value_helper  # noqa: PLC0415  # runtime global
    from litellm.proxy.proxy_server import prisma_client  # noqa: PLC0415  # runtime global

    if prisma_client is None:
        return None
    row: Final = await _assertion_table(prisma_client).find_unique(where={"user_id": user_id})
    if row is None:
        return None
    raw: Final = _MAYBE_STR_ADAPTER.validate_python(
        decrypt_value_helper(row.assertion_b64, _ASSERTION_DECRYPT_LOG_KEY, exception_type="debug")
    )
    if raw is None:
        return None
    try:
        payload: Final = _StoredAssertionPayload.model_validate_json(raw)
    except ValidationError:
        verbose_proxy_logger.warning(
            "Stored SSO identity assertion for user_id=%s could not be parsed; treating as absent.", user_id
        )
        return None
    return SSOIdentityAssertion(
        id_token=SecretStr(payload.id_token),
        refresh_token=SecretStr(payload.refresh_token) if payload.refresh_token else None,
        issuer=payload.issuer,
        expires_at=payload.expires_at,
    )


async def fetch_sso_identity_assertion(
    user_id: str, cache: SSOAssertionCache = _ASSERTION_CACHE
) -> SSOIdentityAssertion | None:
    """The stored assertion for ``user_id``, or ``None`` when absent, undecryptable (salt-key
    rotation), or unparseable. Expiry is not judged here; the reader owns that policy."""
    cached: Final = cache.get(user_id)
    if cached is not None:
        return cached
    seen_epoch: Final = cache.epoch()
    assertion: Final = await _read_assertion_from_db(user_id)
    if assertion is not None:
        cache.set_if_unchanged(user_id, assertion, seen_epoch)
    return assertion


class AssertionStoreUnavailable(Exception):
    """Raised by ``fetch`` when the assertion cannot be read for a transient reason: the DB is
    down, or the IdP behind a renewing store could not be reached.

    Distinct from returning ``None`` for "this user has no captured assertion": an outage must not
    read as a definite absence, which would tell the user to sign in again over a transient failure,
    and it must not escape as an unhandled error on the egress or retry path. The message names the
    real component for the operator log; callers get the reader's generic 503. Mirrors
    ``TokenStoreUnavailable`` on the sibling per-user OAuth store.
    """


class SSOAssertionStore(Protocol):
    """The read seam the ``id_jag`` egress arm depends on, so the arm takes a collaborator
    rather than reaching for a module-level function and a proxy global at call time.

    Returns the user's captured assertion, or ``None`` when they have never signed in. Raises
    ``AssertionStoreUnavailable`` when the backing store is unreachable.
    """

    async def fetch(self, user_id: str) -> SSOIdentityAssertion | None: ...


class DbSSOAssertionStore:
    """The live store: the row the SSO callback wrote, read back by ``user_id``.

    A storage failure is re-raised as ``AssertionStoreUnavailable`` so the resolver can map it to a
    typed fail-closed result; letting the raw driver error escape would surface a DB blip as a 500
    from credential resolution and from the upstream-401 retry.
    """

    def __init__(self, cache: SSOAssertionCache = _ASSERTION_CACHE) -> None:
        self._cache = cache

    async def fetch(self, user_id: str) -> SSOIdentityAssertion | None:
        try:
            return await fetch_sso_identity_assertion(user_id, cache=self._cache)
        except Exception as exc:  # noqa: BLE001  # any driver/storage failure is an outage, not an absence
            raise AssertionStoreUnavailable(str(exc)) from exc

    async def fetch_uncached(self, user_id: str) -> SSOIdentityAssertion | None:
        try:
            return await _read_assertion_from_db(user_id)
        except Exception as exc:  # noqa: BLE001  # any driver/storage failure is an outage, not an absence
            raise AssertionStoreUnavailable(str(exc)) from exc


async def rotate_sso_identity_assertions_master_key(prisma_client: PrismaClient, new_master_key: str) -> None:
    """Re-encrypt every stored assertion under ``new_master_key`` during a salt-key rotation,
    mirroring the sibling per-user credential tables; an unreadable row is skipped so one
    corrupt row does not abort the rotation. Rows are decrypted one at a time inside the loop
    so the whole table's plaintext is never held in memory at once."""
    from prisma.models import LiteLLM_SSOIdentityAssertion as AssertionRow  # noqa: PLC0415  # generated at runtime

    from litellm.proxy.common_utils.encrypt_decrypt_utils import (  # noqa: PLC0415  # runtime global
        decrypt_value_helper,
        encrypt_value_helper,
    )

    async def _rotate_row(row: AssertionRow) -> bool:
        plaintext: Final = _MAYBE_STR_ADAPTER.validate_python(
            decrypt_value_helper(row.assertion_b64, _ASSERTION_DECRYPT_LOG_KEY, exception_type="debug")
        )
        if plaintext is None:
            verbose_proxy_logger.warning(
                "rotate_sso_identity_assertions_master_key: could not decrypt assertion for user_id=%s, skipping",
                row.user_id,
            )
            return False
        re_encrypted: Final = _STR_ADAPTER.validate_python(
            encrypt_value_helper(plaintext, new_encryption_key=new_master_key)
        )
        await _assertion_table(prisma_client).update(
            where={"user_id": row.user_id},
            data={"assertion_b64": re_encrypted},
        )
        return True

    rows: Final = await _assertion_table(prisma_client).find_many()
    outcomes: Final = [await _rotate_row(row) for row in rows]
    verbose_proxy_logger.info(
        "rotate_sso_identity_assertions_master_key: rotated %d row(s), skipped %d",
        sum(outcomes),
        len(outcomes) - sum(outcomes),
    )


async def retain_sso_identity_assertion_for_ema(user_id: str, assertion: SSOIdentityAssertion | None) -> None:
    """The SSO-callback hook: a no-op unless there is material AND an EMA server is registered.
    A store failure is logged and swallowed because the login itself must not fail on an
    egress-side write; the cost of a miss is a 401 challenge at the EMA upstream, not a lockout."""
    if assertion is None:
        return
    try:
        if not await ema_assertion_retention_enabled():
            return
        await persist_sso_identity_assertion(user_id, assertion)
    except Exception as exc:  # noqa: BLE001  # the login itself must not fail on an egress-side write
        verbose_proxy_logger.warning(
            "Failed to persist the SSO identity assertion for EMA egress (user_id=%s): %s", user_id, exc
        )
