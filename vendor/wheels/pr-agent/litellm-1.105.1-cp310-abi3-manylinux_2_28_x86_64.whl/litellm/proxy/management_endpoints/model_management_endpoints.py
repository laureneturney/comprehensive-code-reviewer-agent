"""
Allow proxy admin to add/update/delete models in the db

Currently most endpoints are in `proxy_server.py`, but those should  be moved here over time.

Endpoints here:

model/{model_id}/update - PATCH endpoint for model update.
"""

#### MODEL MANAGEMENT ####

import asyncio
import datetime
import json
from collections.abc import AsyncGenerator, Awaitable, Callable, Mapping, Sequence
from contextlib import AbstractAsyncContextManager, asynccontextmanager, suppress
from dataclasses import dataclass
from fnmatch import fnmatchcase
from json import JSONDecodeError
from types import MappingProxyType
from typing import TYPE_CHECKING, Annotated, Final, Literal, Protocol, TypeAlias, TypeVar, cast, runtime_checkable

from fastapi import APIRouter, Depends, Header, HTTPException, Request, status
from pydantic import BaseModel, ConfigDict, Field, TypeAdapter, ValidationError, field_validator

import litellm
from litellm._logging import verbose_proxy_logger
from litellm._uuid import uuid
from litellm.constants import LITELLM_PROXY_ADMIN_NAME
from litellm.litellm_core_utils.credential_accessor import CredentialAccessor
from litellm.litellm_core_utils.get_model_cost_map import GetModelCostMap
from litellm.litellm_core_utils.ptu_pricing import (
    CUSTOM_PRICING_FIELDS,
    PTU_EMPTIED_PRICING_FIELDS,
    PTU_MODEL_INFO_FIELDS,
    PTU_ZEROED_PRICING_FIELDS,
    PTU_ZEROED_TABLE_FIELDS,
    SEARCH_CONTEXT_SIZES,
    ptu_config_error,
)
from litellm.proxy._types import (
    BlockModelRequest,
    CommonProxyErrors,
    LiteLLM_ProxyModelTable,
    LiteLLM_TeamTable,
    LitellmTableNames,
    LitellmUserRoles,
    ModelInfoDelete,
    PrismaCompatibleUpdateDBModel,
    ProxyErrorTypes,
    ProxyException,
    ReconcileOutcome,
    TeamModelAddRequest,
    TeamModelDeleteRequest,
    UserAPIKeyAuth,
)
from litellm.proxy.auth.litellm_license import AUTO_ROUTER_LICENSE_REMEDY
from litellm.proxy.auth.team_grants import team_model_aliases
from litellm.proxy.auth.user_api_key_auth import user_api_key_auth
from litellm.proxy.common_utils.config_sync_pubsub import (
    coordination_redis_cache,
    publish_config_change,
)
from litellm.proxy.common_utils.encrypt_decrypt_utils import (
    decrypt_value_helper,
    encrypt_value_helper,
)
from litellm.proxy.common_utils.user_api_key_cache import UserApiKeyCache
from litellm.proxy.db.routing_prisma_wrapper import WriterPinnedClient
from litellm.proxy.management.teams.access import TEAM_ADMIN_ONLY, is_team_admin
from litellm.proxy.management.teams.dependencies import get_team_access
from litellm.proxy.management_endpoints.team_endpoints import (
    _refresh_cached_team,
    append_team_models,
    team_model_add,
    team_model_delete,
)
from litellm.proxy.management_endpoints.team_endpoints import (
    update_team as _legacy_update_team,
)
from litellm.proxy.management_helpers.access_group_model_sync import (
    sync_access_groups_for_deleted_model,
    sync_access_groups_for_renamed_model,
)
from litellm.proxy.management_helpers.audit_logs import create_object_audit_log
from litellm.proxy.management_helpers.auto_router_permissions import (
    MemberAutoRouterWrite,
    StoredAutoRouterIdentity,
    authorize_member_auto_router_dependencies,
    authorize_member_auto_router_team,
    authorize_member_auto_router_write,
)
from litellm.proxy.management_helpers.model_allowlist_rename_sync import sync_model_allowlists_for_renamed_model
from litellm.proxy.spend_tracking.ptu_feature_flag import (
    PTU_COST_ATTRIBUTION_ENV_VAR,
    is_ptu_cost_attribution_enabled,
)
from litellm.proxy.utils import PrismaClient, ProxyLogging
from litellm.repositories.credentials_repository import CredentialsRepository
from litellm.repositories.model_repository import ModelRepository
from litellm.repositories.prisma_protocols import TableActions
from litellm.repositories.table_repositories import ModelTableRepository
from litellm.repositories.team_repository import TeamRepository
from litellm.router import Router
from litellm.router_strategy.complexity_router import (
    DEFAULT_CLASSIFIER_CONTEXT_WINDOW_SIZE,
    ClassificationRubric,
    ComplexityRouterConfig,
    ComplexityTier,
    TierDefinition,
    built_in_tier_classification_prompt,
    classification_system_prompt,
    custom_tier_classification_prompt,
    normalize_classification_examples,
    normalize_classification_prompt,
)
from litellm.router_utils.auto_router_model_naming import (
    GATED_AUTO_ROUTER_CAPABILITIES,
    STRATEGY_ROUTER_PARAM_FIELDS,
    capability_limit_violation,
    carries_complexity_router_settings,
    count_capability_routers,
    gated_capability_of,
    is_complexity_router_model,
    validate_complexity_router_config_placement,
    validate_complexity_router_config_write,
    validate_strategy_router_model_write,
)
from litellm.router_utils.auto_router_tuning_baseline import is_mutable_tuned_candidate, tuning_quota_violation
from litellm.types.llms.bedrock import AwsSessionTag
from litellm.types.proxy.management_endpoints.model_management_endpoints import (
    AutoRouterClassifierDefaultPromptResponse,
    UpdateUsefulLinksRequest,
)
from litellm.types.router import (
    SPECIAL_MODEL_INFO_PARAMS,
    Deployment,
    GenericLiteLLMParams,
    ModelInfo,
    updateDeployment,
    updateLiteLLMParams,
)
from litellm.types.utils import (
    COST_MAP_LOOKUP_KEY,
    echoed_cost_map_fields,
    echoed_cost_map_pricing_fields,
    without_server_derived_pricing,
)
from litellm.utils import get_utc_datetime

if TYPE_CHECKING:
    from prisma import models as prisma_models
    from prisma import types as prisma_types

router: Final = APIRouter()
CLEARABLE_LITELLM_PARAMS: Final = frozenset({"cache_control_injection_points", "litellm_credential_name"})
NULL_CLEARABLE_LITELLM_PARAMS: Final = frozenset((*SPECIAL_MODEL_INFO_PARAMS, *CLEARABLE_LITELLM_PARAMS))


async def update_team(*args, **kwargs):
    """
    Backward-compatible shim for tests/legacy call sites that patch this symbol.
    Team model management now uses team_model_add/team_model_delete directly.
    """
    return await _legacy_update_team(*args, **kwargs)


class UpdatePublicModelGroupsRequest(BaseModel):
    """Request model for updating public model groups"""

    model_groups: list[str] = Field(description="List of model group names to make public")

    model_config = ConfigDict(extra="forbid")


class _ProxyModelRow(Protocol):
    @property
    def model_id(self) -> str: ...

    @property
    def model_name(self) -> str: ...

    @property
    def model_info(self) -> object: ...

    def model_dump_json(self, *, exclude_none: bool = False) -> str: ...


class _ProxyModelTable(Protocol):
    def find_unique(self, *, where: Mapping[str, object]) -> Awaitable[BaseModel | None]: ...

    def find_many(self, *, where: Mapping[str, object]) -> Awaitable[Sequence[_ProxyModelRow]]: ...

    def create(self, *, data: Mapping[str, object]) -> Awaitable[_ProxyModelRow]: ...

    def update(
        self, *, where: Mapping[str, object], data: Mapping[str, object]
    ) -> Awaitable[_ProxyModelRow | None]: ...

    def delete(self, *, where: Mapping[str, object]) -> Awaitable[_ProxyModelRow | None]: ...

    def delete_many(self, *, where: Mapping[str, object]) -> Awaitable[int]: ...


class _TxModelTables(Protocol):
    litellm_proxymodeltable: _ProxyModelTable

    async def query_raw(self, query: str, *args: object) -> Sequence[Mapping[str, object]]: ...


@runtime_checkable
class _TransactionFactory(Protocol):
    def __call__(self, *, timeout: datetime.timedelta = ...) -> AbstractAsyncContextManager[_TxModelTables]: ...


class _ModelTransactionClient(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True, from_attributes=True)

    tx: _TransactionFactory


@dataclass(frozen=True, slots=True)
class _TransactionClient:
    db: _TxModelTables


_RowT = TypeVar("_RowT")


class _ExistingModelRow(Protocol):
    @property
    def litellm_params(self) -> Mapping[str, object]: ...

    def model_dump_json(self, *, exclude_none: bool = False) -> str: ...


class _TeamRow(Protocol):
    @property
    def models(self) -> Sequence[str]: ...

    def model_dump(self) -> Mapping[str, object]: ...


class _TeamLookupTable(Protocol):
    def find_unique(self, *, where: Mapping[str, object]) -> Awaitable[_TeamRow | None]: ...


class _TeamTable(_TeamLookupTable, Protocol):
    def update(
        self, *, where: Mapping[str, object], data: Mapping[str, object], include: Mapping[str, bool]
    ) -> Awaitable[LiteLLM_TeamTable]: ...


def _proxy_model_table(prisma_client: PrismaClient) -> _ProxyModelTable:
    return ModelRepository(prisma_client).table


def _repo_team_table(prisma_client: PrismaClient) -> _TeamLookupTable:
    return TeamRepository(WriterPinnedClient(prisma_client.db)).table


def _db_team_table(prisma_client: PrismaClient) -> _TeamTable:
    return prisma_client.db.litellm_teamtable


def _model_alias_table(prisma_client: PrismaClient) -> "TableActions[prisma_models.LiteLLM_ModelTable]":
    return ModelTableRepository(prisma_client).table


async def get_db_model(model_id: str, prisma_client: PrismaClient) -> Deployment | None:
    db_model: Final = await _proxy_model_table(prisma_client).find_unique(where={"model_id": model_id})

    if not db_model:
        return None

    deployment_pydantic_obj: Final = Deployment(**db_model.model_dump(exclude_none=True))
    return deployment_pydantic_obj


def _strategy_router_write_violation(
    incoming_params: GenericLiteLLMParams | None,
    existing_params: GenericLiteLLMParams | None,
) -> str | None:
    """Reject writes that would corrupt a strategy router's pseudo-model.

    An auto-router deployment's ``litellm_params.model`` (``auto_router/...``) is
    the discriminator the router loads it by; a write that mangles it makes the
    router drop the deployment silently under ``ignore_invalid_deployments``.
    A patch adding auto-router settings is judged against the effective model,
    decrypting the stored model when the patch omits it, so a regular deployment
    cannot claim a strategy-router configuration. Unrelated partial patches and
    restores that do not touch strategy-router settings stay legal. A config is
    judged only when the write carries one, for the same reason: a rename must
    not be held hostage by a stored config it does not touch. Returns the
    violation, or None.
    """
    if incoming_params is None:
        return None
    config_violation: Final = validate_complexity_router_config_write(
        complexity_router_config=(
            _effective_complexity_router_config(incoming_params, existing_params)
            if incoming_params.complexity_router_config is not None
            else None
        )
    )
    if config_violation is not None:
        return config_violation
    present_fields: Final = frozenset(
        field
        for field in STRATEGY_ROUTER_PARAM_FIELDS
        for source in (incoming_params, existing_params)
        if source is not None and getattr(source, field, None) is not None
    )
    effective_params: Final = _effective_complexity_router_params(incoming_params, existing_params)
    effective_model: Final = effective_params.get("model")
    if carries_complexity_router_settings(
        effective_model if isinstance(effective_model, str) else None, present_fields
    ):
        placement_violation: Final = validate_complexity_router_config_placement(incoming_params.model_extra)
        if placement_violation is not None:
            return placement_violation
    return validate_strategy_router_model_write(
        model=effective_model if isinstance(effective_model, str) else "",
        present_fields=present_fields,
    )


def _raise_on_strategy_router_write_violation(
    incoming_params: GenericLiteLLMParams | None,
    existing_params: GenericLiteLLMParams | None,
) -> None:
    violation = _strategy_router_write_violation(incoming_params=incoming_params, existing_params=existing_params)
    if violation is None:
        return
    raise ProxyException(
        message=violation,
        type=ProxyErrorTypes.validation_error.value,
        code=status.HTTP_400_BAD_REQUEST,
        param="litellm_params.model",
    )


def _stored_credential_name(existing_litellm_params: GenericLiteLLMParams | None) -> str | None:
    if existing_litellm_params is None or existing_litellm_params.litellm_credential_name is None:
        return None
    return decrypt_value_helper(
        value=existing_litellm_params.litellm_credential_name,
        key="litellm_credential_name",
        exception_type="debug",
        return_original_value=True,
    )


async def _raise_on_invalid_credential_name(
    litellm_params: updateLiteLLMParams | None,
    existing_litellm_params: GenericLiteLLMParams | None,
    prisma_client: PrismaClient,
) -> None:
    if litellm_params is None or "litellm_credential_name" not in litellm_params.model_fields_set:
        return
    credential_name: Final = litellm_params.litellm_credential_name
    if credential_name is None:
        return
    if credential_name == "":
        raise ProxyException(
            message="litellm_credential_name cannot be an empty string. Send null to detach the stored credential or omit the field to leave it unchanged.",
            type=ProxyErrorTypes.validation_error.value,
            code=status.HTTP_400_BAD_REQUEST,
            param="litellm_credential_name",
        )
    if credential_name == _stored_credential_name(existing_litellm_params):
        return
    if CredentialAccessor.find_credential(credential_name) is not None:
        return
    stored_credential: Final = await CredentialsRepository(WriterPinnedClient(prisma_client.db)).find_by_name(
        credential_name
    )
    if stored_credential is not None:
        return
    raise ProxyException(
        message=f"Credential '{credential_name}' not found. Create it via /credentials before attaching it to a model.",
        type=ProxyErrorTypes.validation_error.value,
        code=status.HTTP_400_BAD_REQUEST,
        param="litellm_credential_name",
    )


AUTO_ROUTER_CAPABILITY_SLOT_LOCK_KEY: Final = 5_872_301
_CAPABILITY_LOCK_SQL: Final = "SELECT 1 AS locked FROM pg_advisory_xact_lock($1)"
_STORED_LITELLM_PARAMS_SQL: Final = (
    "(CASE jsonb_typeof(litellm_params) WHEN 'string' THEN (litellm_params #>> '{}')::jsonb ELSE litellm_params END)"
)
_STORED_COMPLEXITY_CONFIG_SQL: Final = f"{_STORED_LITELLM_PARAMS_SQL} -> 'complexity_router_config'"
_CAPABILITY_DB_ROWS_SQL: Final[Mapping[str, str]] = MappingProxyType(
    {
        capability.key: f"""
SELECT {_STORED_LITELLM_PARAMS_SQL} ->> 'model' AS model
FROM "LiteLLM_ProxyModelTable"
WHERE model_id <> $1
  AND ({capability.sql_config_predicate.format(config=_STORED_COMPLEXITY_CONFIG_SQL)})
"""
        for capability in GATED_AUTO_ROUTER_CAPABILITIES
    }
)


def _effective_complexity_router_config(
    incoming_params: GenericLiteLLMParams | None, existing_params: GenericLiteLLMParams | None
) -> object:
    incoming: Final = None if incoming_params is None else incoming_params.complexity_router_config
    existing: Final = None if existing_params is None else existing_params.complexity_router_config
    if incoming is None:
        return existing
    if existing is None or incoming.get("classifier_type") != "jev" or existing.get("classifier_type") != "jev":
        return incoming
    incoming_jev: Final[object] = incoming.get("jev_classifier_config")
    existing_jev: Final[object] = existing.get("jev_classifier_config")
    if not isinstance(incoming_jev, Mapping) or not isinstance(existing_jev, Mapping):
        return incoming
    supplied: Final = TypeAdapter(dict[str, object]).validate_python(incoming_jev)
    stored: Final = TypeAdapter(dict[str, object]).validate_python(existing_jev)
    same_base: Final = "api_base" not in supplied or supplied["api_base"] == stored.get("api_base")
    transport: Final = MappingProxyType(
        {
            key: value
            for key, value in stored.items()
            if key in ("api_key", "api_base") and (key != "api_key" or same_base)
        }
    )
    return {
        **incoming,
        "jev_classifier_config": {
            **transport,
            **supplied,
        },
    }


def _effective_model(
    incoming_params: GenericLiteLLMParams | None, existing_params: GenericLiteLLMParams | None
) -> str | None:
    """The model a write leaves on the row, decrypting an existing value only when the patch omits it."""
    incoming: Final = None if incoming_params is None else incoming_params.model
    if incoming is not None:
        return incoming
    existing: Final = None if existing_params is None else existing_params.model
    if existing is None:
        return None
    decrypted: Final = decrypt_value_helper(
        value=existing,
        key="model",
        exception_type="debug",
        return_original_value=True,
    )
    return decrypted if isinstance(decrypted, str) else None


def _effective_complexity_router_params(
    incoming_params: GenericLiteLLMParams | None, existing_params: GenericLiteLLMParams | None
) -> Mapping[str, object]:
    """The model and complexity config a write leaves, for placement and capability decisions."""
    return MappingProxyType(
        {
            "model": _effective_model(incoming_params, existing_params),
            "complexity_router_config": _effective_complexity_router_config(incoming_params, existing_params),
        }
    )


def _member_auto_router_marker_for_update(
    *,
    incoming_params: updateLiteLLMParams | None,
    existing: Deployment,
    member_write: MemberAutoRouterWrite | None,
) -> bool | None:
    if member_write is not None:
        return True
    if not existing.model_info.member_auto_router:
        return None
    if incoming_params is None:
        return True
    if any(getattr(incoming_params, field, None) is not None for field in STRATEGY_ROUTER_PARAM_FIELDS):
        return False
    if incoming_params.model is not None and incoming_params.model != _effective_model(None, existing.litellm_params):
        return False
    return True


def _decrypted_model(stored_model: object) -> str | None:
    if not isinstance(stored_model, str):
        return None
    decrypted: Final = decrypt_value_helper(
        value=stored_model, key="model", exception_type="debug", return_original_value=True
    )
    return decrypted if isinstance(decrypted, str) else None


def _tuning_candidate(effective_params: Mapping[str, object], model_id: str | None) -> Mapping[str, object]:
    return MappingProxyType(
        {
            "litellm_params": effective_params,
            "model_info": MappingProxyType({"id": model_id, "db_model": True}),
        }
    )


def _raise_on_tuning_quota_violation(
    *,
    candidate: Mapping[str, object],
    others: Sequence[Mapping[str, object]],
    baselines: Mapping[str, str],
    limit: int | None,
) -> None:
    violation: Final = tuning_quota_violation(candidate=candidate, others=others, baselines=baselines, limit=limit)
    if violation is not None:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=f"{violation} {AUTO_ROUTER_LICENSE_REMEDY}")


@asynccontextmanager
async def _auto_router_capability_slot(
    prisma_client: PrismaClient,
    *,
    effective_params: Mapping[str, object],
    model_id: str | None,
    member_write: MemberAutoRouterWrite | None = None,
) -> AsyncGenerator[_ProxyModelTable, None]:
    """Hand out the model table to write through while the row's claim on a licensed capability is settled.

    A write that leaves the row claiming a licensed capability under a limited license runs
    inside one transaction that takes an advisory lock in its own statement before counting
    (a statement's snapshot predates anything it locks), so pods cannot both pass the count:
    the DB rows (any pod, either JSON shape) plus this proxy's config.yaml routers are judged
    against the license limit and the write is refused with a 403 before it happens. The row
    being edited keeps its own slot through ``model_id``. Member writes also recheck their
    authorization under this lock. Team model bookkeeping needs a second connection and
    must wait until the transaction has committed and the lock is released. The transaction
    writes bypass the repository's publish-on-write, so the config change is published once
    after commit, the way delete_team_models does.

    A heuristic-v1 router whose tuning has moved off its recorded baseline is judged the same
    way under the same lock, against the DB rows plus this proxy's config.yaml routers.
    """
    from litellm.proxy.proxy_server import (
        _license_check,  # pyright: ignore[reportPrivateUsage]  # existing capability slot reads the proxy license singleton
        heuristic_v1_tuning_baselines,
        llm_router,
        premium_user,
    )

    limit: Final = _license_check.auto_router_capability_limit()
    capability: Final = gated_capability_of(effective_params)
    baselines: Final = heuristic_v1_tuning_baselines
    tuning_candidate: Final = _tuning_candidate(effective_params, model_id=model_id)
    judges_tuning: Final = baselines is not None and is_mutable_tuned_candidate(tuning_candidate, baselines)
    if member_write is None and (limit is None or (capability is None and not judges_tuning)):
        yield _proxy_model_table(prisma_client)
        return
    transaction_client: Final = _ModelTransactionClient.model_validate(prisma_client.db)
    transaction: Final = (
        transaction_client.tx(timeout=datetime.timedelta(seconds=30))
        if member_write is not None
        else transaction_client.tx()
    )
    async with transaction as tx_ctx:
        tables: Final[_TxModelTables] = tx_ctx
        await tx_ctx.query_raw(_CAPABILITY_LOCK_SQL, AUTO_ROUTER_CAPABILITY_SLOT_LOCK_KEY)
        config_rows: Final = () if llm_router is None else tuple(llm_router.config_deployments())
        if member_write is not None:
            if member_write.model_id is not None:
                await tx_ctx.query_raw(
                    'SELECT model_id FROM "LiteLLM_ProxyModelTable" WHERE model_id = $1 FOR UPDATE',
                    member_write.model_id,
                )
            pinned_client: Final = _TransactionClient(tx_ctx)
            team_where: Final[prisma_types.LiteLLM_TeamTableWhereUniqueInput] = {"team_id": member_write.team_id}
            team_include: Final[prisma_types.LiteLLM_TeamTableInclude] = {"litellm_model_table": True}
            team_row: Final = await TeamRepository(pinned_client).table.find_unique(
                where=team_where, include=team_include
            )
            if team_row is None or llm_router is None:
                raise HTTPException(status_code=403, detail="The auto router's team or model catalog is unavailable.")
            team: Final = LiteLLM_TeamTable.model_validate(team_row.model_dump())
            authorize_member_auto_router_team(
                user_api_key_dict=member_write.actor, team=team, premium_user=premium_user
            )
            if member_write.model_id is not None:
                model_where: Final[prisma_types.LiteLLM_ProxyModelTableWhereInput] = {"model_id": member_write.model_id}
                current_row: Final = await tables.litellm_proxymodeltable.find_unique(where=model_where)
                current_identity: Final = (
                    StoredAutoRouterIdentity.model_validate(current_row.model_dump())
                    if current_row is not None
                    else None
                )
                current_model: Final = (
                    Deployment.model_validate(current_row.model_dump()) if current_row is not None else None
                )
                if (
                    current_identity is None
                    or current_identity.created_by != member_write.actor.user_id
                    or current_model is None
                    or current_model.model_info.team_id != member_write.team_id
                ):
                    raise HTTPException(status_code=403, detail="Team members can update only their own auto routers.")
                if current_identity.updated_at != member_write.updated_at:
                    raise HTTPException(status_code=409, detail="This auto router changed. Reload it before updating.")
            else:
                all_models: Final[prisma_types.LiteLLM_ProxyModelTableWhereInput] = {}
                rows_for_names: Final = await tables.litellm_proxymodeltable.find_many(where=all_models)
                stored_names: Final = tuple(
                    (
                        row.model_name,
                        model_info_as_mapping(row.model_info),
                    )
                    for row in rows_for_names
                )
                config_names: Final = tuple(
                    (str(row.get("model_name", "")), model_info_as_mapping(row.get("model_info")))
                    for row in config_rows
                )
                team_aliases: Final = team_model_aliases(team)
                aliases: Final = (
                    *(llm_router.model_group_alias or ()),
                    *(litellm.model_alias_map or ()),
                    *(team_aliases or ()),
                )
                if member_write.public_name in aliases or any(
                    fnmatchcase(
                        member_write.public_name,
                        str(info.get("team_public_model_name") or name)
                        if info is not None and info.get("team_id") == member_write.team_id
                        else name,
                    )
                    for name, info in (*stored_names, *config_names)
                    if info is None or info.get("team_id") in (None, member_write.team_id)
                ):
                    raise HTTPException(status_code=409, detail="This auto-router name is already used by a model.")
            await authorize_member_auto_router_dependencies(
                config=member_write.config,
                default_model=member_write.default_model,
                user_api_key_dict=member_write.actor,
                team=team,
                prisma_client=pinned_client,
                llm_router=llm_router,
            )
        if capability is not None:
            rows: Sequence[Mapping[str, object]] = await tx_ctx.query_raw(
                _CAPABILITY_DB_ROWS_SQL[capability.key], model_id or ""
            )
            db_held: Final = sum(1 for row in rows if is_complexity_router_model(_decrypted_model(row.get("model"))))
            held: Final = db_held + count_capability_routers(config_rows, capability=capability)
            violation: Final = capability_limit_violation(capability=capability, held=held + 1, limit=limit)
            if violation is not None:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN, detail=f"{violation} {AUTO_ROUTER_LICENSE_REMEDY}"
                )
        if judges_tuning and baselines is not None:
            model_rows: Final = await ModelRepository(_TransactionClient(tx_ctx)).find_all_except(model_id or "")
            _raise_on_tuning_quota_violation(
                candidate=tuning_candidate,
                others=tuple(
                    MappingProxyType(
                        {
                            "litellm_params": row.litellm_params,
                            "model_info": MappingProxyType({"id": row.model_id, "db_model": True}),
                        }
                    )
                    for row in model_rows
                )
                + config_rows,
                baselines=baselines,
                limit=limit,
            )
        yield tables.litellm_proxymodeltable
    await publish_config_change(redis_cache=coordination_redis_cache(), object_type="litellm_proxymodeltable")


ENFORCE_RPM_TPM_ON_MODEL_ADD_SETTING: Final = "enforce_rpm_tpm_on_model_add"


def _raise_if_rate_limits_required_but_missing(*, litellm_params: GenericLiteLLMParams, enforced: bool) -> None:
    """Require both rpm and tpm (each a positive value) when the operator opts in via config.yaml.

    Off by default, so deployments keep adding models without limits. When
    ``enforce_rpm_tpm_on_model_add: true`` is set under general_settings, a model added
    without both rpm and tpm set to a positive value is rejected rather than stored
    unbounded (or effectively excluded from routing by a zero/negative limit).
    """
    if not enforced:
        return
    missing: Final = tuple(
        field
        for field, value in (("rpm", litellm_params.rpm), ("tpm", litellm_params.tpm))
        if value is None or value <= 0
    )
    if not missing:
        return
    raise ProxyException(
        message=(
            f"{' and '.join(missing)} must be set to a positive value when "
            f"'{ENFORCE_RPM_TPM_ON_MODEL_ADD_SETTING}' is enabled in general_settings"
        ),
        type=ProxyErrorTypes.validation_error.value,
        code=status.HTTP_400_BAD_REQUEST,
        param=f"litellm_params.{missing[0]}",
    )


_PTU_PRICED_PAIR: Final = frozenset({"ptu_count", "cost_per_ptu_per_hour"})


def _explicitly_cleared_ptu_fields(model_info: ModelInfo | None) -> frozenset[str]:
    """The PTU fields a patch sends as an explicit null, which update_db_model drops.

    Empty while the feature is off, so disabling pauses PTU rather than letting a client
    that round-trips a model_info blob erase a configuration set up during an earlier opt-in.
    """
    if model_info is None or not is_ptu_cost_attribution_enabled():
        return frozenset()
    return frozenset(
        field
        for field in PTU_MODEL_INFO_FIELDS
        if field in model_info.model_fields_set and getattr(model_info, field) is None
    )


def _merged_ptu_model_info(*, db_model: Deployment, patch_data: updateDeployment) -> Mapping[str, object]:
    """The model_info a patch would store, which is the stored blob updated by the patch.

    A PTU invariant holds over the deployment as it will exist, not over whichever subset
    of fields a caller happened to send.
    """
    stored: Final = db_model.model_info.model_dump(exclude_none=True) if db_model.model_info else _EMPTY_MODEL_INFO
    incoming: Final = (
        patch_data.model_info.model_dump(exclude_none=True) if patch_data.model_info else _EMPTY_MODEL_INFO
    )
    cleared: Final = _explicitly_cleared_ptu_fields(patch_data.model_info)
    return MappingProxyType({k: v for k, v in {**stored, **incoming}.items() if k not in cleared})


def _raise_if_ptu_cost_attribution_disabled(incoming_model_info: Mapping[str, object]) -> None:
    """Reject PTU model_info fields unless the operator opted into PTU cost attribution.

    Takes the incoming request's model_info rather than the merged deployment, so an
    unrelated patch of a model that still stores PTU config from an earlier opt-in is
    left alone. The fields are rejected rather than dropped so a caller never believes
    a flat cost was configured while the rollup that would price it is not running.

    Only a value is rejected. An explicit null reaches the clear loop, which is gated on
    the same flag, so a disabled proxy neither writes PTU config nor erases what an
    earlier opt-in stored. Disabling pauses the feature rather than discarding its setup.
    """
    if is_ptu_cost_attribution_enabled():
        return
    supplied: Final = tuple(field for field in PTU_MODEL_INFO_FIELDS if incoming_model_info.get(field) is not None)
    if not supplied:
        return
    raise HTTPException(
        status_code=400,
        detail=(
            f"PTU cost attribution is disabled, so {', '.join(supplied)} cannot be set. "
            f"Set {PTU_COST_ATTRIBUTION_ENV_VAR}=true to enable it."
        ),
    )


def _validate_ptu_model_info(model_info: Mapping[str, object]) -> None:
    """Enforce the PTU cross-field invariant on the effective model_info.

    The rules live in litellm_core_utils.ptu_pricing so that config.yaml registration
    refuses the same deployments this endpoint does, for the same reason. Per-field bounds
    (positive count, non-negative rate) are enforced by ModelInfo itself.

    Registration additionally requires an operator-declared ``model_info.id``, which this
    endpoint does not: a stored deployment already holds a stable primary key, where a
    config-declared one is otherwise keyed by a hash of its own parameters.
    """
    error: Final = ptu_config_error(model_info)
    if error is not None:
        raise HTTPException(status_code=400, detail=error)


# The mirrored per-token pricing fields plus the remaining rates the public cost map or a
# provider default would otherwise supply (the cache back-fills, the Maps grounding rate). An
# unset field falls back to those sources, so a field left out here is one a PTU deployment
# still bills.
# tiered_pricing is the one mirrored field that is a table of ranges, not a rate, so it is stored
# empty (see _PTU_EMPTIED_PRICING_FIELDS): its tiers outrank the zeros written beside them, so
# dropping it would leave the cost map's tiers billing the traffic the reserved capacity covers.
_PTU_ZEROED_PRICING_FIELDS: Final = PTU_ZEROED_PRICING_FIELDS
_PTU_EMPTIED_PRICING_FIELDS: Final = PTU_EMPTIED_PRICING_FIELDS
_PTU_ZEROED_PRICING: Final[Mapping[str, float | tuple[()]]] = MappingProxyType(
    {
        **dict.fromkeys(_PTU_ZEROED_PRICING_FIELDS, 0.0),
        **dict.fromkeys(_PTU_EMPTIED_PRICING_FIELDS, ()),
    }
)
_NO_PRICING_OVERRIDE: Final[Mapping[str, float | tuple[()]]] = MappingProxyType({})
_EMPTY_MODEL_INFO: Final[Mapping[str, object]] = _NO_PRICING_OVERRIDE
# Rate fields only. CustomPricingLiteLLMParams also carries settings that are not charges
# (an embedding's output_vector_size, the regional uplift multipliers), and zeroing one of
# those would destroy the deployment's configuration rather than stop a charge.
_CUSTOM_PRICING_FIELDS: Final = CUSTOM_PRICING_FIELDS
# search_context_cost_per_query holds its rates in a table keyed by context size, and an absent
# table means the provider's own default rate rather than free (litellm/llms/gemini/cost_calculator
# falls back to $0.035), so it is zeroed in place rather than emptied like tiered_pricing, and
# written on every PTU deployment rather than only where a table is already stored.
_PTU_ZEROED_TABLE_FIELDS: Final = PTU_ZEROED_TABLE_FIELDS
_SEARCH_CONTEXT_SIZES: Final = SEARCH_CONTEXT_SIZES


def _is_nonzero_rate(value: object) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and value != 0


def _is_nonzero_price(value: object) -> bool:
    if isinstance(value, dict):  # an all-zero table is how a rate is expressed as free
        return any(_is_nonzero_rate(rate) for rate in value.values())
    return _is_nonzero_rate(value)


def _is_zero_price(value: object) -> bool:
    if isinstance(value, dict):
        return bool(value) and not _is_nonzero_price(value)
    if isinstance(value, (list, tuple)):
        return not value
    return isinstance(value, (int, float)) and not isinstance(value, bool) and value == 0


def _raise_if_ptu_deployment_is_priced(*, model_info: Mapping[str, object], supplied: Mapping[str, object]) -> None:
    """Refuse a rate the caller supplies for a deployment that bills reserved capacity.

    Separate from the zeroing so the team-model path can run it before it touches the team, whose
    ACL write autocommits: a refusal raised after it would leave the team changed and the
    deployment row never written.
    """
    if not is_ptu_cost_attribution_enabled():
        return
    if model_info.get("ptu_count") is None or model_info.get("cost_per_ptu_per_hour") is None:
        return
    priced: Final = tuple(
        sorted(
            tuple(field for field in _CUSTOM_PRICING_FIELDS if _is_nonzero_price(supplied.get(field)))
            + tuple(field for field in _PTU_EMPTIED_PRICING_FIELDS if supplied.get(field))
        )
    )
    if not priced:
        return
    raise HTTPException(
        status_code=400,
        detail=(
            f"A PTU deployment bills by reserved capacity, so {', '.join(priced)} cannot be charged on "
            "top of it. Send 0 or no value, or remove ptu_count and cost_per_ptu_per_hour to bill per token."
        ),
    )


def _ptu_zeroed_pricing(
    *,
    model_info: Mapping[str, object],
    litellm_params: Mapping[str, object],
    supplied: Mapping[str, object],
) -> Mapping[str, float | tuple[()] | Mapping[str, float]]:
    """The pricing a PTU deployment must carry, empty unless one is being stored.

    Reserved capacity is already billed by the flat cost the rollup writes, so charging the
    traffic it serves bills the same tokens twice. Left unset the rate falls back to the public
    cost map, which makes the double charge the default rather than an opt-in.

    Only a price the caller supplies is refused. A non-zero price already on the row is zeroed
    instead, so a deployment priced through a path this rule does not cover heals on its next
    save rather than rejecting every later edit of a field that has nothing to do with pricing.

    ``supplied`` is the caller's litellm_params alone, because that is the blob a price is
    authored on. model_info's copy is written by the server, both by the mirror in
    ``Deployment.__init__`` and by the cost-map defaults /model/info fills in, so a client that
    round-trips a model_info blob sends back prices it never chose.
    """
    if not is_ptu_cost_attribution_enabled():
        return _NO_PRICING_OVERRIDE
    if model_info.get("ptu_count") is None or model_info.get("cost_per_ptu_per_hour") is None:
        return _NO_PRICING_OVERRIDE
    _raise_if_ptu_deployment_is_priced(model_info=model_info, supplied=supplied)
    stored: Final = frozenset(
        field
        for field in _CUSTOM_PRICING_FIELDS
        if _is_nonzero_price(model_info.get(field)) or _is_nonzero_price(litellm_params.get(field))
    )
    return MappingProxyType(
        {
            **_PTU_ZEROED_PRICING,
            **dict.fromkeys(_PTU_ZEROED_TABLE_FIELDS, dict.fromkeys(_SEARCH_CONTEXT_SIZES, 0.0)),
            **dict.fromkeys(stored - _PTU_ZEROED_TABLE_FIELDS, 0.0),
        }
    )


def _ptu_pricing_delta(
    *,
    stored_model_info: Mapping[str, object],
    model_info: Mapping[str, object],
    litellm_params: Mapping[str, object],
    patch: updateDeployment,
) -> tuple[Mapping[str, float | tuple[()] | Mapping[str, float]], frozenset[str]]:
    """The pricing a patch must write into both blobs, and the pricing it must drop from them.

    A patch that takes the deployment off PTU takes the zeroed pricing with it, since the zeros
    exist only to stop the double charge. Left behind they would serve the deployment for free.
    Reading the stored row rather than the patch alone keeps that release off a deployment that
    never carried PTU config, whose zero price is a rate its operator chose. A zero the patch
    itself carries is released with the rest, because the dashboard echoes the whole stored
    blob on every save, so a supplied zero cannot be told apart from the one this rule wrote.

    The release spans every field the zeroing could have written, not just the mirrored ones, or
    a rate zeroed on the way in (per-second, per-character tiers) would bill nothing forever.
    """
    supplied: Final = patch.litellm_params.model_dump(exclude_none=True) if patch.litellm_params else _EMPTY_MODEL_INFO
    zeroed: Final = _ptu_zeroed_pricing(model_info=model_info, litellm_params=litellm_params, supplied=supplied)
    if zeroed:
        return zeroed, frozenset()
    was_ptu: Final = any(stored_model_info.get(field) is not None for field in _PTU_PRICED_PAIR)
    if not was_ptu or not _explicitly_cleared_ptu_fields(patch.model_info) & _PTU_PRICED_PAIR:
        return _NO_PRICING_OVERRIDE, frozenset()
    return _NO_PRICING_OVERRIDE, frozenset(
        field
        for field in _CUSTOM_PRICING_FIELDS.union(_PTU_ZEROED_PRICING_FIELDS, _PTU_EMPTIED_PRICING_FIELDS)
        if _is_zero_price(model_info.get(field)) or _is_zero_price(litellm_params.get(field))
    )


def _ptu_priced_deployment(model_params: Deployment) -> Deployment:
    """``model_params`` with PTU pricing applied, or itself when it configures no PTU."""
    model_info: Final = model_params.model_info.model_dump(exclude_none=True)
    litellm_params: Final = model_params.litellm_params.model_dump(exclude_none=True)
    override: Final = _ptu_zeroed_pricing(model_info=model_info, litellm_params=litellm_params, supplied=litellm_params)
    if not override:
        return model_params
    # model_copy validates nothing, so the emptied tier table has to arrive as the list the field
    # declares or Pydantic warns on every later dump of it
    stored: Final = MappingProxyType(
        {key: [] if isinstance(value, tuple) else value for key, value in override.items()}
    )
    return model_params.model_copy(
        update=MappingProxyType(
            {
                "litellm_params": model_params.litellm_params.model_copy(update=stored),
                "model_info": model_params.model_info.model_copy(update=stored),
            }
        )
    )


def _cost_map_entry(db_model: Deployment, incoming_model_info: Mapping[str, object]) -> Mapping[str, object]:
    base_model: Final = incoming_model_info.get("base_model")
    lookup: Final = base_model if isinstance(base_model, str) else _decrypted_model(db_model.litellm_params.model)
    if lookup is None:
        return MappingProxyType({})
    with suppress(Exception):
        return MappingProxyType(dict(litellm.get_model_info(model=lookup)))
    return MappingProxyType({})


LoadedCatalog: TypeAlias = Callable[[], Mapping[str, Mapping[str, object]]]


def _loaded_catalog_entry(
    incoming_model_info: Mapping[str, object], loaded_catalog: LoadedCatalog
) -> Mapping[str, object]:
    catalog_key: Final = incoming_model_info.get(COST_MAP_LOOKUP_KEY)
    if not isinstance(catalog_key, str):
        return MappingProxyType({})
    return loaded_catalog().get(catalog_key, MappingProxyType({}))


def update_db_model(
    db_model: Deployment,
    updated_patch: updateDeployment,
    loaded_catalog: LoadedCatalog = GetModelCostMap.loaded_model_cost_map,
) -> PrismaCompatibleUpdateDBModel:
    if updated_patch.model_info is not None:
        _raise_if_ptu_cost_attribution_disabled(updated_patch.model_info.model_dump(exclude_none=True))
    merged_model_name: Final = updated_patch.model_name or db_model.model_name
    merged_litellm_params: Final = db_model.litellm_params.model_dump(exclude_none=True)
    stored_model_info: Final = db_model.model_info.model_dump(exclude_none=True)
    echoed_pricing: Final = echoed_cost_map_pricing_fields(stored_model_info)
    merged_model_info: Final[dict[str, object]] = {
        k: v for k, v in stored_model_info.items() if k not in echoed_pricing
    }

    # update litellm params
    if updated_patch.litellm_params:
        # Encrypt any sensitive values
        encrypted_params: Final = {
            k: (
                _effective_complexity_router_config(updated_patch.litellm_params, db_model.litellm_params)
                if k == "complexity_router_config"
                else encrypt_value_helper(v)
            )
            for k, v in updated_patch.litellm_params.model_dump(exclude_none=True).items()
        }

        merged_litellm_params.update(encrypted_params)

    # update model info
    if updated_patch.model_info:
        incoming_model_info: Final = updated_patch.model_info.model_dump(exclude_none=True)
        echoed_fields: Final = echoed_cost_map_fields(
            incoming_model_info,
            _cost_map_entry(db_model, incoming_model_info),
            _loaded_catalog_entry(incoming_model_info, loaded_catalog),
        )
        merged_model_info.update(
            MappingProxyType(
                dict(
                    (k, v)
                    for k, v in without_server_derived_pricing(incoming_model_info).items()
                    if k not in echoed_fields
                )
            )
        )
        for k in echoed_fields:
            if k in merged_model_info and merged_model_info[k] != incoming_model_info[k]:
                del merged_model_info[k]

    # Honor explicit-null clears LAST, after both merges, so a model_info blob a client
    # passes through cannot silently undo a litellm_params clear via .update().
    #
    # Restricted to SPECIAL_MODEL_INFO_PARAMS (input/output cost per token/character
    # and cache read/write costs) so this path cannot be used to null out privileged
    # model_info fields like team_id or access groups. SPECIAL_MODEL_INFO_PARAMS are
    # mirrored between litellm_params and model_info by Deployment.__init__, so the
    # clear propagates to both blobs.
    if updated_patch.litellm_params:
        for field in updated_patch.litellm_params.model_fields_set:
            if getattr(updated_patch.litellm_params, field) is None and field in NULL_CLEARABLE_LITELLM_PARAMS:
                merged_litellm_params.pop(field, None)
                merged_model_info.pop(field, None)
            elif (
                field
                in (
                    "auto_router_routing_compression",
                    "auto_router_model_compression",
                )
                and getattr(updated_patch.litellm_params, field) is None
            ):
                merged_litellm_params.pop(field, None)
    if updated_patch.model_info:
        for field in updated_patch.model_info.model_fields_set:
            if field in SPECIAL_MODEL_INFO_PARAMS and getattr(updated_patch.model_info, field) is None:
                merged_model_info.pop(field, None)
                merged_litellm_params.pop(field, None)
        for field in _explicitly_cleared_ptu_fields(updated_patch.model_info):
            merged_model_info.pop(field, None)

    _validate_ptu_model_info(merged_model_info)
    ptu_pricing, ptu_released = _ptu_pricing_delta(
        stored_model_info=db_model.model_info.model_dump(exclude_none=True)
        if db_model.model_info
        else _EMPTY_MODEL_INFO,
        model_info=merged_model_info,
        litellm_params=merged_litellm_params,
        patch=updated_patch,
    )
    merged_model_info.update(ptu_pricing)
    merged_litellm_params.update(ptu_pricing)
    for field in ptu_released:
        merged_model_info.pop(field, None)
        merged_litellm_params.pop(field, None)

    # convert to prisma compatible format

    for key, value in merged_model_info.items():
        if isinstance(value, datetime.datetime):
            merged_model_info[key] = value.isoformat()

    prisma_compatible_model_dict: Final = PrismaCompatibleUpdateDBModel(
        model_name=merged_model_name,
        litellm_params=json.dumps(merged_litellm_params),
        model_info=json.dumps(merged_model_info),
    )

    if updated_patch.blocked is not None:
        prisma_compatible_model_dict["blocked"] = updated_patch.blocked

    return prisma_compatible_model_dict


@router.patch(
    "/model/{model_id}/update",
    tags=["model management"],
    dependencies=[Depends(user_api_key_auth)],
)
async def patch_model(
    model_id: str,  # Get model_id from path parameter
    patch_data: updateDeployment,  # Create a specific schema for PATCH operations
    user_api_key_dict: UserAPIKeyAuth = Depends(user_api_key_auth),
):
    """
    PATCH Endpoint for partial model updates.

    Only updates the fields specified in the request while preserving other existing values.
    Follows proper PATCH semantics by only modifying provided fields.

    Args:
        model_id: The ID of the model to update
        patch_data: The fields to update and their new values
        user_api_key_dict: User authentication information

    Returns:
        Updated model information

    Raises:
        ProxyException: For various error conditions including authentication and database errors
    """
    from litellm.proxy.proxy_server import (
        litellm_proxy_admin_name,
        llm_router,
        premium_user,
        prisma_client,
        store_model_in_db,
        user_api_key_cache,
    )

    try:
        if prisma_client is None:
            raise HTTPException(
                status_code=500,
                detail={"error": CommonProxyErrors.db_not_connected_error.value},
            )

        # Verify model exists and is stored in DB
        if not store_model_in_db:
            raise ProxyException(
                message="Model updates only supported for DB-stored models",
                type=ProxyErrorTypes.validation_error.value,
                code=status.HTTP_400_BAD_REQUEST,
                param=None,
            )

        # Fetch existing model
        db_model: Final = await get_db_model(model_id=model_id, prisma_client=prisma_client)

        if db_model is None:
            # Check if model exists in config but not DB
            if llm_router and llm_router.get_deployment(model_id=model_id) is not None:
                raise ProxyException(
                    message="Cannot edit config-based model. Store model in DB via /model/new first.",
                    type=ProxyErrorTypes.validation_error.value,
                    code=status.HTTP_400_BAD_REQUEST,
                    param=None,
                )
            raise ProxyException(
                message=f"Model {model_id} not found on proxy.",
                type=ProxyErrorTypes.not_found_error,
                code=status.HTTP_404_NOT_FOUND,
                param=None,
            )

        write_authorization: Final = await ModelManagementAuthChecks.can_user_make_model_call(
            model_params=db_model,
            user_api_key_dict=user_api_key_dict,
            prisma_client=prisma_client,
            premium_user=premium_user,
            member_operation="update",
            incoming_model_params=patch_data,
        )
        member_write: Final = write_authorization if isinstance(write_authorization, MemberAutoRouterWrite) else None
        member_marker: Final = _member_auto_router_marker_for_update(
            incoming_params=patch_data.litellm_params, existing=db_model, member_write=member_write
        )
        marker_info: Final = (
            ModelInfo(id=db_model.model_info.id)
            if member_write is not None
            else patch_data.model_info or ModelInfo(id=db_model.model_info.id)
        )
        effective_info: Final = (
            marker_info.model_copy(update=MappingProxyType({"member_auto_router": member_marker}))
            if member_marker is not None
            else patch_data.model_info
        )
        effective_patch: Final = (
            patch_data.model_copy(
                update=MappingProxyType(
                    {
                        "model_name": None if member_write is not None else patch_data.model_name,
                        "model_info": effective_info,
                    }
                )
            )
            if member_marker is not None
            else patch_data
        )

        # Pause/resume (`blocked`) is a proxy-admin-only privilege. Team admins
        # passed the auth check above for team-scoped models, but they must not
        # be able to unblock (or block) a model their proxy admin has paused.
        if patch_data.blocked is not None and user_api_key_dict.user_role != LitellmUserRoles.PROXY_ADMIN:
            raise ProxyException(
                message="Only proxy admins can change a model's blocked flag.",
                type=ProxyErrorTypes.auth_error.value,
                code=status.HTTP_403_FORBIDDEN,
                param="blocked",
            )

        ModelManagementAuthChecks.can_user_attach_credential(
            litellm_params=patch_data.litellm_params,
            user_api_key_dict=user_api_key_dict,
            existing_litellm_params=db_model.litellm_params,
            null_detaches=True,
        )
        await _raise_on_invalid_credential_name(patch_data.litellm_params, db_model.litellm_params, prisma_client)

        ModelManagementAuthChecks.can_user_set_aws_session_tags(
            litellm_params=patch_data.litellm_params,
            user_api_key_dict=user_api_key_dict,
            existing_litellm_params=db_model.litellm_params,
        )

        _raise_on_strategy_router_write_violation(
            incoming_params=patch_data.litellm_params,
            existing_params=db_model.litellm_params,
        )

        effective_params: Final = _effective_complexity_router_params(
            patch_data.litellm_params, db_model.litellm_params
        )
        requested_model_name: Final = patch_data.model_name
        stored_model_name: str | None = None

        async def write_row(update_data: PrismaCompatibleUpdateDBModel) -> _ProxyModelRow | None:
            nonlocal stored_model_name
            stored_model_name = update_data.get("model_name")
            update_data["updated_by"] = user_api_key_dict.user_id or litellm_proxy_admin_name
            update_data["updated_at"] = cast(str, get_utc_datetime())
            async with _auto_router_capability_slot(
                prisma_client,
                effective_params=effective_params,
                model_id=model_id,
                member_write=member_write,
            ) as table:
                return await table.update(where={"model_id": model_id}, data=update_data)

        # Handle team model updates with proper alias management
        updated_model: Final = await _update_team_model_in_db(
            db_model=db_model,
            patch_data=effective_patch,
            user_api_key_dict=user_api_key_dict,
            prisma_client=prisma_client,
            write_row=write_row,
        )

        if updated_model is None:
            raise ProxyException(
                message=f"Model {model_id} not found on proxy.",
                type=ProxyErrorTypes.not_found_error,
                code=status.HTTP_404_NOT_FOUND,
                param=None,
            )

        if (
            stored_model_name is not None
            and stored_model_name == requested_model_name
            and stored_model_name != db_model.model_name
        ):
            await sync_access_groups_for_renamed_model(
                prisma_client=prisma_client,
                model_id=model_id,
                old_name=db_model.model_name,
                new_name=stored_model_name,
                llm_router=llm_router,
            )
            await sync_model_allowlists_for_renamed_model(
                prisma_client=prisma_client,
                model_id=model_id,
                old_name=db_model.model_name,
                new_name=stored_model_name,
                llm_router=llm_router,
                user_api_key_cache=user_api_key_cache,
            )

        # Clear cache and reload models (uses config setting or defaults to preserving config models for DB updates)
        live_before_reload: Final = live_model_ids_snapshot()
        reload_outcome: Final = await clear_cache()

        ## CREATE AUDIT LOG ##
        asyncio.create_task(
            create_object_audit_log(
                object_id=model_id,
                action="updated",
                user_api_key_dict=user_api_key_dict,
                table_name=LitellmTableNames.PROXY_MODEL_TABLE_NAME,
                before_value=db_model.model_dump_json(exclude_none=True),
                after_value=updated_model.model_dump_json(exclude_none=True),
                litellm_changed_by=user_api_key_dict.user_id,
                litellm_proxy_admin_name=LITELLM_PROXY_ADMIN_NAME,
            )
        )

        raise_if_reload_degraded_serving(
            before=live_before_reload,
            written_models=[(model_id, getattr(updated_model, "model_info", None))],
            action="update",
            still_desired=reload_outcome.still_desired,
            live_after=reload_outcome.live_after,
        )

        return updated_model

    except Exception as e:
        verbose_proxy_logger.exception("Error in patch_model: %s", e)

        if isinstance(e, (HTTPException, ProxyException)):
            raise e

        raise ProxyException(
            message=f"Error updating model: {e}",
            type=ProxyErrorTypes.internal_server_error,
            code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            param=None,
        )


async def _set_model_blocked_status(
    data: BlockModelRequest,
    user_api_key_dict: UserAPIKeyAuth,
    blocked: bool,
    action: Literal["blocked", "unblocked"],
    litellm_changed_by: str | None,
) -> LiteLLM_ProxyModelTable | None:
    from litellm.proxy.proxy_server import (
        litellm_proxy_admin_name,
        llm_router,
        prisma_client,
        store_model_in_db,
    )

    try:
        if prisma_client is None:
            raise HTTPException(
                status_code=500,
                detail={"error": CommonProxyErrors.db_not_connected_error.value},
            )

        if store_model_in_db is not True:
            raise ProxyException(
                message="Model updates only supported for DB-stored models",
                type=ProxyErrorTypes.validation_error.value,
                code=status.HTTP_400_BAD_REQUEST,
                param=None,
            )

        if user_api_key_dict.user_role != LitellmUserRoles.PROXY_ADMIN:
            raise ProxyException(
                message="Only proxy admins can change a model's blocked flag.",
                type=ProxyErrorTypes.auth_error.value,
                code=status.HTTP_403_FORBIDDEN,
                param="blocked",
            )

        db_model: Final = await get_db_model(
            model_id=data.model_id,
            prisma_client=prisma_client,
        )

        if db_model is None:
            if llm_router and llm_router.get_deployment(model_id=data.model_id) is not None:
                raise ProxyException(
                    message="Cannot edit config-based model. Store model in DB via /model/new first.",
                    type=ProxyErrorTypes.validation_error.value,
                    code=status.HTTP_400_BAD_REQUEST,
                    param=None,
                )
            raise ProxyException(
                message=f"Model {data.model_id} not found on proxy.",
                type=ProxyErrorTypes.not_found_error,
                code=status.HTTP_404_NOT_FOUND,
                param=None,
            )

        updated_model: Final = await ModelRepository(prisma_client).table.update(
            where={"model_id": data.model_id},
            data={
                "blocked": blocked,
                "updated_by": user_api_key_dict.user_id or litellm_proxy_admin_name,
                "updated_at": cast(str, get_utc_datetime()),
            },
        )

        live_before_reload: Final = live_model_ids_snapshot()
        reload_outcome: Final = await clear_cache()

        asyncio.create_task(
            create_object_audit_log(
                object_id=data.model_id,
                action=action,
                user_api_key_dict=user_api_key_dict,
                table_name=LitellmTableNames.PROXY_MODEL_TABLE_NAME,
                before_value=db_model.model_dump_json(exclude_none=True),
                after_value=(
                    updated_model.model_dump_json(exclude_none=True) if isinstance(updated_model, BaseModel) else None
                ),
                litellm_changed_by=litellm_changed_by,
                litellm_proxy_admin_name=litellm_proxy_admin_name,
            )
        )

        raise_if_reload_degraded_serving(
            before=live_before_reload,
            written_models=[(data.model_id, getattr(updated_model, "model_info", None))],
            action=action,
            still_desired=reload_outcome.still_desired,
            live_after=reload_outcome.live_after,
        )

        return updated_model  # pyright: ignore[reportReturnType]  # prisma row, coerced by this route's response_model

    except Exception as e:
        verbose_proxy_logger.exception("Error in model %s: %s", action, e)

        if isinstance(e, (HTTPException, ProxyException)):
            raise e

        raise ProxyException(
            message=f"Error updating model blocked status: {e}",
            type=ProxyErrorTypes.internal_server_error,
            code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            param=None,
        )


@router.post(
    "/model/block",
    tags=["model management"],
    dependencies=[Depends(user_api_key_auth)],
)
async def block_model(
    data: BlockModelRequest,
    http_request: Request,
    user_api_key_dict: UserAPIKeyAuth = Depends(user_api_key_auth),
    litellm_changed_by: str | None = Header(
        None,
        description="The litellm-changed-by header enables tracking of actions performed by authorized users on behalf of other users, providing an audit trail for accountability",
    ),
) -> LiteLLM_ProxyModelTable | None:
    """
    Block a DB-stored model deployment from serving requests.

    Parameters:
    - model_id: str - The model deployment id to block.
    """
    return await _set_model_blocked_status(
        data=data,
        user_api_key_dict=user_api_key_dict,
        blocked=True,
        action="blocked",
        litellm_changed_by=litellm_changed_by,
    )


@router.post(
    "/model/unblock",
    tags=["model management"],
    dependencies=[Depends(user_api_key_auth)],
)
async def unblock_model(
    data: BlockModelRequest,
    http_request: Request,
    user_api_key_dict: UserAPIKeyAuth = Depends(user_api_key_auth),
    litellm_changed_by: str | None = Header(
        None,
        description="The litellm-changed-by header enables tracking of actions performed by authorized users on behalf of other users, providing an audit trail for accountability",
    ),
) -> LiteLLM_ProxyModelTable | None:
    """
    Unblock a DB-stored model deployment so it can serve requests again.

    Parameters:
    - model_id: str - The model deployment id to unblock.
    """
    return await _set_model_blocked_status(
        data=data,
        user_api_key_dict=user_api_key_dict,
        blocked=False,
        action="unblocked",
        litellm_changed_by=litellm_changed_by,
    )


################################# Helper Functions #################################
####################################################################################
####################################################################################
####################################################################################


async def _add_model_to_db(
    model_params: Deployment,
    user_api_key_dict: UserAPIKeyAuth,
    prisma_client: PrismaClient,
    new_encryption_key: str | None = None,
    should_create_model_in_db: bool = True,
    slot: AbstractAsyncContextManager[_ProxyModelTable] | None = None,
) -> "_ProxyModelRow | LiteLLM_ProxyModelTable":
    # encrypt litellm params #
    _litellm_params_dict: Final = model_params.litellm_params.dict(exclude_none=True)
    _original_litellm_model_name: Final = model_params.litellm_params.model
    for k, v in _litellm_params_dict.items():
        encrypted_value = encrypt_value_helper(value=v, new_encryption_key=new_encryption_key)
        model_params.litellm_params[k] = encrypted_value
    _data: Final[dict] = {
        "model_id": model_params.model_info.id,
        "model_name": model_params.model_name,
        "litellm_params": model_params.litellm_params.model_dump_json(exclude_none=True),
        "model_info": model_params.model_info.model_dump_json(exclude_none=True),
        "created_by": user_api_key_dict.user_id or LITELLM_PROXY_ADMIN_NAME,
        "updated_by": user_api_key_dict.user_id or LITELLM_PROXY_ADMIN_NAME,
    }
    if model_params.model_info.id is not None:
        _data["model_id"] = model_params.model_info.id
    _create_data: Final = cast("Mapping[str, object]", _data)  # cast-ok: str-keyed json payload built just above
    if not should_create_model_in_db:
        return LiteLLM_ProxyModelTable(**_data)
    if slot is None:
        return await _proxy_model_table(prisma_client).create(data=_create_data)
    async with slot as table:
        return await table.create(data=_create_data)


async def _add_team_model_to_db(
    model_params: Deployment,
    user_api_key_dict: UserAPIKeyAuth,
    prisma_client: PrismaClient,
    slot: AbstractAsyncContextManager[_ProxyModelTable] | None = None,
) -> "_ProxyModelRow | LiteLLM_ProxyModelTable | None":
    """
    If 'team_id' is provided,

    - generate a unique 'model_name' for the model (e.g. 'model_name_{team_id}_{uuid})
    - store the model in the db with the unique 'model_name'
    - add the public model name to the team's allowed models list
    """
    from litellm.proxy.proxy_server import proxy_logging_obj, user_api_key_cache

    _team_id: Final = model_params.model_info.team_id
    if _team_id is None:
        return None

    # Capture the original public name FIRST, before any mutations
    original_model_name: Final = model_params.model_name

    # Set team_public_model_name in model_info using the captured original_model_name
    # This must happen BEFORE mutating model_params.model_name so _add_model_to_db
    # serializes the correct team_public_model_name (not the internal UUID name)
    if original_model_name:
        model_params.model_info.team_public_model_name = original_model_name

    # Generate and assign unique internal model_name LAST
    # (after team_public_model_name is safely stored)
    unique_model_name: Final = f"model_name_{_team_id}_{uuid.uuid4()}"
    model_params.model_name = unique_model_name

    ## CREATE MODEL IN DB ##
    model_response: Final = await _add_model_to_db(
        model_params=model_params,
        user_api_key_dict=user_api_key_dict,
        prisma_client=prisma_client,
        slot=slot,
    )

    if original_model_name:
        await append_team_models(
            data=TeamModelAddRequest(
                team_id=_team_id,
                models=[original_model_name],
            ),
            prisma_client=prisma_client,
            user_api_key_cache=user_api_key_cache,
            proxy_logging_obj=proxy_logging_obj,
        )

    return model_response


async def _update_team_model_in_db(
    db_model: Deployment,
    patch_data: updateDeployment,
    user_api_key_dict: UserAPIKeyAuth,
    prisma_client: PrismaClient,
    write_row: Callable[[PrismaCompatibleUpdateDBModel], Awaitable[_RowT]],
) -> _RowT:
    """
    Handle team model updates with proper alias management.

    If patch_data contains a team_id:
    - Creates unique internal model_name and team alias
    - Adds model to team object
    - Preserves team_public_model_name for external reference

    The row is written through ``write_row`` before the team's model list is touched, so a
    refused or failed write leaves the team as it was (the create path orders itself the same way).
    """
    # Validate team_id if present in patch_data
    from litellm.proxy.proxy_server import premium_user

    await ModelManagementAuthChecks.allow_team_model_action(
        model_params=patch_data,
        user_api_key_dict=user_api_key_dict,
        prisma_client=prisma_client,
        premium_user=premium_user,
    )

    # Validated before the row write, beside the premium check the create path already runs here.
    #
    # The merged view is what gets stored, so that is what has to satisfy the invariants.
    # Validating the patch alone rejected a partial edit of an already valid deployment:
    # raising the rate on a configured model carries no ptu_effective_from, which the
    # stored row supplies.
    if patch_data.model_info is not None:
        _raise_if_ptu_cost_attribution_disabled(patch_data.model_info.model_dump(exclude_none=True))
        _validate_ptu_model_info(_merged_ptu_model_info(db_model=db_model, patch_data=patch_data))
    _raise_if_ptu_deployment_is_priced(
        model_info=_merged_ptu_model_info(db_model=db_model, patch_data=patch_data),
        supplied=(
            patch_data.litellm_params.model_dump(exclude_none=True) if patch_data.litellm_params else _EMPTY_MODEL_INFO
        ),
    )

    patch_team_id: Final = patch_data.model_info.team_id if patch_data.model_info else None

    # No team_id in patch, proceed with standard update
    if patch_team_id is None:
        return await write_row(update_db_model(db_model=db_model, updated_patch=patch_data))

    # Determine public model name
    public_model_name: Final = _get_public_model_name(
        patch_data=patch_data,
        db_model=db_model,
    )

    # Ensure model_info exists and set team_public_model_name
    if patch_data.model_info is None:
        from litellm.types.router import ModelInfo

        patch_data.model_info = ModelInfo()
    patch_data.model_info.team_public_model_name = public_model_name

    # Check if team assignment is new or changed
    db_team_id: Final = db_model.model_info.team_id if db_model.model_info else None
    is_new_team_assignment: Final = db_team_id != patch_team_id

    # Team rows keep their internal UUID-based model_name; the public name lives in model_info
    patch_data.model_name = f"model_name_{patch_team_id}_{uuid.uuid4()}" if is_new_team_assignment else None
    row: Final = await write_row(update_db_model(db_model=db_model, updated_patch=patch_data))

    if is_new_team_assignment:
        await _setup_new_team_model_assignment(
            team_id=patch_team_id,
            public_model_name=public_model_name,
            user_api_key_dict=user_api_key_dict,
        )
    else:
        await _update_existing_team_model_assignment(
            team_id=patch_team_id,
            public_model_name=public_model_name,
            db_model=db_model,
            user_api_key_dict=user_api_key_dict,
            prisma_client=prisma_client,
        )

    return row


def _get_public_model_name(
    patch_data: updateDeployment,
    db_model: Deployment,
) -> str:
    """Determine the public model name from patch or existing model.

    The top-level ``model_name`` is the rename channel. For team-scoped rows
    the DB ``model_name`` column holds an internal routing key
    (``model_name_{team_id}_{uuid}``), and ``/model/info`` historically leaked
    it into the dashboard edit form, so a non-rename save (e.g. a TPM tweak)
    would PATCH the internal name and the update path would treat it as a
    rename -- overwriting ``team_public_model_name`` and rewriting the team ACL
    (see issue #28382).

    Guard against that by ignoring an incoming ``model_name`` that matches the
    internal shape, or is a no-op against the current DB column. Anything else
    is a genuine rename and wins. We deliberately do NOT read
    ``patch_data.model_info.team_public_model_name``: the dashboard passes the
    existing ``model_info`` blob through untouched on a rename, so honoring it
    would return the OLD public name and silently drop the rename.

    Precedence (highest first):
    1. patch_data.model_name -- a genuine rename: not internal-shape and not a
       no-op against db_model.model_name.
    2. db_model.model_info.team_public_model_name -- existing public name.
    3. db_model.model_name -- last-resort fallback for legacy rows.
    """
    team_id: Final = (patch_data.model_info.team_id if patch_data.model_info else None) or (
        db_model.model_info.team_id if db_model.model_info else None
    )

    def _is_internal_shape(name: str | None) -> bool:
        if team_id is None or not name:
            return False
        return name.startswith(f"model_name_{team_id}_")

    incoming: Final = patch_data.model_name
    if incoming and not _is_internal_shape(incoming) and incoming != db_model.model_name:
        return incoming

    if db_model.model_info and db_model.model_info.team_public_model_name:
        return db_model.model_info.team_public_model_name

    return db_model.model_name


async def _setup_new_team_model_assignment(
    team_id: str,
    public_model_name: str,
    user_api_key_dict: UserAPIKeyAuth,
) -> None:
    """Register a newly team-assigned model's public name on the team."""
    await team_model_add(
        data=TeamModelAddRequest(
            team_id=team_id,
            models=[public_model_name],
        ),
        http_request=Request(scope={"type": "http"}),
        user_api_key_dict=user_api_key_dict,
    )


async def _get_team_deployments(
    team_id: str, prisma_client: PrismaClient, table: _ProxyModelTable | None = None
) -> Sequence[_ProxyModelRow]:
    """
    Fetch all deployments for a given team_id from the database.

    Centralizes team deployment queries to ensure consistent filtering and error handling.
    This is the established helper pattern for team deployment DB access in this module.

    Note: prisma-client-py 0.11.0 does not support JSON path filtering, so we filter
    by the model_name prefix (team models use "model_name_{team_id}_*") and confirm
    team_id in model_info with Python-side filtering.

    Pass ``table`` (a transaction's proxy-model table) to run the read inside an
    existing transaction.
    """
    prefix: Final = f"model_name_{team_id}_"
    table = table or _proxy_model_table(prisma_client)
    response: Final = await table.find_many(
        where={
            "model_name": {"startswith": prefix},
        }
    )
    if not response:
        return []

    # Confirm team_id in model_info (defensive check)
    result: Final = []
    for row in response:
        model_info = model_info_as_mapping(row.model_info)
        if model_info is not None and model_info.get("team_id") == team_id:
            result.append(row)
    return result


async def delete_team_models(
    team_ids: list[str],
    prisma_client: PrismaClient,
    llm_router: Router | None,
) -> list[str]:
    """
    Delete every BYOK model owned by the given teams, from the DB and the router.

    The DB rows are removed inside a single transaction, so deletion is atomic
    across all team_ids. Each team's rows are deleted by the exact model_ids read
    in the same transaction, which keeps the deleted set identical to the set
    handed to the router. The router is synced only after the transaction commits,
    so a rollback can never leave a deployment live in the router without its row.

    Returns the model_ids that were deleted.
    """
    deleted_model_ids: Final[list[str]] = []
    async with prisma_client.db.tx() as tx_ctx:
        tx: Final[_TxModelTables] = tx_ctx
        for team_id in team_ids:
            rows = await _get_team_deployments(team_id, prisma_client, table=tx.litellm_proxymodeltable)
            model_ids = [row.model_id for row in rows]
            if model_ids:
                await tx.litellm_proxymodeltable.delete_many(where={"model_id": {"in": model_ids}})
                deleted_model_ids.extend(model_ids)

    if deleted_model_ids:
        await publish_config_change(redis_cache=coordination_redis_cache(), object_type="litellm_proxymodeltable")

    # Under MODEL_RECONCILE_LOCK, for the same reason as delete_model: the rows are
    # gone, but a reconcile holding a pre-delete snapshot would upsert these ids back
    # onto this pod. The lock orders the eviction after any in-flight reconcile.
    from litellm.proxy.proxy_server import MODEL_RECONCILE_LOCK, proxy_config

    async with MODEL_RECONCILE_LOCK:
        proxy_config.remove_auto_router_catalog_entries(frozenset(deleted_model_ids))
        if llm_router is not None:
            for model_id in deleted_model_ids:
                llm_router.delete_deployment(id=model_id)

    return deleted_model_ids


async def _get_team_public_model_names(
    team_id: str,
    prisma_client: PrismaClient,
) -> set[str]:
    """
    Public model names currently backed by a deployment in the team.

    Called on delete (after the deployment row is removed) so a public name that is
    load-balanced across several deployments stays in team.models while a replica
    still serves it.
    """
    deployments: Final = await _get_team_deployments(team_id, prisma_client)
    public_names: Final[set[str]] = set()
    for row in deployments:
        model_info = model_info_as_mapping(row.model_info)
        if model_info is not None:
            public_name = model_info.get("team_public_model_name")
            if public_name:
                public_names.add(public_name)
    return public_names


async def _remove_unbacked_team_models(
    model_params: Deployment,
    prisma_client: PrismaClient,
    user_api_key_cache: UserApiKeyCache,
    proxy_logging_obj: ProxyLogging,
    llm_router: Router | None = None,
) -> None:
    """
    Strip a deleted team model's public name(s) from team.models and refresh the cache.

    Must be called after the deployment row is deleted: a public name is removed only
    when no remaining team deployment still backs it, so a load-balanced replica isn't
    revoked while siblings serve it, and concurrent deletes can't leave a ghost.

    Legacy team models (created before team_public_model_name existed) store a
    ``{public_name: "model_name_{team_id}_{uuid}"}`` entry in the team's model_aliases,
    so the alias scan runs for every team model; skipping it for internal-shaped names
    left stale aliases that rewrote requests to deployments that no longer exist.
    Aliases are scrubbed only when the deleted deployment's name no longer resolves in
    the router, so deleting one replica of a load-balanced group never breaks aliases
    that still route to the surviving replicas (in any team).

    A public name that still resolves to a live router deployment (e.g. a gateway-level
    model group shared with the team) is kept in team.models, so deleting a per-team
    duplicate does not revoke the team's access to the shared deployment.
    """
    team_id: Final = model_params.model_info.team_id
    if team_id is None:
        return

    deleted_name_still_served: Final = (
        llm_router is not None and model_params.model_name in llm_router.model_name_to_deployment_indices
    )
    removed_model_aliases: Final[list[tuple[str, str]]] = (
        []
        if deleted_name_still_served
        else await delete_team_model_alias(
            public_model_name=model_params.model_name,
            prisma_client=prisma_client,
        )
    )
    removed_alias_names: Final = {alias for alias_team_id, alias in removed_model_aliases if alias_team_id == team_id}
    candidate_names: Final = (
        removed_alias_names | {model_params.model_info.team_public_model_name}
        if model_params.model_info.team_public_model_name is not None
        else removed_alias_names
    )
    if not candidate_names:
        return

    team_backed_names: Final = await _get_team_public_model_names(team_id=team_id, prisma_client=prisma_client)
    router_served_names: Final = (
        frozenset(name for name in candidate_names if name in llm_router.model_name_to_deployment_indices)
        if llm_router is not None
        else frozenset()
    )
    names_to_remove: Final = candidate_names - team_backed_names - router_served_names
    if not names_to_remove:
        return

    existing_team_row: Final = await _db_team_table(prisma_client).find_unique(where={"team_id": team_id})
    if existing_team_row is None:
        return

    updated_team_row: Final[LiteLLM_TeamTable] = await _db_team_table(prisma_client).update(
        where={"team_id": team_id},
        data={"models": [model for model in existing_team_row.models if model not in names_to_remove]},
        include={"object_permission": True},
    )
    await _refresh_cached_team(
        team_row=updated_team_row,
        user_api_key_cache=user_api_key_cache,
        proxy_logging_obj=proxy_logging_obj,
    )


async def _update_existing_team_model_assignment(
    team_id: str,
    public_model_name: str,
    db_model: Deployment,
    user_api_key_dict: UserAPIKeyAuth,
    prisma_client: PrismaClient | None,
) -> None:
    """Update an existing team model if the public name changed.

    Note on DB scan: Prisma's JSON filtering does not support compound AND conditions
    across multiple JSON paths, so we fetch all deployments for the team and filter
    team_public_model_name in Python. For teams with many deployments this scan grows
    linearly; if team deployment counts become large this should be revisited.
    """

    def _get_team_public_model_name(
        model_info: object,
    ) -> str | None:
        parsed: Final = model_info_as_mapping(model_info)
        if parsed is None:
            return None
        value: Final = parsed.get("team_public_model_name")
        return value if isinstance(value, str) else None

    old_public_name: Final = db_model.model_info.team_public_model_name if db_model.model_info else None

    if old_public_name and public_model_name != old_public_name:
        if prisma_client is None:
            verbose_proxy_logger.warning(
                "prisma_client not initialized; skipping public name update entirely to avoid orphaned entries"
            )
            return

        # Query DB for all team deployments to check for sibling deployments
        team_deployments: Final = await _get_team_deployments(team_id, prisma_client)
        other_deployments_with_old_name: Final = [
            d
            for d in team_deployments
            if d.model_name != db_model.model_name and _get_team_public_model_name(d.model_info) == old_public_name
        ]

        # Add new name first, then delete old name to prevent access loss on partial failure
        await team_model_add(
            data=TeamModelAddRequest(
                team_id=team_id,
                models=[public_model_name],
            ),
            http_request=Request(scope={"type": "http"}),
            user_api_key_dict=user_api_key_dict,
        )

        if not other_deployments_with_old_name:
            await team_model_delete(
                data=TeamModelDeleteRequest(
                    team_id=team_id,
                    models=[old_public_name],
                ),
                http_request=Request(scope={"type": "http"}),
                user_api_key_dict=user_api_key_dict,
            )
    elif not old_public_name and public_model_name:
        # First-time assignment of public name on an existing team deployment:
        # ensure the team's models list is updated so team routing can resolve it.
        await team_model_add(
            data=TeamModelAddRequest(
                team_id=team_id,
                models=[public_model_name],
            ),
            http_request=Request(scope={"type": "http"}),
            user_api_key_dict=user_api_key_dict,
        )
    # else: old_public_name == public_model_name (no rename needed)
    # No team_model_add/delete calls required; public name is already registered


def _canonical_session_tags(tags: Sequence[AwsSessionTag]) -> tuple[tuple[str, str], ...]:
    return tuple(sorted((tag["Key"], tag["Value"]) for tag in tags))


class ModelManagementAuthChecks:
    """
    Common auth checks for model management endpoints
    """

    @staticmethod
    def can_user_make_team_model_call(
        team_id: str,
        user_api_key_dict: UserAPIKeyAuth,
        team_obj: LiteLLM_TeamTable | None = None,
        premium_user: bool = False,
    ) -> Literal[True]:
        if premium_user is False:
            raise HTTPException(
                status_code=403,
                detail={"error": CommonProxyErrors.not_premium_user.value},
            )
        if user_api_key_dict.user_role and user_api_key_dict.user_role == LitellmUserRoles.PROXY_ADMIN:
            return True
        elif team_obj is None or not is_team_admin(user_api_key_dict=user_api_key_dict, team_obj=team_obj):
            raise HTTPException(
                status_code=403,
                detail={
                    "error": f"Team ID={team_id} does not match the API key's team ID={user_api_key_dict.team_id}, OR you are not the admin for this team. Check `/user/info` to verify your team admin status."
                },
            )
        return True

    @staticmethod
    def can_user_attach_credential(
        litellm_params: GenericLiteLLMParams | None,
        user_api_key_dict: UserAPIKeyAuth,
        existing_litellm_params: GenericLiteLLMParams | None = None,
        *,
        null_detaches: bool = False,
    ) -> Literal[True]:
        if litellm_params is None:
            return True
        if "litellm_credential_name" not in litellm_params.model_fields_set:
            return True
        if litellm_params.litellm_credential_name is None and not null_detaches:
            return True
        requested_credential_name: Final = litellm_params.litellm_credential_name
        if requested_credential_name == _stored_credential_name(existing_litellm_params):
            return True
        if user_api_key_dict.user_role == LitellmUserRoles.PROXY_ADMIN:
            return True
        action: Final = "detach" if requested_credential_name is None else "attach"
        raise ProxyException(
            message=f"Only a proxy admin can {action} a stored credential (litellm_credential_name) on a model. Your role={user_api_key_dict.user_role}.",
            type=ProxyErrorTypes.auth_error.value,
            code=status.HTTP_403_FORBIDDEN,
            param="litellm_credential_name",
        )

    @staticmethod
    def can_user_set_aws_session_tags(
        litellm_params: GenericLiteLLMParams | None,
        user_api_key_dict: UserAPIKeyAuth,
        existing_litellm_params: GenericLiteLLMParams | None = None,
    ) -> Literal[True]:
        if litellm_params is None or litellm_params.aws_session_tags is None:
            return True
        if user_api_key_dict.user_role == LitellmUserRoles.PROXY_ADMIN:
            return True
        existing_tags: Final = existing_litellm_params.aws_session_tags if existing_litellm_params is not None else None
        if existing_tags is not None and _canonical_session_tags(existing_tags) == _canonical_session_tags(
            litellm_params.aws_session_tags
        ):
            return True
        raise ProxyException(
            message=f"Only a proxy admin can set aws_session_tags on a model. Your role={user_api_key_dict.user_role}.",
            type=ProxyErrorTypes.auth_error.value,
            code=status.HTTP_403_FORBIDDEN,
            param="aws_session_tags",
        )

    @staticmethod
    async def allow_team_model_action(
        model_params: Deployment | updateDeployment,
        user_api_key_dict: UserAPIKeyAuth,
        prisma_client: PrismaClient,
        premium_user: bool,
    ) -> Literal[True]:
        if model_params.model_info is None or model_params.model_info.team_id is None:
            return True
        if model_params.model_info.team_id is not None and premium_user is not True:
            raise HTTPException(
                status_code=403,
                detail={"error": CommonProxyErrors.not_premium_user.value},
            )

        _existing_team_row: Final = await _repo_team_table(prisma_client).find_unique(
            where={"team_id": model_params.model_info.team_id}
        )

        if _existing_team_row is None:
            raise HTTPException(
                status_code=400,
                detail={"error": f"Team id={model_params.model_info.team_id} does not exist in db"},
            )
        existing_team_row: Final = LiteLLM_TeamTable.model_validate(_existing_team_row.model_dump())

        ModelManagementAuthChecks.can_user_make_team_model_call(
            team_id=model_params.model_info.team_id,
            user_api_key_dict=user_api_key_dict,
            team_obj=existing_team_row,
            premium_user=premium_user,
        )
        return True

    @staticmethod
    async def can_user_make_model_call(
        model_params: Deployment,
        user_api_key_dict: UserAPIKeyAuth,
        prisma_client: PrismaClient,
        premium_user: bool,
        allow_missing_team: bool = False,
        member_operation: Literal["create", "update"] | None = None,
        incoming_model_params: updateDeployment | None = None,
    ) -> Literal[True] | MemberAutoRouterWrite:
        if user_api_key_dict.user_role in (
            LitellmUserRoles.PROXY_ADMIN_VIEW_ONLY,
            LitellmUserRoles.INTERNAL_USER_VIEW_ONLY,
        ):
            raise HTTPException(status_code=403, detail="View-only users cannot manage models.")
        ## Check team model auth
        if model_params.model_info.team_id is not None:
            team_obj_row: Final = await _repo_team_table(prisma_client).find_unique(
                where={"team_id": model_params.model_info.team_id}
            )
            if team_obj_row is None:
                # The team was deleted. Callers that opt in (e.g. model deletion) may
                # act on the orphaned model, but only as a proxy admin -- without the
                # team there is no team-admin membership left to verify.
                if allow_missing_team:
                    if user_api_key_dict.user_role == LitellmUserRoles.PROXY_ADMIN:
                        return True
                    raise HTTPException(
                        status_code=403,
                        detail={"error": "Only a proxy admin can delete a model whose team has been deleted."},
                    )
                raise HTTPException(
                    status_code=400,
                    detail={"error": f"Team id={model_params.model_info.team_id} does not exist in db"},
                )
            team_obj: Final = LiteLLM_TeamTable.model_validate(team_obj_row.model_dump())

            caller_is_admin: Final = await get_team_access().allows(user_api_key_dict, team_obj, TEAM_ADMIN_ONLY)
            if member_operation is not None and not caller_is_admin:
                from litellm.proxy.proxy_server import llm_router

                if llm_router is None or (member_operation == "update" and incoming_model_params is None):
                    raise HTTPException(
                        status_code=400, detail="An auto-router configuration and model catalog are required."
                    )
                return await authorize_member_auto_router_write(
                    incoming=incoming_model_params if incoming_model_params is not None else model_params,
                    existing=model_params if member_operation == "update" else None,
                    user_api_key_dict=user_api_key_dict,
                    team=team_obj,
                    premium_user=premium_user,
                    prisma_client=prisma_client,
                    llm_router=llm_router,
                )

            return ModelManagementAuthChecks.can_user_make_team_model_call(
                team_id=model_params.model_info.team_id,
                user_api_key_dict=user_api_key_dict,
                team_obj=team_obj,
                premium_user=premium_user,
            )
        ## Check non-team model auth
        elif user_api_key_dict.user_role != LitellmUserRoles.PROXY_ADMIN:
            raise HTTPException(
                status_code=403,
                detail={
                    "error": f"User does not have permission to make this model call. Your role={user_api_key_dict.user_role}. You can only make model calls if you are a PROXY_ADMIN or if you are a team admin, by specifying a team_id in the model_info."
                },
            )
        else:
            return True

        return True


#### [BETA] - This is a beta endpoint, format might change based on user feedback. - https://github.com/BerriAI/litellm/issues/964
@router.post(
    "/model/delete",
    description="Allows deleting models in the model list in the config.yaml",
    tags=["model management"],
    dependencies=[Depends(user_api_key_auth)],
)
async def delete_model(
    model_info: ModelInfoDelete,
    user_api_key_dict: UserAPIKeyAuth = Depends(user_api_key_auth),
):
    from litellm.proxy.proxy_server import llm_router

    try:
        """
        [BETA] - This is a beta endpoint, format might change based on user feedback. - https://github.com/BerriAI/litellm/issues/964

        - Check if id in db
        - Delete
        """

        from litellm.proxy.proxy_server import (
            MODEL_RECONCILE_LOCK,
            llm_router,
            premium_user,
            prisma_client,
            proxy_config,
            proxy_logging_obj,
            store_model_in_db,
            user_api_key_cache,
        )

        if prisma_client is None:
            raise HTTPException(
                status_code=500,
                detail={
                    "error": "No DB Connected. Here's how to do it - https://docs.litellm.ai/docs/proxy/virtual_keys"
                },
            )

        model_in_db: Final = await _proxy_model_table(prisma_client).find_unique(where={"model_id": model_info.id})
        if model_in_db is None:
            raise HTTPException(
                status_code=400,
                detail={"error": f"Model with id={model_info.id} not found in db"},
            )

        model_params: Final = Deployment(**model_in_db.model_dump())
        await ModelManagementAuthChecks.can_user_make_model_call(
            model_params=model_params,
            user_api_key_dict=user_api_key_dict,
            prisma_client=prisma_client,
            premium_user=premium_user,
            allow_missing_team=True,
        )

        # update DB
        if store_model_in_db is True:
            """
            - store model_list in db
            - store keys separately
            """
            # encrypt litellm params #
            result: Final = await _proxy_model_table(prisma_client).delete(where={"model_id": model_info.id})

            if result is None:
                raise HTTPException(
                    status_code=400,
                    detail={"error": f"Model with id={model_info.id} not found in db"},
                )

            ## DELETE FROM ROUTER ##
            # Under MODEL_RECONCILE_LOCK. The db row is already gone, but a reconcile
            # that snapshotted the db BEFORE that delete still lists this id as desired,
            # and its _add_deployment upserts the deployment straight back -- leaving
            # this pod serving a model the database no longer has, until the next
            # reconcile. Taking the lock orders this eviction after any such in-flight
            # reconcile's re-add, so the eviction is the last word.
            async with MODEL_RECONCILE_LOCK:
                proxy_config.remove_auto_router_catalog_entries(frozenset({model_info.id}))
                if llm_router is not None:
                    llm_router.delete_deployment(id=model_info.id)

            # Runs after the row delete so the sibling check sees post-delete state.
            if model_params.model_info.team_id is not None:
                await _remove_unbacked_team_models(
                    model_params=model_params,
                    prisma_client=prisma_client,
                    user_api_key_cache=user_api_key_cache,
                    proxy_logging_obj=proxy_logging_obj,
                    llm_router=llm_router,
                )
            await sync_access_groups_for_deleted_model(
                prisma_client=prisma_client,
                model_id=model_info.id,
                model_name=model_params.model_name,
                llm_router=llm_router,
            )

            ## CREATE AUDIT LOG ##
            asyncio.create_task(
                create_object_audit_log(
                    object_id=model_info.id,
                    action="deleted",
                    user_api_key_dict=user_api_key_dict,
                    table_name=LitellmTableNames.PROXY_MODEL_TABLE_NAME,
                    before_value=result.model_dump_json(exclude_none=True),
                    after_value=None,
                    litellm_changed_by=user_api_key_dict.user_id,
                    litellm_proxy_admin_name=LITELLM_PROXY_ADMIN_NAME,
                )
            )
            return {"message": f"Model: {result.model_id} deleted successfully"}
        else:
            raise HTTPException(
                status_code=500,
                detail={"error": "Set `'STORE_MODEL_IN_DB='True'` in your env to enable this feature."},
            )

    except Exception as e:
        verbose_proxy_logger.exception("Failed to delete model. Due to error - %s", e)
        if isinstance(e, HTTPException):
            raise ProxyException(
                message=getattr(e, "detail", f"Authentication Error({e})"),
                type=ProxyErrorTypes.auth_error,
                param=getattr(e, "param", "None"),
                code=getattr(e, "status_code", status.HTTP_400_BAD_REQUEST),
            )
        elif isinstance(e, ProxyException):
            raise e
        raise ProxyException(
            message="Authentication Error, " + str(e),
            type=ProxyErrorTypes.auth_error,
            param=getattr(e, "param", "None"),
            code=status.HTTP_400_BAD_REQUEST,
        )


async def delete_team_model_alias(
    public_model_name: str,
    prisma_client: PrismaClient,
) -> list[tuple[str, str]]:
    """
    Delete a team model alias

    Iterate through all team model aliases and delete the one that matches the model_id

    Returns:
    - List of team id + model alias pairs that were removed
    """
    team_model_aliases: Final = await _model_alias_table(prisma_client).find_many(include={"team": True})
    tasks: Final = []
    removed_model_aliases: Final[list[tuple[str, str]]] = []
    for team_model_alias in team_model_aliases:
        model_aliases = cast(  # cast-ok: prisma types Json columns as `str`; the driver hands back the parsed dict
            "dict[str, str]", team_model_alias.model_aliases
        )
        id = team_model_alias.id

        if public_model_name in model_aliases.values():
            key = list(model_aliases.keys())[list(model_aliases.values()).index(public_model_name)]
            if team_model_alias.team is not None:
                removed_model_aliases.append((team_model_alias.team.team_id, key))
            del model_aliases[key]
            tasks.append(
                _model_alias_table(prisma_client).update(
                    where={"id": id},
                    data={"model_aliases": json.dumps(model_aliases)},
                )
            )
    await asyncio.gather(*tasks)

    return removed_model_aliases


#### [BETA] - This is a beta endpoint, format might change based on user feedback. - https://github.com/BerriAI/litellm/issues/964
@router.post(
    "/model/new",
    description="Allows adding new models to the model list in the config.yaml",
    tags=["model management"],
    dependencies=[Depends(user_api_key_auth)],
)
async def add_new_model(
    model_params: Deployment,
    user_api_key_dict: UserAPIKeyAuth = Depends(user_api_key_auth),
):
    """
    Add a new model to the proxy.

    Parameters:
    - model_name: str - The name users will use to call this model (required)
    - litellm_params: dict - LiteLLM-specific parameters (required)
        - model: str - The actual model identifier, e.g., "azure/my-deployment-name" (required - this is the only required field in litellm_params)
        - api_key: str - API key for the provider (optional)
        - api_base: str - API base URL (optional)
        - Other optional params: api_version, timeout, max_retries, etc.
    - model_info: dict - Additional model metadata returned in /v1/model/info (optional)

    Example curl:

    ```bash
    curl -L -X POST 'http://0.0.0.0:4000/model/new' \
    -H 'Authorization: Bearer LITELLM_VIRTUAL_KEY' \
    -H 'Content-Type: application/json' \
    -d '{
      "model_name": "my-azure-model",
      "litellm_params": {
        "model": "azure/my-deployment-name",
        "api_key": "my-azure-api-key",
        "api_base": "https://my-endpoint.openai.azure.com"
      },
      "model_info": {
        "my_custom_key": "my_custom_value"
      }
    }'
    ```

    Returns:
    - The created model entry with model_id
    """
    from litellm.proxy.proxy_server import (
        general_settings,
        premium_user,
        prisma_client,
        proxy_config,
        proxy_logging_obj,
        store_model_in_db,
    )

    try:
        if prisma_client is None:
            raise HTTPException(
                status_code=500,
                detail={
                    "error": "No DB Connected. Here's how to do it - https://docs.litellm.ai/docs/proxy/virtual_keys"
                },
            )

        ## Auth check
        write_authorization: Final = await ModelManagementAuthChecks.can_user_make_model_call(
            model_params=model_params,
            user_api_key_dict=user_api_key_dict,
            prisma_client=prisma_client,
            premium_user=premium_user,
            member_operation="create",
        )
        member_write: Final = write_authorization if isinstance(write_authorization, MemberAutoRouterWrite) else None

        ModelManagementAuthChecks.can_user_attach_credential(
            litellm_params=model_params.litellm_params,
            user_api_key_dict=user_api_key_dict,
        )

        ModelManagementAuthChecks.can_user_set_aws_session_tags(
            litellm_params=model_params.litellm_params,
            user_api_key_dict=user_api_key_dict,
        )

        _raise_on_strategy_router_write_violation(
            incoming_params=model_params.litellm_params,
            existing_params=None,
        )

        _raise_if_rate_limits_required_but_missing(
            litellm_params=model_params.litellm_params,
            enforced=bool(general_settings.get(ENFORCE_RPM_TPM_ON_MODEL_ADD_SETTING, False)),
        )

        clean_model_info: Final = ModelInfo(
            **without_server_derived_pricing(model_params.model_info.model_dump(exclude_none=True))
        )
        model_params.model_info = (  # rebind-ok: downstream team-model handling mutates this same object
            clean_model_info.model_copy(update=MappingProxyType({"member_auto_router": True}))
            if member_write is not None
            else clean_model_info
        )

        model_response: prisma_models.LiteLLM_ProxyModelTable | LiteLLM_ProxyModelTable | None = None
        # update DB
        incoming_model_info: Final = model_params.model_info.model_dump(exclude_none=True)
        _raise_if_ptu_cost_attribution_disabled(incoming_model_info)
        _validate_ptu_model_info(incoming_model_info)
        priced_model_params: Final = _ptu_priced_deployment(model_params)

        if store_model_in_db is True:
            """
            - store model_list in db
            - store keys separately
            """

            live_before_reload: Final = live_model_ids_snapshot()
            reload_outcome: ReconcileOutcome = ReconcileOutcome(still_desired=None, live_after=None)
            try:
                _original_litellm_model_name: Final = model_params.model_name
                add_model: Final = (
                    _add_model_to_db if model_params.model_info.team_id is None else _add_team_model_to_db
                )
                model_response = await add_model(
                    model_params=priced_model_params,
                    user_api_key_dict=user_api_key_dict,
                    prisma_client=prisma_client,
                    slot=_auto_router_capability_slot(
                        prisma_client,
                        effective_params=_effective_complexity_router_params(
                            priced_model_params.litellm_params,
                            None,
                        ),
                        model_id=priced_model_params.model_info.id,
                        member_write=member_write,
                    ),
                )
                reload_outcome = await proxy_config.add_deployment(
                    prisma_client=prisma_client, proxy_logging_obj=proxy_logging_obj
                )
                # don't let failed slack alert block the /model/new response
                _alerting: Final = general_settings.get("alerting", []) or []
                if "slack" in _alerting:
                    # send notification - new model added
                    await proxy_logging_obj.slack_alerting_instance.model_added_alert(
                        model_name=priced_model_params.model_name,
                        litellm_model_name=_original_litellm_model_name,
                        passed_model_info=priced_model_params.model_info,
                    )
            except Exception as e:
                if isinstance(e, HTTPException):
                    raise
                verbose_proxy_logger.exception("Exception in add_new_model: %s", e)

        else:
            raise HTTPException(
                status_code=500,
                detail={"error": "Set `'STORE_MODEL_IN_DB='True'` in your env to enable this feature."},
            )

        if model_response is None:
            raise HTTPException(
                status_code=500,
                detail={"error": "Failed to add model to db. Check your server logs for more details."},
            )

        ## CREATE AUDIT LOG ##
        asyncio.create_task(
            create_object_audit_log(
                object_id=model_response.model_id,
                action="created",
                user_api_key_dict=user_api_key_dict,
                table_name=LitellmTableNames.PROXY_MODEL_TABLE_NAME,
                before_value=None,
                after_value=(
                    model_response.model_dump_json(exclude_none=True) if isinstance(model_response, BaseModel) else None
                ),
                litellm_changed_by=user_api_key_dict.user_id,
                litellm_proxy_admin_name=LITELLM_PROXY_ADMIN_NAME,
            )
        )

        raise_if_reload_degraded_serving(
            before=live_before_reload,
            written_models=[(model_response.model_id, getattr(model_response, "model_info", None))],
            action="create",
            still_desired=reload_outcome.still_desired,
            live_after=reload_outcome.live_after,
        )

        return model_response

    except Exception as e:
        verbose_proxy_logger.exception("litellm.proxy.proxy_server.add_new_model(): Exception occured - %s", e)
        if isinstance(e, HTTPException):
            raise ProxyException(
                message=getattr(e, "detail", f"Authentication Error({e})"),
                type=ProxyErrorTypes.auth_error,
                param=getattr(e, "param", "None"),
                code=getattr(e, "status_code", status.HTTP_400_BAD_REQUEST),
            )
        elif isinstance(e, ProxyException):
            raise e
        raise ProxyException(
            message="Authentication Error, " + str(e),
            type=ProxyErrorTypes.auth_error,
            param=getattr(e, "param", "None"),
            code=status.HTTP_400_BAD_REQUEST,
        )


#### MODEL MANAGEMENT ####
@router.post(
    "/model/update",
    description="Edit existing model params",
    tags=["model management"],
    dependencies=[Depends(user_api_key_auth)],
)
async def update_model(
    model_params: updateDeployment,
    user_api_key_dict: UserAPIKeyAuth = Depends(user_api_key_auth),
):
    """
    Old endpoint for model update. Makes a PUT request.

    Use `/model/{model_id}/update` to PATCH the stored model in db.
    """
    from litellm.proxy.proxy_server import (
        LITELLM_PROXY_ADMIN_NAME,
        llm_router,
        premium_user,
        prisma_client,
        store_model_in_db,
        user_api_key_cache,
    )

    try:
        if prisma_client is None:
            raise HTTPException(
                status_code=500,
                detail={
                    "error": "No DB Connected. Here's how to do it - https://docs.litellm.ai/docs/proxy/virtual_keys"
                },
            )

        _model_id: str | None = None
        _model_info: Final[ModelInfo | None] = getattr(model_params, "model_info", None)
        if _model_info is None:
            raise Exception("model_info not provided")

        _model_id = _model_info.id
        if _model_id is None:
            raise Exception("model_info.id not provided")

        _existing_litellm_params = await ModelRepository(prisma_client).table.find_unique(where={"model_id": _model_id})

        if _existing_litellm_params is None:
            if llm_router is not None and llm_router.get_deployment(model_id=_model_id) is not None:
                raise HTTPException(
                    status_code=400,
                    detail={"error": "Can't edit model. Model in config. Store model in db via `/model/new`. to edit."},
                )
            else:
                raise Exception("model not found")
        deployment: Final = Deployment(**_existing_litellm_params.model_dump())

        write_authorization: Final = await ModelManagementAuthChecks.can_user_make_model_call(
            model_params=deployment,
            user_api_key_dict=user_api_key_dict,
            prisma_client=prisma_client,
            premium_user=premium_user,
            member_operation="update",
            incoming_model_params=model_params,
        )
        member_write: Final = write_authorization if isinstance(write_authorization, MemberAutoRouterWrite) else None

        ModelManagementAuthChecks.can_user_attach_credential(
            litellm_params=model_params.litellm_params,
            user_api_key_dict=user_api_key_dict,
            existing_litellm_params=deployment.litellm_params,
        )

        ModelManagementAuthChecks.can_user_set_aws_session_tags(
            litellm_params=model_params.litellm_params,
            user_api_key_dict=user_api_key_dict,
            existing_litellm_params=deployment.litellm_params,
        )

        _raise_on_strategy_router_write_violation(
            incoming_params=model_params.litellm_params,
            existing_params=deployment.litellm_params,
        )
        effective_params: Final = _effective_complexity_router_params(
            model_params.litellm_params, deployment.litellm_params
        )
        member_marker: Final = _member_auto_router_marker_for_update(
            incoming_params=model_params.litellm_params, existing=deployment, member_write=member_write
        )

        # update DB
        if store_model_in_db is True:
            existing_model_row: Final = cast(  # cast-ok: prisma types Json columns as `str`; the driver parses them
                "_ExistingModelRow", _existing_litellm_params
            )
            _existing_litellm_params_dict: Final = dict(existing_model_row.litellm_params)

            if model_params.litellm_params is None:
                raise Exception("litellm_params not provided")

            _new_litellm_params_dict: Final = model_params.litellm_params.dict(exclude_none=True)

            ### ENCRYPT PARAMS ###
            encrypted_params: Final = MappingProxyType(
                {
                    k: (
                        _effective_complexity_router_config(model_params.litellm_params, deployment.litellm_params)
                        if k == "complexity_router_config"
                        else encrypt_value_helper(value=v)
                    )
                    for k, v in _new_litellm_params_dict.items()
                }
            )

            ### MERGE WITH EXISTING DATA ###
            _mp: Final[dict[str, object]] = model_params.litellm_params.dict()
            merged_dictionary: Final = {
                key: _existing_litellm_params_dict[key] if value is None else encrypted_params[key]
                for key, value in _mp.items()
                if value is not None or _existing_litellm_params_dict.get(key) is not None
            }

            renamed_to: Final = (
                model_params.model_name
                if model_params.model_name not in (None, deployment.model_name)
                and deployment.model_info.team_id is None
                else None
            )
            base_update: Final[PrismaCompatibleUpdateDBModel] = {
                "litellm_params": json.dumps(merged_dictionary),
                "updated_by": user_api_key_dict.user_id or LITELLM_PROXY_ADMIN_NAME,
            }
            renamed_update: Final[PrismaCompatibleUpdateDBModel] = (
                {**base_update, "model_name": renamed_to} if renamed_to is not None else base_update
            )
            _data: Final[PrismaCompatibleUpdateDBModel] = (
                {
                    **renamed_update,
                    "model_info": deployment.model_info.model_copy(
                        update=MappingProxyType({"member_auto_router": member_marker})
                    ).model_dump_json(exclude_none=True),
                }
                if member_marker is not None
                else renamed_update
            )
            async with _auto_router_capability_slot(
                prisma_client,
                effective_params=effective_params,
                model_id=_model_id,
                member_write=member_write,
            ) as table:
                model_response: Final = await table.update(
                    where={"model_id": _model_id},
                    data=_data,
                )
            if renamed_to is not None:
                await sync_access_groups_for_renamed_model(
                    prisma_client=prisma_client,
                    model_id=_model_id,
                    old_name=deployment.model_name,
                    new_name=renamed_to,
                    llm_router=llm_router,
                )
                await sync_model_allowlists_for_renamed_model(
                    prisma_client=prisma_client,
                    model_id=_model_id,
                    old_name=deployment.model_name,
                    new_name=renamed_to,
                    llm_router=llm_router,
                    user_api_key_cache=user_api_key_cache,
                )

            # Clear cache and reload models (uses config setting or defaults to preserving config models for DB updates)
            live_before_reload: Final = live_model_ids_snapshot()
            reload_outcome: Final = await clear_cache()
            ## CREATE AUDIT LOG ##
            asyncio.create_task(
                create_object_audit_log(
                    object_id=_model_id,
                    action="updated",
                    user_api_key_dict=user_api_key_dict,
                    table_name=LitellmTableNames.PROXY_MODEL_TABLE_NAME,
                    before_value=(
                        existing_model_row.model_dump_json(exclude_none=True)
                        if isinstance(existing_model_row, BaseModel)
                        else None
                    ),
                    after_value=(
                        model_response.model_dump_json(exclude_none=True)
                        if isinstance(model_response, BaseModel)
                        else None
                    ),
                    litellm_changed_by=user_api_key_dict.user_id,
                    litellm_proxy_admin_name=LITELLM_PROXY_ADMIN_NAME,
                )
            )

            raise_if_reload_degraded_serving(
                before=live_before_reload,
                written_models=[(_model_id, getattr(model_response, "model_info", None))],
                action="update",
                still_desired=reload_outcome.still_desired,
                live_after=reload_outcome.live_after,
            )

            return model_response
    except Exception as e:
        verbose_proxy_logger.exception("litellm.proxy.proxy_server.update_model(): Exception occured - %s", e)
        if isinstance(e, HTTPException):
            raise ProxyException(
                message=getattr(e, "detail", f"Authentication Error({e})"),
                type=ProxyErrorTypes.auth_error,
                param=getattr(e, "param", "None"),
                code=getattr(e, "status_code", status.HTTP_400_BAD_REQUEST),
            )
        elif isinstance(e, ProxyException):
            raise e
        raise ProxyException(
            message="Authentication Error, " + str(e),
            type=ProxyErrorTypes.auth_error,
            param=getattr(e, "param", "None"),
            code=status.HTTP_400_BAD_REQUEST,
        )


@router.post(
    "/model_group/make_public",
    description="Update which model groups are public",
    tags=["model management"],
    dependencies=[Depends(user_api_key_auth)],
)
async def update_public_model_groups(
    request: UpdatePublicModelGroupsRequest,
    user_api_key_dict: UserAPIKeyAuth = Depends(user_api_key_auth),
):
    """
    Update which model groups are public.

    This endpoint allows admins to specify which model groups should be publicly accessible.
    Public model groups are visible via the /public/model_hub endpoint.

    Args:
        request: Request containing list of model group names to make public
        user_api_key_dict: User authentication information

    Returns:
        Success message with updated public model groups

    Raises:
        ProxyException: For various error conditions including authentication errors
    """
    try:
        # Update the public model groups
        from litellm.proxy.proxy_server import proxy_config, store_model_in_db

        # Check if user has admin permissions
        if user_api_key_dict.user_role != LitellmUserRoles.PROXY_ADMIN:
            raise HTTPException(
                status_code=403,
                detail={
                    "error": f"Only proxy admins can update public model groups. Your role={user_api_key_dict.user_role}"
                },
            )

        # Check if STORE_MODEL_IN_DB is enabled
        if store_model_in_db is not True:
            raise HTTPException(
                status_code=500,
                detail={"error": "Set `'STORE_MODEL_IN_DB='True'` in your env to enable this feature."},
            )

        # Load existing config first (this may overwrite in-memory litellm settings
        # from DB values via _update_config_from_db), so set the in-memory value AFTER
        config: Final = await proxy_config.get_config()

        # Update config with new settings
        if "litellm_settings" not in config:
            config["litellm_settings"] = {}

        config["litellm_settings"]["public_model_groups"] = request.model_groups

        # Save the updated config
        await proxy_config.save_config(new_config=config)

        # Set in-memory value AFTER get_config() and save_config() to avoid
        # get_config() overwriting with stale DB value
        litellm.public_model_groups = request.model_groups

        verbose_proxy_logger.debug(
            "Updated public model groups to: %s by user: %s", request.model_groups, user_api_key_dict.user_id
        )

        return {
            "message": "Successfully updated public model groups",
            "public_model_groups": request.model_groups,
            "updated_by": user_api_key_dict.user_id,
        }

    except Exception as e:
        verbose_proxy_logger.exception("Error updating public model groups: %s", e)

        if isinstance(e, HTTPException):
            raise e

        raise ProxyException(
            message=f"Error updating public model groups: {e}",
            type=ProxyErrorTypes.internal_server_error,
            code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            param=None,
        )


@router.post(
    "/model_hub/update_useful_links",
    description="Update useful links",
    tags=["model management"],
    dependencies=[Depends(user_api_key_auth)],
)
async def update_useful_links(
    request: UpdateUsefulLinksRequest,
    user_api_key_dict: UserAPIKeyAuth = Depends(user_api_key_auth),
):
    """
    Update useful links.
    """
    try:
        # Update the public model groups
        from litellm.proxy.proxy_server import proxy_config

        # Check if user has admin permissions
        if user_api_key_dict.user_role != LitellmUserRoles.PROXY_ADMIN:
            raise HTTPException(
                status_code=403,
                detail={
                    "error": f"Only proxy admins can update public model groups. Your role={user_api_key_dict.user_role}"
                },
            )

        # Load existing config first (this may overwrite in-memory litellm settings
        # from DB values via _update_config_from_db), so set the in-memory value AFTER
        config: Final = await proxy_config.get_config()

        # Update config with new settings
        if "litellm_settings" not in config:
            config["litellm_settings"] = {}

        config["litellm_settings"]["public_model_groups_links"] = request.useful_links

        # Save the updated config
        await proxy_config.save_config(new_config=config)

        # Set in-memory value AFTER get_config() and save_config() to avoid
        # get_config() overwriting with stale DB value
        litellm.public_model_groups_links = request.useful_links

        verbose_proxy_logger.debug(
            "Updated useful links to: %s by user: %s", request.useful_links, user_api_key_dict.user_id
        )

        return {
            "message": "Successfully updated useful links",
            "useful_links": request.useful_links,
            "updated_by": user_api_key_dict.user_id,
        }

    except Exception as e:
        verbose_proxy_logger.exception("Error updating public model groups: %s", e)

        if isinstance(e, HTTPException):
            raise e

        raise ProxyException(
            message=f"Error updating public model groups: {e}",
            type=ProxyErrorTypes.internal_server_error,
            code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            param=None,
        )


def _validated_labeled_tiers(
    tier_labels: dict[ComplexityTier, str],  # mutable-ok: Pydantic materializes JSON object fields as dicts
) -> tuple[tuple[ComplexityTier, str], ...]:
    """Validate tier labels once for both prompt-preview transports."""
    try:
        return ComplexityRouterConfig(tier_labels=tier_labels).labeled_tiers()
    except (TypeError, ValidationError) as e:
        raise ProxyException(
            message=f"tier_labels must be a JSON object of tier name to display name: {e}",
            type=ProxyErrorTypes.bad_request_error,
            code=status.HTTP_400_BAD_REQUEST,
            param="tier_labels",
        ) from e


def _labeled_tiers_from_query(tier_labels: str | None) -> tuple[tuple[ComplexityTier, str], ...] | None:
    """Resolve the tier_labels query param into the labeled tiers the rubric is built from."""
    if not tier_labels:
        return None
    try:
        parsed: Final = json.loads(tier_labels)
    except JSONDecodeError as e:
        raise ProxyException(
            message=f"tier_labels must be a JSON object of tier name to display name: {e}",
            type=ProxyErrorTypes.bad_request_error,
            code=status.HTTP_400_BAD_REQUEST,
            param="tier_labels",
        ) from e
    return _validated_labeled_tiers(parsed)


class AutoRouterClassifierPromptPreviewRequest(BaseModel):
    """A POST rather than query params: the classification sections are the operator's own text,
    which must not reach access logs through a URL."""

    tier_definitions: tuple[TierDefinition, ...] | None = None
    tier_labels: dict[ComplexityTier, str] | None = None  # mutable-ok: FastAPI parses JSON object fields into dicts
    classification_rubric: ClassificationRubric | None = None
    context_window_size: Annotated[int, Field(ge=0)] = DEFAULT_CLASSIFIER_CONTEXT_WINDOW_SIZE
    classification_prompt: str | None = None
    classification_examples: str | None = None

    _normalize_prompt = field_validator("classification_prompt")(normalize_classification_prompt)
    _normalize_examples = field_validator("classification_examples")(normalize_classification_examples)


@router.post(
    "/auto_router/classifier/default_prompt",
    description="Get the system prompt an auto-router's LLM classifier sends for an edited tier set",
    tags=["model management"],
    dependencies=[Depends(user_api_key_auth)],
)
async def preview_auto_router_classifier_prompt(
    request: AutoRouterClassifierPromptPreviewRequest,
) -> AutoRouterClassifierDefaultPromptResponse:
    """
    Get the classifier system prompt an edited tier set sends, so the dashboard can show it.

    Built by the same function the live classifier uses, so the preview cannot drift from what the
    router sends. Payload validity beyond a renderable definition stays the dry-run's job.
    """
    labeled_tiers: Final = _validated_labeled_tiers(request.tier_labels or {})
    system_prompt: Final = (
        custom_tier_classification_prompt(
            request.tier_definitions,
            request.classification_prompt,
            request.context_window_size,
            classification_examples=request.classification_examples,
        )
        if request.tier_definitions is not None
        else built_in_tier_classification_prompt(
            request.classification_prompt,
            request.context_window_size,
            labeled_tiers=labeled_tiers,
            classification_rubric=request.classification_rubric,
            classification_examples=request.classification_examples,
        )
    )
    return AutoRouterClassifierDefaultPromptResponse(system_prompt=system_prompt)


@router.get(
    "/auto_router/classifier/default_prompt",
    description="Get the built-in system prompt used by an auto-router's LLM classifier",
    tags=["model management"],
    dependencies=[Depends(user_api_key_auth)],
)
async def get_auto_router_classifier_default_prompt(
    context_window_size: int = DEFAULT_CLASSIFIER_CONTEXT_WINDOW_SIZE,
    tier_labels: str | None = None,
    classification_rubric: ClassificationRubric | None = None,
) -> AutoRouterClassifierDefaultPromptResponse:
    """
    Get the classifier system prompt a router would send, so the dashboard can show it.

    The prompt's closing line depends on whether prior conversation turns are quoted to the
    classifier, its tier bullets are named by the router's tier_labels, and its calibration examples
    come from the router's classification rubric, so the caller passes all three to get the text that router
    would actually send rather than a rubric it does not use.

    An edited tier set replaces the whole rubric; POST to this path for that prompt, which carries
    the operator's own instructions and so must not ride in a query string.

    Parameters:
    - context_window_size: int - The router's classifier_context_window_size. Defaults to the
      built-in default.
    - tier_labels: str | None - The router's tier_labels as a JSON object of canonical tier name to
      display name, e.g. `{"SIMPLE": "Cheap"}`. Omit or pass an empty object for the default names.
    - classification_rubric: ClassificationRubric | None - The router's
      classifier_llm_config.classification_rubric. Omit for the default.
    """
    if context_window_size < 0:
        raise ProxyException(
            message="context_window_size must be non-negative",
            type=ProxyErrorTypes.bad_request_error,
            code=status.HTTP_400_BAD_REQUEST,
            param="context_window_size",
        )

    labeled_tiers: Final = _labeled_tiers_from_query(tier_labels)
    return AutoRouterClassifierDefaultPromptResponse(
        system_prompt=(
            classification_system_prompt(context_window_size, classification_rubric=classification_rubric)
            if labeled_tiers is None
            else classification_system_prompt(
                context_window_size, labeled_tiers=labeled_tiers, classification_rubric=classification_rubric
            )
        )
    )


def _deduplicate_litellm_router_models(models: list[dict]) -> list[dict]:
    """
    Deduplicate models based on their model_info.id field.
    Returns a list of unique models keeping only the first occurrence of each model ID.

    Args:
        models: List of model dictionaries containing model_info

    Returns:
        List of deduplicated model dictionaries
    """
    seen_ids: Final = set()
    unique_models: Final = []
    for model in models:
        model_id = model.get("model_info", {}).get("id", None)
        if model_id is not None and model_id not in seen_ids:
            unique_models.append(model)
            seen_ids.add(model_id)
    return unique_models


def model_info_as_mapping(model_info: object) -> Mapping[str, object] | None:
    """A DB row's model_info column arrives as a dict or as its JSON string depending on
    the query path, and every consumer needs the mapping. Single owner of that parse:
    returns None when no usable mapping exists (None, an unparseable string, or JSON
    that is not an object), and callers choose what None means for them."""
    if isinstance(model_info, Mapping):
        return model_info
    if not isinstance(model_info, str):
        return None
    try:
        parsed: Final = json.loads(model_info)
    except (TypeError, ValueError):
        return None
    return parsed if isinstance(parsed, Mapping) else None


def _expects_liveness_on_this_pod(model_info: object) -> bool:
    from litellm.router import model_info_is_active_for_environment

    try:
        return model_info_is_active_for_environment(model_info=model_info_as_mapping(model_info))
    except ValueError:
        return True


def live_model_ids_snapshot() -> frozenset[str]:
    """The ids this pod's router is currently serving, read fresh from the module global
    because a reload can rebind it. The empirical ground truth every verdict below is
    computed from; an absent router serves nothing."""
    from litellm.proxy.proxy_server import llm_router

    if llm_router is None:
        return frozenset()
    return frozenset(llm_router.get_model_ids())


def reload_serving_verdict(
    before: frozenset[str],
    written_models: Sequence[tuple[str, object]],
    written_must_serve: bool,
    still_desired: frozenset[str] | None = None,
    live_after: frozenset[str] | None = None,
) -> tuple[tuple[str, ...], tuple[str, ...]]:
    """Judge a write-triggered reload by diffing the router's serving state instead of
    trusting any layer of the reload stack to report its own failure.

    The full cell matrix, per id:
    - written, must-serve (the write's purpose is this model's serving state): live now
      is fine; not live is reported unless the row is deliberately inactive for this
      pod's LITELLM_ENVIRONMENT; a row whose model_info cannot be read counts as
      expecting to serve, so its drop is still reported
    - written, metadata-only (must_not_degrade): live before and gone now is reported;
      a row that was already not serving stays silent, because its deadness predates
      this write and blaming it would block unrelated metadata fixes
    - not written but live before and gone now: collateral degradation of this pod
      caused by the reload this request triggered (a wholesale re-add failure, or a
      newly introduced conflict), reported only when the db still wants that id

    ``still_desired`` is the db + config id set the reload just reconciled against. An
    id absent from it was deleted on purpose, most often by another pod this one had not
    yet polled, so the reload dropping it is the reconcile working rather than damage.
    Without it (no reconcile ran) every drop is reported, which is the safe direction.

    ``live_after`` is the router's serving state captured by the reload itself, while it
    still held MODEL_RECONCILE_LOCK. Pass it whenever the caller has it: re-reading the
    router here instead means sampling it after the lock was released, where the NEXT
    reconcile's leading wipe (clear_cache un-serves every db model before reloading
    them) shows up as this reload having dropped them. Falling back to a fresh read is
    only correct when no reconcile ran and there is nothing to be concurrent with.

    Returns (written ids violating their obligation, collateral ids no longer served).
    """
    now: Final = live_model_ids_snapshot() if live_after is None else live_after
    written_ids: Final = frozenset(model_id for model_id, _ in written_models)
    if written_must_serve:
        missing = tuple(
            model_id
            for model_id, model_info in written_models
            if model_id not in now and _expects_liveness_on_this_pod(model_info)
        )
    else:
        missing = tuple(model_id for model_id, _ in written_models if model_id in before and model_id not in now)
    dropped: Final = before - now - written_ids
    collateral: Final = tuple(sorted(dropped if still_desired is None else dropped & still_desired))
    return (missing, collateral)


def raise_if_reload_degraded_serving(
    before: frozenset[str],
    written_models: Sequence[tuple[str, object]],
    action: str,
    still_desired: frozenset[str] | None = None,
    live_after: frozenset[str] | None = None,
) -> None:
    """The caller-visible error this pod's model-write endpoints owe their caller when
    the model they wrote is not being served after the reload they triggered. The DB
    write is durable either way and every other pod reloads on its own interval; this
    speaks only for the handling pod.

    Callers hold a ReconcileOutcome from the reload; pass BOTH of its fields. Supplying
    still_desired without live_after mixes a snapshot taken under the reconcile lock
    with one taken after it was released, which is what makes a concurrent model write
    look like collateral damage."""
    missing, collateral = reload_serving_verdict(
        before=before,
        written_models=written_models,
        written_must_serve=True,
        still_desired=still_desired,
        live_after=live_after,
    )
    if not missing and not collateral:
        return
    missing_clause: Final = (
        f"the model id(s) {list(missing)} are not live in this pod's router after the reload and are not "
        "being served by this pod."
        if missing
        else "the reload it triggered degraded this pod's serving state."
    )
    collateral_clause: Final = (
        f" Previously served model id(s) {list(collateral)} are also no longer being served by this pod."
        if collateral
        else ""
    )
    raise ProxyException(
        message=(
            f"Model {action} was saved to the database, but {missing_clause}{collateral_clause} "
            "Other pods reload on their own interval. Check server logs for 'Error upserting deployment' or "
            "'Error creating deployment' for the cause."
        ),
        type=ProxyErrorTypes.internal_server_error,
        code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        param=None,
    )


async def clear_cache() -> ReconcileOutcome:
    """
    Clear router caches and reload models.

    Returns what the reload saw (see ReconcileOutcome) so callers can pass it to
    raise_if_reload_degraded_serving.

    Runs under MODEL_RECONCILE_LOCK for its whole extent, not just the reload at the
    end, so the auto-router reset and the reload that rebuilds those routers are atomic
    to any other reconcile. The inner call is _add_deployment_locked because
    add_deployment would re-acquire the same non-reentrant lock and deadlock.
    """
    from litellm.proxy.proxy_server import (
        MODEL_RECONCILE_LOCK,
        llm_router,
        prisma_client,
        proxy_config,
        proxy_logging_obj,
        verbose_proxy_logger,
    )

    if llm_router is None or prisma_client is None:
        verbose_proxy_logger.debug("llm_router or prisma_client is None, skipping cache clear")
        return ReconcileOutcome(still_desired=None, live_after=None)

    async with MODEL_RECONCILE_LOCK:
        try:
            # Only clear DB models, preserve config models
            verbose_proxy_logger.debug("Clearing only DB models, preserving config models")

            # Get current models and filter out DB models
            current_models: Final = llm_router.model_list.copy()
            config_models: Final = []
            db_model_ids: Final = []

            db_router_names: Final = set()

            for model in current_models:
                model_info = model.get("model_info", {})
                if model_info.get("db_model", False):
                    db_model_ids.append(model_info.get("id"))
                    # Auto-router deployments (and only those) are wiped here, in the
                    # same pass, so the reload rebuilds them -- see the comment below.
                    model_name = model.get("model_name")
                    if model_name is not None and str(model.get("litellm_params", {}).get("model", "")).startswith(
                        "auto_router/"
                    ):
                        db_router_names.add(model_name)
                        router_model_id = model_info.get("id")
                        if router_model_id is not None:
                            llm_router.delete_deployment(id=router_model_id)
                else:
                    # This is a config model, preserved by the reconcile below
                    config_models.append(model)

            # ORDINARY db deployments are deliberately NOT wiped. This used to
            # delete_deployment() every db model before the reload put them back, which
            # left the router serving ZERO db models for the whole width of the reload
            # -- a real data-plane hole that every inference request landing in it fell
            # into. It was also redundant for them: the reload's _delete_deployment
            # evicts exactly the ids the db no longer lists, and upsert_deployment
            # pops-and-re-adds a deployment whose params changed while no-opping one
            # that did not, so the reconcile converges on its own. Every mutation is
            # visible to that comparison -- `blocked` and (for premium) `updated_at`
            # are written into model_info.
            #
            # AUTO-ROUTER db deployments are the exception and ARE wiped -- in the
            # classification pass above, together with the strategy entries popped
            # just below. Their strategy registries are keyed
            # by model_name, which no deployment-id reconcile touches, so they have to
            # be popped and rebuilt here. But the rebuild only happens on the ADD path:
            # Router.upsert_deployment returns early when a deployment is unchanged and
            # never reaches add_deployment -> _add_deployment ->
            # init_auto_router_deployment, which is what repopulates the registries.
            # Popping without deleting would therefore strip every db-backed auto,
            # complexity, adaptive and quality router on this pod and never put it back,
            # so ANY unrelated model write would leave them unroutable until a restart.
            # Deleting the deployment forces upsert down the add path, which rebuilds
            # both the deployment and its strategy entry.
            #
            # That pass restricts the wipe to deployments whose model is actually an
            # auto_router/* so a config router that merely shares a model_name with a
            # regular db model isn't evicted -- config routers are never re-added by the
            # reload (it only reloads db models) and would be permanently unroutable.
            # The auto_router/ prefix also covers quality_router/ and adaptive_router/,
            # so pop the name from every registry (no-op where absent); a missing
            # quality/adaptive entry would otherwise make init raise "already exists"
            # on reload and abort it.
            for model_name in db_router_names:
                llm_router.auto_routers.pop(model_name, None)
                llm_router.complexity_routers.pop(model_name, None)
                llm_router.adaptive_routers.pop(model_name, None)
                llm_router.quality_routers.pop(model_name, None)

            # Reload only DB models. _add_deployment_locked, not add_deployment: this
            # coroutine already holds MODEL_RECONCILE_LOCK and asyncio.Lock is not
            # reentrant, so the public wrapper would deadlock against itself.
            outcome: Final = await proxy_config._add_deployment_locked(
                prisma_client=prisma_client, proxy_logging_obj=proxy_logging_obj
            )

            verbose_proxy_logger.debug(
                "Reconciled %s DB models, preserved %s config models", len(db_model_ids), len(config_models)
            )
            return outcome
        except Exception as e:
            verbose_proxy_logger.exception("Failed to clear cache and reload models. Due to error - %s", e)
            return ReconcileOutcome(still_desired=None, live_after=None)
