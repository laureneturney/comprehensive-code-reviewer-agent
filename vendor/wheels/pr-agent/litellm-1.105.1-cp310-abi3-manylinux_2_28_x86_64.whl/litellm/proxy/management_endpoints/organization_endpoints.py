import math

"""
Endpoints for /organization operations

/organization/new
/organization/update
/organization/delete
/organization/member_add
/organization/info
/organization/list
"""

#### ORGANIZATION MANAGEMENT ####

from collections.abc import Mapping, Sequence
from types import MappingProxyType
from typing import (
    TYPE_CHECKING,
    Annotated,
    Final,
    NamedTuple,
    Protocol,
    cast,  # noqa: TID251  # prisma types Json columns as fields.Json but reads back plain python values
    overload,
)

import fastapi
from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import TypeAdapter
from typing_extensions import ReadOnly, TypedDict

from litellm._logging import verbose_proxy_logger
from litellm._uuid import uuid
from litellm.proxy._types import *
from litellm.proxy.auth.auth_checks import (
    can_user_call_model,
    delete_cache_key_objects,
    get_jwt_key_mapping_cache_keys_for_tokens,
    get_user_object,
)
from litellm.proxy.auth.user_api_key_auth import user_api_key_auth
from litellm.proxy.common_utils.auth_cache_invalidation_pubsub import evict_and_broadcast
from litellm.proxy.common_utils.timezone_utils import get_budget_reset_time
from litellm.proxy.common_utils.user_api_key_cache import UserApiKeyCache
from litellm.proxy.management_endpoints.budget_management_endpoints import (
    new_budget,
    update_budget,
)
from litellm.proxy.management_endpoints.common_daily_activity import get_daily_activity
from litellm.proxy.management_endpoints.common_utils import (
    _set_object_metadata_field,
    _user_has_admin_view,
    validate_budget_duration,
)
from litellm.proxy.management_helpers.object_permission_utils import (
    handle_update_object_permission_common,
    prepare_object_permission_upsert,
    reject_ambiguous_mcp_tool_permission_keys,
)
from litellm.proxy.management_helpers.utils import (
    get_new_internal_user_defaults,
    management_endpoint_wrapper,
)
from litellm.proxy.utils import PrismaClient, ProxyLogging
from litellm.repositories.budget_repository import BudgetRepository
from litellm.repositories.chunked_in import find_many_in
from litellm.repositories.object_permission_repository import ObjectPermissionRepository
from litellm.repositories.organization_repository import OrganizationRepository
from litellm.repositories.table_repositories import OrganizationMembershipRepository
from litellm.repositories.team_repository import TeamRepository
from litellm.repositories.user_repository import UserRepository
from litellm.repositories.verification_token_repository import (
    VerificationTokenRepository,
)
from litellm.types.proxy.management_endpoints.common_daily_activity import (
    SpendAnalyticsPaginatedResponse,
)
from litellm.utils import _update_dictionary

if TYPE_CHECKING:
    from types import TracebackType

    from prisma.models import LiteLLM_BudgetTable as PrismaBudgetTable
    from prisma.models import (
        LiteLLM_ObjectPermissionTable as PrismaObjectPermissionTable,
    )
    from prisma.models import (
        LiteLLM_OrganizationMembership as PrismaOrganizationMembership,
    )
    from prisma.models import LiteLLM_OrganizationTable as PrismaOrganizationTable
    from prisma.models import LiteLLM_UserTable as PrismaUserTable
    from prisma.models import LiteLLM_VerificationToken as PrismaVerificationToken


async def _enterprise_license_required(
    _user_api_key_dict: Annotated[UserAPIKeyAuth, Depends(user_api_key_auth)],
) -> None:
    from litellm.proxy.proxy_server import premium_user

    if not premium_user:
        raise HTTPException(
            status_code=403,
            detail={
                "error": "Organizations are only available for LiteLLM Enterprise users. "
                f"{CommonProxyErrors.not_premium_user.value}"
            },
        )


router: Final = APIRouter(dependencies=[Depends(_enterprise_license_required)])


class _ObjectPermissionRow(Protocol):
    @property
    def object_permission_id(self) -> str | None: ...


class _UserTableClient(Protocol):
    async def find_unique(self, where: Mapping[str, object]) -> "PrismaUserTable | None": ...


class _BudgetTableClient(Protocol):
    async def create(self, data: Mapping[str, object]) -> "PrismaBudgetTable": ...


class _ObjectPermissionTableClient(Protocol):
    async def create(self, data: Mapping[str, object]) -> "PrismaObjectPermissionTable": ...


class _OrganizationTableClient(Protocol):
    async def create(
        self, data: Mapping[str, object], include: Mapping[str, object] | None = None
    ) -> "PrismaOrganizationTable": ...

    async def find_unique(
        self, where: Mapping[str, object], include: Mapping[str, object] | None = None
    ) -> "PrismaOrganizationTable | None": ...

    async def find_many(
        self,
        where: Mapping[str, object] | None = None,
        include: Mapping[str, object] | None = None,
    ) -> "Sequence[PrismaOrganizationTable]": ...

    async def update(
        self,
        where: Mapping[str, object],
        data: Mapping[str, object],
        include: Mapping[str, object] | None = None,
    ) -> "PrismaOrganizationTable": ...

    async def delete(
        self, where: Mapping[str, object], include: Mapping[str, object] | None = None
    ) -> "PrismaOrganizationTable | None": ...


class _OrganizationMembershipTableClient(Protocol):
    async def create(self, data: Mapping[str, object]) -> "PrismaOrganizationMembership": ...

    async def find_unique(
        self, where: Mapping[str, object], include: Mapping[str, object] | None = None
    ) -> "PrismaOrganizationMembership | None": ...

    async def find_many(
        self, where: Mapping[str, object] | None = None
    ) -> "Sequence[PrismaOrganizationMembership]": ...

    async def update(
        self, where: Mapping[str, object], data: Mapping[str, object]
    ) -> "PrismaOrganizationMembership": ...

    async def delete(self, where: Mapping[str, object]) -> "PrismaOrganizationMembership | None": ...

    async def delete_many(self, where: Mapping[str, object]) -> int: ...


class _TeamTableClient(Protocol):
    async def delete_many(self, where: Mapping[str, object]) -> int: ...


class _VerificationTokenTableClient(Protocol):
    async def find_many(self, where: Mapping[str, object] | None = None) -> "Sequence[PrismaVerificationToken]": ...

    async def delete_many(self, where: Mapping[str, object]) -> int: ...


class _OrganizationIdFilter(TypedDict):
    organization_id: ReadOnly[str]


class _ObjectPermissionTxClient(Protocol):
    async def upsert(
        self, where: Mapping[str, object], data: Mapping[str, object]
    ) -> "PrismaObjectPermissionTable": ...


class _BudgetTxClient(Protocol):
    async def update(self, where: Mapping[str, object], data: Mapping[str, object]) -> "PrismaBudgetTable | None": ...


class _TransactionTables(Protocol):
    @property
    def litellm_objectpermissiontable(self) -> "_ObjectPermissionTxClient": ...

    @property
    def litellm_budgettable(self) -> "_BudgetTxClient": ...

    @property
    def litellm_organizationtable(self) -> "_OrganizationTableClient": ...


class _TransactionManager(Protocol):
    async def __aenter__(self) -> "_TransactionTables": ...

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: "TracebackType | None",
    ) -> bool | None: ...


@overload
def _table(repository: BudgetRepository) -> "_BudgetTableClient": ...


@overload
def _table(repository: ObjectPermissionRepository) -> "_ObjectPermissionTableClient": ...


@overload
def _table(repository: OrganizationRepository) -> "_OrganizationTableClient": ...


@overload
def _table(repository: OrganizationMembershipRepository) -> "_OrganizationMembershipTableClient": ...


@overload
def _table(repository: TeamRepository) -> "_TeamTableClient": ...


@overload
def _table(repository: UserRepository) -> "_UserTableClient": ...


@overload
def _table(repository: VerificationTokenRepository) -> "_VerificationTokenTableClient": ...


def _table(
    repository: BudgetRepository
    | ObjectPermissionRepository
    | OrganizationRepository
    | OrganizationMembershipRepository
    | TeamRepository
    | UserRepository
    | VerificationTokenRepository,
) -> object:
    prisma_table: Final[object] = repository.table
    return prisma_table


async def _verify_org_access(
    organization_id: str,
    user_api_key_dict: UserAPIKeyAuth,
    prisma_client: PrismaClient,
) -> None:
    """
    Verify the caller is either a proxy admin or an org admin of the given organization.

    Raises HTTPException(403) if the caller does not have access.
    """
    if _user_has_admin_view(user_api_key_dict):
        return

    if not user_api_key_dict.user_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You do not have access to this organization",
        )

    from litellm.proxy.proxy_server import proxy_logging_obj, user_api_key_cache

    caller_user: Final = await get_user_object(
        user_id=user_api_key_dict.user_id,
        prisma_client=prisma_client,
        user_api_key_cache=user_api_key_cache,
        user_id_upsert=False,
        proxy_logging_obj=proxy_logging_obj,
    )
    if caller_user is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You do not have access to this organization",
        )

    for m in caller_user.organization_memberships or []:
        if m.organization_id == organization_id and m.user_role == LitellmUserRoles.ORG_ADMIN.value:
            return

    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="You do not have access to this organization",
    )


_STR_OBJECT_DICT_ADAPTER: Final = TypeAdapter(dict[str, object])
_BUDGET_SETTABLE_FIELDS: Final = frozenset(LiteLLM_BudgetTable.model_fields.keys()) - {"budget_id"}
_ORG_COLUMN_FIELDS: Final = frozenset({"organization_alias", "models"})
_ORG_METADATA_FIELDS: Final = tuple(
    field for field in LiteLLM_ManagementEndpoint_MetadataFields if field not in _BUDGET_SETTABLE_FIELDS
)


def build_budget_write_data(budget_updates: Mapping[str, object], updated_by: str) -> Mapping[str, object]:
    """
    Budget-row columns to write. ``budget_reset_at`` tracks any sent ``budget_duration``:
    recomputed for a new duration, cleared alongside a ``None`` duration so no stale reset
    timestamp survives. Other sent fields (including a ``None`` clear) are written as-is.
    """
    budget_duration: Final = budget_updates.get("budget_duration")
    recomputed_reset_at: Final[Mapping[str, object]] = (
        {
            "budget_reset_at": (
                get_budget_reset_time(budget_duration=budget_duration) if isinstance(budget_duration, str) else None
            )
        }
        if "budget_duration" in budget_updates
        else {}
    )
    return {**budget_updates, **recomputed_reset_at, "updated_by": updated_by}


def handle_nested_budget_structure_in_organization_update_request(
    raw_data: dict,
) -> dict:
    """
    Transform organization update request to handle UI payload format.

    The UI sends nested budget data in 'litellm_budget_table', but our
    model expects flat budget fields at the top level.
    """
    transformed_data: Final = raw_data.copy()

    # Handle nested budget structure from UI
    if "litellm_budget_table" in transformed_data:
        budget_data: Final = transformed_data.pop("litellm_budget_table", {})
        if budget_data:
            # Extract valid budget fields and merge into top level
            budget_fields: Final = LiteLLM_BudgetTable.model_fields.keys()
            for key, value in budget_data.items():
                if key in budget_fields:
                    transformed_data[key] = value

    return transformed_data


@router.post(
    "/organization/new",
    tags=["organization management"],
    dependencies=[Depends(user_api_key_auth)],
    response_model=NewOrganizationResponse,
)
async def new_organization(
    data: NewOrganizationRequest,
    user_api_key_dict: UserAPIKeyAuth = Depends(user_api_key_auth),
):
    """
    Allow orgs to own teams

    Set org level budgets + model access.

    Only admins can create orgs.

    # Parameters

    - organization_alias: *str* - The name of the organization.
    - models: *List* - The models the organization has access to.
    - budget_id: *Optional[str]* - The id for a budget (tpm/rpm/max budget) for the organization.
    ### IF NO BUDGET ID - CREATE ONE WITH THESE PARAMS ###
    - max_budget: *Optional[float]* - Max budget for org
    - tpm_limit: *Optional[int]* - Max tpm limit for org
    - rpm_limit: *Optional[int]* - Max rpm limit for org
    - tpd_limit: *Optional[int]* - Max tokens per day stored on the org budget. Batch submissions enforce tpd_limit at the key, team and end user scopes only.
    - model_rpm_limit: *Optional[Dict[str, int]]* - The RPM (Requests Per Minute) limit per model for this organization.
    - model_tpm_limit: *Optional[Dict[str, int]]* - The TPM (Tokens Per Minute) limit per model for this organization.
    - max_parallel_requests: *Optional[int]* - [Not Implemented Yet] Max parallel requests for org
    - soft_budget: *Optional[float]* - [Not Implemented Yet] Get a slack alert when this soft budget is reached. Don't block requests.
    - model_max_budget: *Optional[dict]* - Max budget for a specific model
    - budget_duration: *Optional[str]* - Frequency of reseting org budget
    - metadata: *Optional[dict]* - Metadata for organization, store information for organization. Example metadata - {"extra_info": "some info"}
    - blocked: *bool* - Flag indicating if the org is blocked or not - will stop all calls from keys with this org_id.
    - tags: *Optional[List[str]]* - Tags for [tracking spend](https://litellm.vercel.app/docs/proxy/enterprise#tracking-spend-for-custom-tags) and/or doing [tag-based routing](https://litellm.vercel.app/docs/proxy/tag_routing).
    - organization_id: *Optional[str]* - The organization id of the team. Default is None. Create via `/organization/new`.
    - model_aliases: Optional[dict] - Model aliases for the team. [Docs](https://docs.litellm.ai/docs/proxy/team_based_routing#create-team-with-model-alias)
    - object_permission: Optional[LiteLLM_ObjectPermissionBase] - organization-specific object permission. Example - {"vector_stores": ["vector_store_1", "vector_store_2"]}. IF null or {} then no object permission.
    - allowed_models: Optional[List[str]] - List of models the organization is allowed to access. If not set, defaults to the models field.
    - temp_budget_increase: *Optional[float]* - Stored on the org budget row but only enforced for team member budgets today.
    - temp_budget_expiry: *Optional[str]* - Stored on the org budget row but only enforced for team member budgets today.
    Case 1: Create new org **without** a budget_id

    ```bash
    curl --location 'http://0.0.0.0:4000/organization/new' \

    --header 'Authorization: Bearer sk-1234' \

    --header 'Content-Type: application/json' \

    --data '{
        "organization_alias": "my-secret-org",
        "models": ["model1", "model2"],
        "max_budget": 100
    }'


    ```

    Case 2: Create new org **with** a budget_id

    ```bash
    curl --location 'http://0.0.0.0:4000/organization/new' \

    --header 'Authorization: Bearer sk-1234' \

    --header 'Content-Type: application/json' \

    --data '{
        "organization_alias": "my-secret-org",
        "models": ["model1", "model2"],
        "budget_id": "428eeaa8-f3ac-4e85-a8fb-7dc8d7aa8689"
    }'
    ```
    """

    from litellm.proxy.proxy_server import (
        litellm_proxy_admin_name,
        llm_router,
        prisma_client,
    )

    if prisma_client is None:
        raise HTTPException(
            status_code=500,
            detail={"error": CommonProxyErrors.db_not_connected_error.value},
        )

    if user_api_key_dict.user_role is None or user_api_key_dict.user_role != LitellmUserRoles.PROXY_ADMIN:
        raise HTTPException(
            status_code=401,
            detail={"error": f"Only admins can create orgs. Your role is = {user_api_key_dict.user_role}"},
        )

    if llm_router is None:
        raise HTTPException(status_code=500, detail={"error": CommonProxyErrors.no_llm_router.value})

    # Validate budget values are not negative
    if data.max_budget is not None and (not math.isfinite(data.max_budget) or data.max_budget < 0):
        raise HTTPException(
            status_code=400,
            detail={"error": f"max_budget must be a non-negative finite number. Received: {data.max_budget}"},
        )
    if data.soft_budget is not None and (not math.isfinite(data.soft_budget) or data.soft_budget < 0):
        raise HTTPException(
            status_code=400,
            detail={"error": f"soft_budget must be a non-negative finite number. Received: {data.soft_budget}"},
        )

    user_object_correct_type: LiteLLM_UserTable | None = None

    if user_api_key_dict.user_id is not None:
        try:
            user_object: Final = await _table(UserRepository(prisma_client)).find_unique(
                where={"user_id": user_api_key_dict.user_id}
            )
            if user_object is not None:
                user_object_correct_type = LiteLLM_UserTable.model_validate(user_object.model_dump())
        except Exception:
            pass

    if data.budget_id is None:
        """
        Every organization needs a budget attached.

        If none provided, create one based on provided values
        """
        budget_params: Final = LiteLLM_BudgetTable.model_fields.keys()

        # Only include Budget Params when creating an entry in litellm_budgettable
        _json_data: Final = _STR_OBJECT_DICT_ADAPTER.validate_python(data.json(exclude_none=True))
        _budget_data: Final = {k: v for k, v in _json_data.items() if k in budget_params}
        budget_row: Final = LiteLLM_BudgetTable.model_validate(_budget_data)

        new_budget: Final = _STR_OBJECT_DICT_ADAPTER.validate_python(
            prisma_client.jsonify_object(budget_row.json(exclude_none=True))
        )

        _budget: Final = await _table(BudgetRepository(prisma_client)).create(
            data={
                **new_budget,
                "created_by": user_api_key_dict.user_id or litellm_proxy_admin_name,
                "updated_by": user_api_key_dict.user_id or litellm_proxy_admin_name,
            }
        )

        data.budget_id = _budget.budget_id

    ## Handle Object Permission - MCP, Vector Stores etc.
    object_permission_id: Final = await _set_object_permission(
        data=data,
        prisma_client=prisma_client,
    )

    """
    Ensure only models that user has access to, are given to org
    """
    if len(user_api_key_dict.models) == 0:  # user has access to all models
        pass
    else:
        if len(data.models) == 0:
            raise HTTPException(
                status_code=400,
                detail={
                    "error": "User not allowed to give access to all models. Select models you want org to have access to."
                },
            )

        for m in data.models:
            await can_user_call_model(m, llm_router=llm_router, user_object=user_object_correct_type)

    organization_payload: Final = _STR_OBJECT_DICT_ADAPTER.validate_python(data.json(exclude_none=True))
    organization_payload["object_permission_id"] = object_permission_id
    organization_payload["created_by"] = user_api_key_dict.user_id or litellm_proxy_admin_name
    organization_payload["updated_by"] = user_api_key_dict.user_id or litellm_proxy_admin_name
    organization_row: Final = LiteLLM_OrganizationTable.model_validate(organization_payload)

    for field in _ORG_METADATA_FIELDS:
        if getattr(data, field, None) is not None:
            _set_object_metadata_field(
                object_data=organization_row,
                field_name=field,
                value=getattr(data, field),
            )

    new_organization_row: Final = _STR_OBJECT_DICT_ADAPTER.validate_python(
        prisma_client.jsonify_object(organization_row.json(exclude_none=True))
    )
    verbose_proxy_logger.info("new_organization_row: %s", json.dumps(new_organization_row, indent=2))
    response: Final = await _table(OrganizationRepository(prisma_client)).create(
        data={
            **new_organization_row,
        },
        include={"litellm_budget_table": True},
    )

    return response


@router.get(
    "/organization/daily/activity",
    response_model=SpendAnalyticsPaginatedResponse,
    tags=["organization management"],
)
async def get_organization_daily_activity(
    organization_ids: str | None = None,
    start_date: str | None = None,
    end_date: str | None = None,
    model: str | None = None,
    api_key: str | None = None,
    page: int = 1,
    page_size: int = 10,
    exclude_organization_ids: str | None = None,
    user_api_key_dict: UserAPIKeyAuth = Depends(user_api_key_auth),
):
    """
    Get daily activity for specific organizations or all accessible organizations.
    """
    from litellm.proxy.proxy_server import (
        prisma_client,
    )

    if prisma_client is None:
        raise HTTPException(
            status_code=500,
            detail={"error": CommonProxyErrors.db_not_connected_error.value},
        )

    org_ids: Final = tuple(organization_ids.split(",")) if organization_ids else None
    exclude_org_ids_list: list[str] | None = None
    if exclude_organization_ids:
        exclude_org_ids_list = exclude_organization_ids.split(",") if exclude_organization_ids else None

    org_scope: Final = await resolve_organization_daily_activity_scope(
        organization_ids=org_ids,
        prisma_client=prisma_client,
        user_api_key_dict=user_api_key_dict,
    )

    return await get_daily_activity(
        prisma_client=prisma_client,
        table_name="litellm_dailyorganizationspend",
        entity_id_field="organization_id",
        entity_id=None if org_scope.organization_ids is None else list(org_scope.organization_ids),
        entity_metadata_field=org_scope.organization_metadata,
        exclude_entity_ids=exclude_org_ids_list,
        start_date=start_date,
        end_date=end_date,
        model=model,
        api_key=api_key,
        page=page,
        page_size=page_size,
    )


class _OrganizationDailyActivityScope(NamedTuple):
    organization_ids: tuple[str, ...] | None
    organization_metadata: Mapping[str, dict[str, object]]


async def resolve_organization_daily_activity_scope(
    *,
    organization_ids: tuple[str, ...] | None,
    prisma_client: PrismaClient,
    user_api_key_dict: UserAPIKeyAuth,
) -> _OrganizationDailyActivityScope:
    is_admin: Final = _user_has_admin_view(user_api_key_dict)
    memberships: Final = (
        await _table(OrganizationMembershipRepository(prisma_client)).find_many(
            where={"user_id": user_api_key_dict.user_id}
        )
        if not is_admin
        else ()
    )
    admin_organization_ids: Final = tuple(
        membership.organization_id
        for membership in memberships
        if membership.user_role == LitellmUserRoles.ORG_ADMIN.value
    )
    if not is_admin and organization_ids is not None:
        for organization_id in organization_ids:
            if organization_id not in admin_organization_ids:
                raise HTTPException(
                    status_code=403,
                    detail={"error": f"User is not org_admin for Organization= {organization_id}."},
                )
    resolved_organization_ids: Final[tuple[str, ...] | None] = (
        organization_ids if is_admin or organization_ids is not None else admin_organization_ids
    )

    organization_table: Final = _table(OrganizationRepository(prisma_client))
    organization_rows: Final = (
        await find_many_in(organization_table, "organization_id", resolved_organization_ids)
        if resolved_organization_ids is not None
        else await organization_table.find_many(where={})
    )
    metadata: Final = MappingProxyType(
        {
            organization.organization_id: {"organization_alias": organization.organization_alias}
            for organization in organization_rows
        }
    )
    return _OrganizationDailyActivityScope(resolved_organization_ids, metadata)


async def _set_object_permission(
    data: NewOrganizationRequest,
    prisma_client: PrismaClient | None,
) -> str | None:
    """
    Creates the LiteLLM_ObjectPermissionTable record for the organization.
    - Handles permissions for vector stores and mcp servers.

    Returns the object_permission_id if created, otherwise None.
    """
    if prisma_client is None:
        return None

    if data.object_permission is not None:
        await reject_ambiguous_mcp_tool_permission_keys(
            new_mcp_tool_permissions=data.object_permission.mcp_tool_permissions,
            existing_mcp_tool_permissions=None,
            prisma_client=prisma_client,
        )
        created_object_permission: Final = await _table(ObjectPermissionRepository(prisma_client)).create(
            data=data.object_permission.model_dump(exclude_none=True),
        )
        del data.object_permission
        return created_object_permission.object_permission_id
    return None


@router.patch(
    "/organization/update",
    tags=["organization management"],
    dependencies=[Depends(user_api_key_auth)],
    response_model=LiteLLM_OrganizationTableWithMembers,
)
async def update_organization(
    request: Request,
    user_api_key_dict: UserAPIKeyAuth = Depends(user_api_key_auth),
):
    """
    Update an organization
    """
    from litellm.proxy.proxy_server import prisma_client

    if prisma_client is None:
        raise HTTPException(
            status_code=500,
            detail={"error": CommonProxyErrors.db_not_connected_error.value},
        )

    if user_api_key_dict.user_id is None:
        raise HTTPException(
            status_code=400,
            detail={
                "error": "Cannot associate a user_id to this action. Check `/key/info` to validate if 'user_id' is set."
            },
        )

    # Transform UI payload to expected format
    raw_data: Final[dict[str, object]] = await request.json()
    raw_data_with_flat_budget_fields: Final = handle_nested_budget_structure_in_organization_update_request(raw_data)

    # Create validated data model
    data: Final = LiteLLM_OrganizationTableUpdate(**raw_data_with_flat_budget_fields)

    # Validate budget values are not negative
    if data.max_budget is not None and (not math.isfinite(data.max_budget) or data.max_budget < 0):
        raise HTTPException(
            status_code=400,
            detail={"error": f"max_budget must be a non-negative finite number. Received: {data.max_budget}"},
        )
    if data.soft_budget is not None and (not math.isfinite(data.soft_budget) or data.soft_budget < 0):
        raise HTTPException(
            status_code=400,
            detail={"error": f"soft_budget must be a non-negative finite number. Received: {data.soft_budget}"},
        )

    if data.updated_by is None:
        data.updated_by = user_api_key_dict.user_id

    if data.organization_id is None:
        raise HTTPException(
            status_code=400,
            detail={"error": "organization_id is required"},
        )

    # IDOR guard: only proxy admins / org admins of THIS org may update
    # it. Without this, any authenticated key holder could rewrite
    # another organization's metadata, budgets, and object permissions.
    await _verify_org_access(
        organization_id=data.organization_id,
        user_api_key_dict=user_api_key_dict,
        prisma_client=prisma_client,
    )

    existing_organization_row: Final = await OrganizationRepository(prisma_client).table.find_unique(
        where={"organization_id": data.organization_id},
    )

    if existing_organization_row is None:
        raise ValueError(f"Organization not found for organization_id={data.organization_id}")

    updated_organization_row_json: Final = data.model_dump(exclude_none=True)
    # Merge metadata from existing organization with updated metadata
    if updated_organization_row_json.get("metadata") is not None:
        existing_metadata: Final = existing_organization_row.metadata or {}
        updated_metadata: Final[dict[str, object]] = updated_organization_row_json.get("metadata", {})
        merged_metadata: Final[Mapping[str, object]] = _update_dictionary(
            existing_dict=cast(  # cast-ok: prisma de-serializes a Json column to the plain python dict it stores
                "dict[str, object]", existing_metadata
            ).copy(),
            new_dict=updated_metadata,
        )
        updated_organization_row_json["metadata"] = merged_metadata

    updated_organization_row = _STR_OBJECT_DICT_ADAPTER.validate_python(
        prisma_client.jsonify_object(updated_organization_row_json)
    )
    if data.object_permission is not None:
        updated_organization_row = await handle_update_object_permission(
            data_json=updated_organization_row,
            existing_organization_row=existing_organization_row,
        )

    budget_fields: Final = {
        k: v for k, v in data.model_dump().items() if k in _BUDGET_SETTABLE_FIELDS and k in data.model_fields_set
    }

    if budget_fields and existing_organization_row.budget_id:
        await update_budget(
            budget_obj=BudgetNewRequest(budget_id=existing_organization_row.budget_id, **budget_fields),
            user_api_key_dict=user_api_key_dict,
        )

    # Remove budget fields from organization update data
    for field in LiteLLM_BudgetTable.model_fields:
        updated_organization_row.pop(field, None)

    response: Final = await _table(OrganizationRepository(prisma_client)).update(
        where={"organization_id": data.organization_id},
        data=updated_organization_row,
        include={"members": True, "teams": True, "litellm_budget_table": True},
    )

    return response


async def handle_update_object_permission(
    data_json: dict[str, object],
    existing_organization_row: _ObjectPermissionRow,
) -> dict[str, object]:
    """
    Handle the update of object permission for an organization.

    - Upserts the new object permission into the LiteLLM_ObjectPermissionTable
    - Adds object_permission_id to data_json (this gets added in the DB)
    - Pops the object_permission from data_json
    """
    from litellm.proxy.proxy_server import prisma_client

    # Use the common helper to handle the object permission update
    object_permission_id: Final = await handle_update_object_permission_common(
        data_json=data_json,
        existing_object_permission_id=existing_organization_row.object_permission_id,
        prisma_client=prisma_client,
    )

    # Add the object_permission_id to data_json if one was created/updated
    if object_permission_id is not None:
        data_json["object_permission_id"] = object_permission_id

    return data_json


@router.patch(
    "/v2/organization/{organization_id}",
    tags=["organization management"],
    dependencies=[Depends(user_api_key_auth)],
    response_model=LiteLLM_OrganizationTableWithMembers,
)
async def update_organization_v2(
    organization_id: str,
    data: OrganizationUpdateRequestV2,
    user_api_key_dict: Annotated[UserAPIKeyAuth, Depends(user_api_key_auth)],
):
    """
    Partial update of an organization (RESTful PATCH, RFC 7396 merge-patch semantics).

    A sent field is written and an omitted one is left untouched (presence is read from
    ``model_fields_set``). Clear tokens are per field: budget limits and ``metadata`` clear with
    ``null``, ``models`` with ``[]``, and ``object_permission`` with ``null`` (it merges when sent,
    so an empty ``{}`` is rejected). ``organization_alias`` is required and cannot be cleared.
    Validation failures return 422; the object-permission upsert, budget-row write, and
    org-row write are one transaction.
    """
    from litellm.proxy.proxy_server import prisma_client

    if prisma_client is None:
        raise HTTPException(
            status_code=500,
            detail={"error": CommonProxyErrors.db_not_connected_error.value},
        )

    if user_api_key_dict.user_id is None:
        raise HTTPException(
            status_code=400,
            detail={
                "error": "Cannot associate a user_id to this action. Check `/key/info` to validate if 'user_id' is set."
            },
        )

    if data.max_budget is not None and (not math.isfinite(data.max_budget) or data.max_budget < 0):
        raise HTTPException(
            status_code=422,
            detail={"error": f"max_budget must be a non-negative finite number. Received: {data.max_budget}"},
        )
    if data.soft_budget is not None and (not math.isfinite(data.soft_budget) or data.soft_budget < 0):
        raise HTTPException(
            status_code=422,
            detail={"error": f"soft_budget must be a non-negative finite number. Received: {data.soft_budget}"},
        )
    for limit_name, limit_value in (
        ("tpm_limit", data.tpm_limit),
        ("rpm_limit", data.rpm_limit),
        ("max_parallel_requests", data.max_parallel_requests),
    ):
        if limit_value is not None and limit_value < 0:
            raise HTTPException(
                status_code=422,
                detail={"error": f"{limit_name} must be non-negative. Received: {limit_value}"},
            )
    validate_budget_duration(data.budget_duration, status_code=422)
    if data.model_max_budget:
        from litellm.proxy.management_endpoints.key_management_endpoints import (
            validate_model_max_budget,
        )

        try:
            validate_model_max_budget(data.model_max_budget)
        except ValueError as e:
            raise HTTPException(status_code=422, detail={"error": str(e)})

    if "organization_alias" in data.model_fields_set and data.organization_alias is None:
        raise HTTPException(
            status_code=422,
            detail={"error": "organization_alias cannot be cleared; it is required"},
        )
    if "models" in data.model_fields_set and data.models is None:
        raise HTTPException(
            status_code=422,
            detail={"error": "models cannot be set to null; send [] to clear it"},
        )
    if data.object_permission is not None and not data.object_permission.model_dump(exclude_none=True):
        raise HTTPException(
            status_code=422,
            detail={
                "error": "object_permission cannot be an empty object; send null to clear it, or a non-empty object to set grants"
            },
        )

    await _verify_org_access(
        organization_id=organization_id,
        user_api_key_dict=user_api_key_dict,
        prisma_client=prisma_client,
    )

    existing_organization_row: Final = await _table(OrganizationRepository(prisma_client)).find_unique(
        where={"organization_id": organization_id},
    )
    if existing_organization_row is None:
        raise HTTPException(
            status_code=404,
            detail={"error": f"Organization not found for organization_id={organization_id}"},
        )

    field_values: Final = _STR_OBJECT_DICT_ADAPTER.validate_python(data.model_dump())
    present_fields: Final = data.model_fields_set
    budget_updates: Final = {field: field_values[field] for field in present_fields if field in _BUDGET_SETTABLE_FIELDS}
    org_column_updates: Final[Mapping[str, object]] = {
        **{field: field_values[field] for field in present_fields if field in _ORG_COLUMN_FIELDS},
        **({"metadata": data.metadata or {}} if "metadata" in present_fields else {}),
    }

    object_permission_cleared: Final = "object_permission" in present_fields and data.object_permission is None
    object_permission_upsert: Final = (
        await prepare_object_permission_upsert(
            new_object_permission=data.object_permission.model_dump(exclude_none=True),
            existing_object_permission_id=existing_organization_row.object_permission_id,
            prisma_client=prisma_client,
        )
        if data.object_permission is not None
        else None
    )
    object_permission_write: Final[Mapping[str, object]] = (
        {"object_permission_id": object_permission_upsert.object_permission_id}
        if object_permission_upsert is not None
        else ({"object_permission_id": None} if object_permission_cleared else {})
    )

    organization_write_data: Final = _STR_OBJECT_DICT_ADAPTER.validate_python(
        prisma_client.jsonify_object(
            {
                **org_column_updates,
                **object_permission_write,
                "updated_by": user_api_key_dict.user_id,
            }
        )
    )

    tx_manager: Final[_TransactionManager] = prisma_client.db.tx()
    async with tx_manager as tx:
        if object_permission_upsert is not None:
            await tx.litellm_objectpermissiontable.upsert(
                where={"object_permission_id": object_permission_upsert.object_permission_id},
                data={
                    "create": object_permission_upsert.record,
                    "update": object_permission_upsert.record,
                },
            )
        if budget_updates:
            budget_write_data: Final = _STR_OBJECT_DICT_ADAPTER.validate_python(
                prisma_client.jsonify_object(dict(build_budget_write_data(budget_updates, user_api_key_dict.user_id)))
            )
            await tx.litellm_budgettable.update(
                where={"budget_id": existing_organization_row.budget_id},
                data=budget_write_data,
            )
        response: Final = await tx.litellm_organizationtable.update(
            where={"organization_id": organization_id},
            data=organization_write_data,
            include={"members": True, "teams": True, "litellm_budget_table": True},
        )

    return response


@router.delete(
    "/organization/delete",
    tags=["organization management"],
    dependencies=[Depends(user_api_key_auth)],
    response_model=list[LiteLLM_OrganizationTableWithMembers],
)
async def delete_organization(
    data: DeleteOrganizationRequest,
    user_api_key_dict: UserAPIKeyAuth = Depends(user_api_key_auth),
):
    """
    Delete an organization

    # Parameters:

    - organization_ids: List[str] - The organization ids to delete.
    """
    from litellm.proxy.proxy_server import prisma_client, proxy_logging_obj, user_api_key_cache

    if prisma_client is None:
        raise HTTPException(
            status_code=500,
            detail={"error": CommonProxyErrors.db_not_connected_error.value},
        )

    if user_api_key_dict.user_role != LitellmUserRoles.PROXY_ADMIN:
        raise HTTPException(
            status_code=401,
            detail={"error": "Only proxy admins can delete organizations"},
        )

    deleted_orgs: Final = []
    for organization_id in data.organization_ids:
        # delete all teams in the organization
        await _table(TeamRepository(prisma_client)).delete_many(where={"organization_id": organization_id})
        # delete all members in the organization
        await _table(OrganizationMembershipRepository(prisma_client)).delete_many(
            where={"organization_id": organization_id}
        )
        await _delete_organization_keys(
            organization_id=organization_id,
            prisma_client=prisma_client,
            user_api_key_cache=user_api_key_cache,
            proxy_logging_obj=proxy_logging_obj,
        )
        # delete the organization
        deleted_org = await _table(OrganizationRepository(prisma_client)).delete(
            where={"organization_id": organization_id},
            include={"members": True, "teams": True, "litellm_budget_table": True},
        )
        if deleted_org is None:
            raise HTTPException(
                status_code=404,
                detail={"error": f"Organization={organization_id} not found"},
            )
        deleted_orgs.append(deleted_org)

    return deleted_orgs


async def _delete_organization_keys(
    organization_id: str,
    prisma_client: PrismaClient,
    user_api_key_cache: UserApiKeyCache,
    proxy_logging_obj: ProxyLogging | None,
) -> None:
    key_filter: Final[_OrganizationIdFilter] = {"organization_id": organization_id}
    keys_to_delete: Final = await _table(VerificationTokenRepository(prisma_client)).find_many(where=key_filter)
    hashed_tokens_to_delete: Final = tuple(key.token for key in keys_to_delete)
    jwt_mapping_cache_keys: Final = await get_jwt_key_mapping_cache_keys_for_tokens(
        hashed_tokens=hashed_tokens_to_delete,
        prisma_client=prisma_client,
    )
    await _table(VerificationTokenRepository(prisma_client)).delete_many(where=key_filter)
    await delete_cache_key_objects(
        hashed_tokens=hashed_tokens_to_delete,
        user_api_key_cache=user_api_key_cache,
        proxy_logging_obj=proxy_logging_obj,
    )
    await evict_and_broadcast(cache_keys=jwt_mapping_cache_keys, user_api_key_cache=user_api_key_cache)


@router.get(
    "/organization/list",
    tags=["organization management"],
    dependencies=[Depends(user_api_key_auth)],
    response_model=list[LiteLLM_OrganizationTableWithMembers],
)
async def list_organization(
    org_id: str | None = fastapi.Query(default=None, description="Filter organizations by exact organization_id match"),
    org_alias: str | None = fastapi.Query(
        default=None,
        description="Filter organizations by partial organization_alias match. Supports case-insensitive search.",
    ),
    user_api_key_dict: UserAPIKeyAuth = Depends(user_api_key_auth),
):
    """
    Get a list of organizations with optional filtering.

    Parameters:
        org_id: Optional[str]
            Filter organizations by exact organization_id match
        org_alias: Optional[str]
            Filter organizations by partial organization_alias match (case-insensitive)

    Example:
    ```
    curl --location --request GET 'http://0.0.0.0:4000/organization/list?org_alias=my-org' \
        --header 'Authorization: Bearer sk-1234'
    ```

    Example with org_id:
    ```
    curl --location --request GET 'http://0.0.0.0:4000/organization/list?org_id=123e4567-e89b-12d3-a456-426614174000' \
        --header 'Authorization: Bearer sk-1234'
    ```
    """
    from litellm.proxy.proxy_server import prisma_client

    if prisma_client is None:
        raise HTTPException(status_code=500, detail={"error": "No db connected"})

    if prisma_client is None:
        raise HTTPException(
            status_code=400,
            detail={"error": CommonProxyErrors.db_not_connected_error.value},
        )

    # Build where conditions based on provided filters
    where_conditions: Final[dict[str, object]] = {}

    if org_id:
        where_conditions["organization_id"] = org_id

    if org_alias:
        where_conditions["organization_alias"] = {
            "contains": org_alias,
            "mode": "insensitive",  # Case-insensitive search
        }

    # if proxy admin or admin viewer - get all orgs (with optional filters)
    if _user_has_admin_view(user_api_key_dict):
        response = await _table(OrganizationRepository(prisma_client)).find_many(
            where=where_conditions if where_conditions else None,
            include={"litellm_budget_table": True, "members": True, "teams": True},
        )
    # if internal user - get orgs they are a member of (with optional filters)
    else:
        org_memberships: Final = await _table(OrganizationMembershipRepository(prisma_client)).find_many(
            where={"user_id": user_api_key_dict.user_id}
        )
        membership_org_ids: Final = [membership.organization_id for membership in org_memberships]

        # Combine membership filter with provided filters
        if membership_org_ids:
            if org_id:
                # If org_id is provided, ensure user is a member of that org
                if org_id not in membership_org_ids:
                    # User is not a member of the requested org, return empty list
                    response = []
                else:
                    where_conditions["organization_id"] = org_id
                    response = await _table(OrganizationRepository(prisma_client)).find_many(
                        where=where_conditions,
                        include={
                            "litellm_budget_table": True,
                            "members": True,
                            "teams": True,
                        },
                    )
            else:
                # Filter by membership and any additional filters
                where_conditions["organization_id"] = {"in": membership_org_ids}
                response = await _table(OrganizationRepository(prisma_client)).find_many(
                    where=where_conditions,
                    include={
                        "litellm_budget_table": True,
                        "members": True,
                        "teams": True,
                    },
                )
        else:
            # User is not a member of any orgs
            response = []

    return response


@router.get(
    "/organization/info",
    tags=["organization management"],
    dependencies=[Depends(user_api_key_auth)],
    response_model=LiteLLM_OrganizationTableWithMembers,
)
async def info_organization(
    organization_id: str,
    user_api_key_dict: UserAPIKeyAuth = Depends(user_api_key_auth),
):
    """
    Get the org specific information
    """
    from litellm.proxy.proxy_server import prisma_client

    if prisma_client is None:
        raise HTTPException(status_code=500, detail={"error": "No db connected"})

    # Verify caller has access to this organization
    await _verify_org_access(
        organization_id=organization_id,
        user_api_key_dict=user_api_key_dict,
        prisma_client=prisma_client,
    )

    response: Final = await _table(OrganizationRepository(prisma_client)).find_unique(
        where={"organization_id": organization_id},
        include={
            "litellm_budget_table": True,
            "members": {
                "include": {
                    "user": True,
                }
            },
            "teams": True,
            "object_permission": True,
        },
    )

    if response is None:
        raise HTTPException(status_code=404, detail={"error": "Organization not found"})

    response_pydantic_obj: Final = LiteLLM_OrganizationTableWithMembers.model_validate(response.model_dump())

    return response_pydantic_obj


@router.post(
    "/organization/info",
    tags=["organization management"],
    dependencies=[Depends(user_api_key_auth)],
)
async def deprecated_info_organization(
    data: OrganizationRequest,
    user_api_key_dict: UserAPIKeyAuth = Depends(user_api_key_auth),
):
    """
    DEPRECATED: Use GET /organization/info instead
    """
    from litellm.proxy.proxy_server import prisma_client

    if prisma_client is None:
        raise HTTPException(status_code=500, detail={"error": "No db connected"})

    if len(data.organizations) == 0:
        raise HTTPException(
            status_code=400,
            detail={"error": f"Specify list of organization id's to query. Passed in={data.organizations}"},
        )

    # Verify caller has access to each requested organization
    for org_id in data.organizations:
        await _verify_org_access(
            organization_id=org_id,
            user_api_key_dict=user_api_key_dict,
            prisma_client=prisma_client,
        )

    response: Final = await _table(OrganizationRepository(prisma_client)).find_many(
        where={"organization_id": {"in": data.organizations}},
        include={"litellm_budget_table": True},
    )

    return response


@router.post(
    "/organization/member_add",
    tags=["organization management"],
    dependencies=[Depends(user_api_key_auth)],
    response_model=OrganizationAddMemberResponse,
)
@management_endpoint_wrapper
async def organization_member_add(
    data: OrganizationMemberAddRequest,
    http_request: Request,
    user_api_key_dict: UserAPIKeyAuth = Depends(user_api_key_auth),
) -> OrganizationAddMemberResponse:
    """
    [BETA]

    Add new members (either via user_email or user_id) to an organization

    If user doesn't exist, new user row will also be added to User Table

    Only proxy_admin or org_admin of organization, allowed to access this endpoint.

    # Parameters:

    - organization_id: str (required)
    - member: Union[List[Member], Member] (required)
        - role: Literal[LitellmUserRoles] (required)
        - user_id: Optional[str]
        - user_email: Optional[str]

    Note: Either user_id or user_email must be provided for each member.

    Example:
    ```
    curl -X POST 'http://0.0.0.0:4000/organization/member_add' \
    -H 'Authorization: Bearer sk-1234' \
    -H 'Content-Type: application/json' \
    -d '{
        "organization_id": "45e3e396-ee08-4a61-a88e-16b3ce7e0849",
        "member": {
            "role": "internal_user",
            "user_id": "krrish247652@berri.ai"
        },
        "max_budget_in_organization": 100.0
    }'
    ```

    The following is executed in this function:

    1. Check if organization exists
    2. Creates a new Internal User if the user_id or user_email is not found in LiteLLM_UserTable
    3. Add Internal User to the `LiteLLM_OrganizationMembership` table
    """
    try:
        from litellm.proxy.proxy_server import prisma_client

        if prisma_client is None:
            raise HTTPException(status_code=500, detail={"error": "No db connected"})

        # IDOR guard: docstring says "Only proxy_admin or org_admin of
        # organization, allowed to access this endpoint" — but the code
        # never enforced that. Any authenticated key holder could add
        # members to any org. Now gated explicitly.
        await _verify_org_access(
            organization_id=data.organization_id,
            user_api_key_dict=user_api_key_dict,
            prisma_client=prisma_client,
        )

        # Check if organization exists
        existing_organization_row: Final = await _table(OrganizationRepository(prisma_client)).find_unique(
            where={"organization_id": data.organization_id}
        )
        if existing_organization_row is None:
            raise HTTPException(
                status_code=404,
                detail={
                    "error": f"Organization not found for organization_id={getattr(data, 'organization_id', None)}"
                },
            )

        members: Sequence[OrgMember]
        if isinstance(data.member, list):
            members = data.member
        else:
            members = [data.member]

        updated_users: Final[list[LiteLLM_UserTable]] = []
        updated_organization_memberships: Final[list[LiteLLM_OrganizationMembershipTable]] = []

        for member in members:
            (
                updated_user,
                updated_organization_membership,
            ) = await add_member_to_organization(
                member=member,
                organization_id=data.organization_id,
                prisma_client=prisma_client,
            )

            updated_users.append(updated_user)
            updated_organization_memberships.append(updated_organization_membership)

        return OrganizationAddMemberResponse(
            organization_id=data.organization_id,
            updated_users=updated_users,
            updated_organization_memberships=updated_organization_memberships,
        )
    except Exception as e:
        verbose_proxy_logger.exception("Error adding member to organization: %s", e)
        if isinstance(e, HTTPException):
            raise ProxyException(
                message=getattr(e, "detail", f"Authentication Error({e})"),
                type=ProxyErrorTypes.auth_error,
                param=getattr(e, "param", "None"),
                code=getattr(e, "status_code", status.HTTP_500_INTERNAL_SERVER_ERROR),
            )
        elif isinstance(e, ProxyException):
            raise e
        raise ProxyException(
            message="Authentication Error, " + str(e),
            type=ProxyErrorTypes.auth_error,
            param=getattr(e, "param", "None"),
            code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        )


async def find_member_if_email(user_email: str, prisma_client: PrismaClient) -> LiteLLM_UserTable:
    """
    Find a member if the user_email is in LiteLLM_UserTable
    """

    not_unique_user_email_error: Final = HTTPException(
        status_code=400,
        detail={
            "error": f"Unique user not found for user_email={user_email}. Potential duplicate OR non-existent user_email in LiteLLM_UserTable. Use 'user_id' instead."
        },
    )
    try:
        existing_user_email_row: Final = await UserRepository(prisma_client).table.find_unique(
            where={"user_email": user_email}
        )
    except Exception:
        raise not_unique_user_email_error
    if existing_user_email_row is None:
        raise not_unique_user_email_error
    existing_user_email_row_pydantic: Final = LiteLLM_UserTable.model_validate(existing_user_email_row.model_dump())
    return existing_user_email_row_pydantic


@router.patch(
    "/organization/member_update",
    tags=["organization management"],
    dependencies=[Depends(user_api_key_auth)],
    response_model=LiteLLM_OrganizationMembershipTable,
)
@management_endpoint_wrapper
async def organization_member_update(
    data: OrganizationMemberUpdateRequest,
    user_api_key_dict: UserAPIKeyAuth = Depends(user_api_key_auth),
):
    """
    Update a member's role in an organization
    """
    try:
        from litellm.proxy.proxy_server import prisma_client

        if prisma_client is None:
            raise HTTPException(
                status_code=500,
                detail={"error": CommonProxyErrors.db_not_connected_error.value},
            )

        # IDOR guard: only proxy admins / org admins of THIS org may
        # update member roles. The PROXY_ADMIN-target check below was
        # the only access control; without this, any authenticated user
        # could change any non-admin member's role in any org.
        await _verify_org_access(
            organization_id=data.organization_id,
            user_api_key_dict=user_api_key_dict,
            prisma_client=prisma_client,
        )

        # Check if organization exists
        existing_organization_row: Final = await _table(OrganizationRepository(prisma_client)).find_unique(
            where={"organization_id": data.organization_id}
        )
        if existing_organization_row is None:
            raise HTTPException(
                status_code=400,
                detail={
                    "error": f"Organization not found for organization_id={getattr(data, 'organization_id', None)}"
                },
            )

        # Check if member exists in organization
        if data.user_email is not None and data.user_id is None:
            existing_user_email_row: Final = await find_member_if_email(data.user_email, prisma_client)
            data.user_id = existing_user_email_row.user_id

        try:
            existing_organization_membership: Final = await _table(
                OrganizationMembershipRepository(prisma_client)
            ).find_unique(
                where={
                    "user_id_organization_id": {
                        "user_id": data.user_id,
                        "organization_id": data.organization_id,
                    }
                }
            )
        except Exception as e:
            raise HTTPException(
                status_code=400,
                detail={
                    "error": f"Error finding organization membership for user_id={data.user_id} in organization={data.organization_id}: {e}"
                },
            )
        if existing_organization_membership is None:
            raise HTTPException(
                status_code=404,
                detail={"error": f"Member not found in organization for user_id={data.user_id}"},
            )

        # Reject attempts to change the role of a global PROXY_ADMIN via
        # org-scoped operations. An org-admin of any org could otherwise
        # alter a PROXY_ADMIN user's per-org role, which has downstream
        # effects on admin UI filtering and scope derivation.
        target_user_row = await _table(UserRepository(prisma_client)).find_unique(where={"user_id": data.user_id})
        if target_user_row is not None and getattr(target_user_row, "user_role", None) in (
            LitellmUserRoles.PROXY_ADMIN.value,
            LitellmUserRoles.PROXY_ADMIN_VIEW_ONLY.value,
        ):
            if user_api_key_dict.user_role != LitellmUserRoles.PROXY_ADMIN.value:
                raise HTTPException(
                    status_code=403,
                    detail={
                        "error": (
                            "Only PROXY_ADMIN may modify the organization role of a user who is a global PROXY_ADMIN."
                        )
                    },
                )

        # Update member role
        if data.role is not None:
            await _table(OrganizationMembershipRepository(prisma_client)).update(
                where={
                    "user_id_organization_id": {
                        "user_id": data.user_id,
                        "organization_id": data.organization_id,
                    }
                },
                data={"user_role": data.role},
            )
        if data.max_budget_in_organization is not None:
            # if budget_id is None, create a new budget
            budget_id: Final = existing_organization_membership.budget_id or str(uuid.uuid4())
            if existing_organization_membership.budget_id is None:
                new_budget_obj = BudgetNewRequest(budget_id=budget_id, max_budget=data.max_budget_in_organization)
                await new_budget(budget_obj=new_budget_obj, user_api_key_dict=user_api_key_dict)
            else:
                # update budget table with new max_budget
                await update_budget(
                    budget_obj=BudgetNewRequest(budget_id=budget_id, max_budget=data.max_budget_in_organization),
                    user_api_key_dict=user_api_key_dict,
                )

            # update organization membership with new budget_id
            await _table(OrganizationMembershipRepository(prisma_client)).update(
                where={
                    "user_id_organization_id": {
                        "user_id": data.user_id,
                        "organization_id": data.organization_id,
                    }
                },
                data={"budget_id": budget_id},
            )
        final_organization_membership = await _table(OrganizationMembershipRepository(prisma_client)).find_unique(
            where={
                "user_id_organization_id": {
                    "user_id": data.user_id,
                    "organization_id": data.organization_id,
                }
            },
            include={"litellm_budget_table": True},
        )

        if final_organization_membership is None:
            raise HTTPException(
                status_code=400,
                detail={"error": f"Member not found in organization={data.organization_id} for user_id={data.user_id}"},
            )

        final_organization_membership_pydantic: Final = LiteLLM_OrganizationMembershipTable.model_validate(
            final_organization_membership.model_dump(exclude_none=True)
        )
        return final_organization_membership_pydantic
    except Exception as e:
        verbose_proxy_logger.exception("Error updating member in organization: %s", e)
        raise e


@router.delete(
    "/organization/member_delete",
    tags=["organization management"],
    dependencies=[Depends(user_api_key_auth)],
)
async def organization_member_delete(
    data: OrganizationMemberDeleteRequest,
    user_api_key_dict: UserAPIKeyAuth = Depends(user_api_key_auth),
):
    """
    Delete a member from an organization
    """
    try:
        from litellm.proxy.proxy_server import prisma_client

        if prisma_client is None:
            raise HTTPException(
                status_code=500,
                detail={"error": CommonProxyErrors.db_not_connected_error.value},
            )

        # IDOR guard: only proxy admins / org admins of THIS org may
        # delete members. Without this, any authenticated key holder
        # could remove any user from any org.
        await _verify_org_access(
            organization_id=data.organization_id,
            user_api_key_dict=user_api_key_dict,
            prisma_client=prisma_client,
        )

        if data.user_email is not None and data.user_id is None:
            existing_user_email_row: Final = await find_member_if_email(data.user_email, prisma_client)
            data.user_id = existing_user_email_row.user_id

        member_to_delete: Final = await _table(OrganizationMembershipRepository(prisma_client)).delete(
            where={
                "user_id_organization_id": {
                    "user_id": data.user_id,
                    "organization_id": data.organization_id,
                }
            }
        )
        return member_to_delete

    except Exception as e:
        verbose_proxy_logger.exception("Error deleting member from organization: %s", e)
        raise e


async def add_member_to_organization(
    member: OrgMember,
    organization_id: str,
    prisma_client: PrismaClient,
) -> tuple[LiteLLM_UserTable, LiteLLM_OrganizationMembershipTable]:
    """
    Add a member to an organization

    - Checks if member.user_id or member.user_email is in LiteLLM_UserTable
    - If not found, create a new user in LiteLLM_UserTable
    - Add user to organization in LiteLLM_OrganizationMembership
    """

    try:
        user_object: LiteLLM_UserTable | None = None
        existing_user_id_row = None
        existing_user_email_row = None
        ## Check if user exists in LiteLLM_UserTable - user exists - either the user_id or user_email is in LiteLLM_UserTable
        if member.user_id is not None:
            existing_user_id_row = await _table(UserRepository(prisma_client)).find_unique(
                where={"user_id": member.user_id}
            )

        if existing_user_id_row is None and member.user_email is not None:
            try:
                existing_user_email_row = await UserRepository(prisma_client).table.find_unique(
                    where={"user_email": member.user_email}
                )
            except Exception as e:
                raise ValueError(
                    f"Potential NON-Existent or Duplicate user email in DB: Error finding a unique instance of user_email={member.user_email} in LiteLLM_UserTable.: {e}"
                )

        ## If user does not exist, create a new user
        if existing_user_id_row is None and existing_user_email_row is None:
            # Create a new user - since user does not exist
            user_id: Final[str] = member.user_id or str(uuid.uuid4())
            new_user_defaults: Final = get_new_internal_user_defaults(
                user_id=user_id,
                user_email=member.user_email,
            )

            _returned_user = await prisma_client.insert_data(data=new_user_defaults, table_name="user")
            if _returned_user is not None:
                user_object = LiteLLM_UserTable.model_validate(_returned_user.model_dump())
        elif existing_user_email_row is not None and (
            len(existing_user_email_row)  # pyright: ignore[reportArgumentType]  # find_unique yields a row, not a list
            > 1
        ):
            raise HTTPException(
                status_code=400,
                detail={"error": "Multiple users with this email found in db. Please use 'user_id' instead."},
            )
        elif existing_user_email_row is not None:
            user_object = LiteLLM_UserTable.model_validate(existing_user_email_row.model_dump())
        elif existing_user_id_row is not None:
            user_object = LiteLLM_UserTable.model_validate(existing_user_id_row.model_dump())
        else:
            raise HTTPException(
                status_code=404,
                detail={"error": f"User not found for user_id={member.user_id} and user_email={member.user_email}"},
            )

        if user_object is None:
            raise ValueError(
                f"User does not exist in LiteLLM_UserTable. user_id={member.user_id} and user_email={member.user_email}"
            )

        # Add user to organization
        _organization_membership: Final = await _table(OrganizationMembershipRepository(prisma_client)).create(
            data={
                "organization_id": organization_id,
                "user_id": user_object.user_id,
                "user_role": member.role,
            }
        )
        organization_membership: Final = LiteLLM_OrganizationMembershipTable.model_validate(
            _organization_membership.model_dump()
        )
        return user_object, organization_membership

    except Exception as e:
        raise ValueError(f"Error adding member={member} to organization={organization_id}: {e}")
