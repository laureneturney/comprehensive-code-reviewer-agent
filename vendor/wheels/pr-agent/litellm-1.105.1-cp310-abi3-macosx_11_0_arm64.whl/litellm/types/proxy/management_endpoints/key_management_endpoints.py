from datetime import datetime
from typing import Any, Final, Literal, TypeAlias

from pydantic import BaseModel, ConfigDict, model_validator
from typing_extensions import ReadOnly, TypedDict

from litellm.models.verification_token import LiteLLM_VerificationToken
from litellm.proxy._types import (
    GenerateKeyRequest,
    LiteLLM_ObjectPermissionBase,
    RegenerateKeyRequest,
    UpdateKeyRequest,
)
from litellm.types.llms.base import LiteLLMPydanticObjectBase
from litellm.types.proxy.management_endpoints.internal_user_endpoints import InsensitiveContains


class KeyTokenWhere(TypedDict):
    token: ReadOnly[str]


class KeyAliasContainsWhere(TypedDict):
    key_alias: ReadOnly[InsensitiveContains]


class KeySearchWhere(TypedDict):
    """Prisma filter behind `/key/list?search=`: exact token or case-insensitive alias substring."""

    OR: ReadOnly[tuple[KeyTokenWhere, KeyAliasContainsWhere]]


class BulkUpdateKeyRequestItem(BaseModel):
    """One /key/bulk_update item; only the fields it carries are written."""

    key: str  # Key identifier (token)
    budget_id: str | None = None  # Budget ID associated with the key
    max_budget: float | None = None  # Max budget for key
    team_id: str | None = None  # Team ID associated with key
    tags: list[str] | None = None  # Tags for organizing keys
    object_permission: LiteLLM_ObjectPermissionBase | None = None


class BulkUpdateKeyRequest(BaseModel):
    """Request for bulk key updates"""

    keys: list[BulkUpdateKeyRequestItem]


class SuccessfulKeyUpdate(BaseModel):
    """Successfully updated key with its updated information"""

    key: str
    key_info: dict[str, Any]


class FailedKeyUpdate(BaseModel):
    """Failed key update with reason"""

    key: str
    key_info: dict[str, Any] | None = None
    failed_reason: str


class BulkUpdateKeyResponse(BaseModel):
    """Response for bulk key update operations"""

    total_requested: int
    successful_updates: list[SuccessfulKeyUpdate]
    failed_updates: list[FailedKeyUpdate]


class KeyUpdateFields(BaseModel):
    """Allowlist of bulk-broadcastable fields for /team/key/bulk_update; `extra="forbid"` blocks RBAC/ownership/scope mutations even by team admins."""

    model_config = ConfigDict(extra="forbid", protected_namespaces=())

    # Budgets
    max_budget: float | None = None
    budget_id: str | None = None
    budget_duration: str | None = None
    budget_limits: list[Any] | None = None
    model_max_budget: dict[str, Any] | None = None

    # Rate limits
    tpm_limit: int | None = None
    rpm_limit: int | None = None
    model_tpm_limit: dict[str, Any] | None = None
    model_rpm_limit: dict[str, Any] | None = None
    max_parallel_requests: int | None = None
    rpm_limit_type: Literal["guaranteed_throughput", "best_effort_throughput", "dynamic"] | None = None
    tpm_limit_type: Literal["guaranteed_throughput", "best_effort_throughput", "dynamic"] | None = None

    # Temporary budget grants (auto-expire). `spend` deliberately omitted — bulk-zeroing it bypasses budget enforcement; admin-only via /key/update.
    temp_budget_increase: float | None = None
    temp_budget_expiry: datetime | None = None

    # Expiry
    duration: str | None = None

    # Operational metadata
    tags: list[str] | None = None
    metadata: dict[str, Any] | None = None

    @model_validator(mode="after")
    def validate_temp_budget(self) -> "KeyUpdateFields":
        if self.temp_budget_increase is not None or self.temp_budget_expiry is not None:
            if self.temp_budget_increase is None or self.temp_budget_expiry is None:
                raise ValueError("temp_budget_increase and temp_budget_expiry must be set together")
        return self

    @model_validator(mode="after")
    def require_at_least_one_field(self) -> "KeyUpdateFields":
        # Reject empty payload — would iterate every key with no-op writes.
        if not self.model_fields_set:
            raise ValueError("update_fields must specify at least one field to update.")
        return self


class BulkUpdateTeamKeysRequest(BaseModel):
    """Apply one update payload to many keys inside a team; provide either `key_ids` or `all_keys_in_team=True`."""

    team_id: str
    key_ids: list[str] | None = None
    all_keys_in_team: bool = False
    update_fields: KeyUpdateFields

    @model_validator(mode="after")
    def validate_selection(self) -> "BulkUpdateTeamKeysRequest":
        has_key_ids: Final = self.key_ids is not None and len(self.key_ids) > 0
        if has_key_ids and self.all_keys_in_team:
            raise ValueError("Provide either `key_ids` or `all_keys_in_team=True`, not both.")
        if not has_key_ids and not self.all_keys_in_team:
            raise ValueError("Must provide either `key_ids` (non-empty) or `all_keys_in_team=True`.")
        return self


CustomKeyPolicyOperation: TypeAlias = Literal["generate", "update", "regenerate"]


class CustomKeyPolicyRequest(LiteLLMPydanticObjectBase):
    """What `general_settings.custom_key_policy` receives.

    `effective_key` is the verification token row as it will be written: the existing row overlaid with the
    requested changes, with `duration` resolved to `expires` and `budget_duration` to `budget_reset_at`. Values the
    proxy fills in after the policy stay at their defaults: `token`, `key_name`, `created_by`, `updated_by` and the
    soft-budget `budget_id` on generate, the rotated token on regenerate, and the `object_permission` relation on
    every operation (`object_permission_id` is set; read `request.object_permission` for the requested change).
    """

    model_config = ConfigDict(protected_namespaces=(), frozen=True)

    operation: CustomKeyPolicyOperation
    existing_key: LiteLLM_VerificationToken | None
    effective_key: LiteLLM_VerificationToken
    request: GenerateKeyRequest | UpdateKeyRequest | RegenerateKeyRequest
