from typing import Literal

from pydantic import Field

from .base import GuardrailConfigModel


class PanwPrismaAirsGuardrailConfigModel(GuardrailConfigModel):
    api_key: str | None = Field(
        default=None,
        description="The API key for the PANW Prisma AIRS guardrail. If not provided, the `PANW_PRISMA_AIRS_API_KEY` environment variable is checked.",
    )
    api_base: str | None = Field(
        default=None,
        description="The API base for the PANW Prisma AIRS guardrail. Defaults to https://service.api.aisecurity.paloaltonetworks.com. If not provided, the `PANW_PRISMA_AIRS_API_BASE` environment variable is checked.",
    )

    profile_name: str | None = Field(
        default=None,
        description="PANW Prisma AIRS security profile name configured in Strata Cloud Manager. Optional if API key has a linked profile.",
    )

    app_name: str | None = Field(
        default=None,
        description="Application name for tracking this LiteLLM instance in Prisma AIRS analytics and dashboards. Defaults to 'LiteLLM' if not specified.",
    )

    mask_on_block: bool = Field(
        default=False,
        description="Backwards compatible flag that enables both request and response masking. When True, enables both mask_request_content and mask_response_content.",
    )

    mask_request_content: bool = Field(
        default=False,
        description="Apply masking to prompts that would be blocked. When True, masked content is sent to the LLM instead of blocking the request.",
    )

    mask_response_content: bool = Field(
        default=False,
        description="Apply masking to responses that would be blocked. When True, masked content is returned to the user instead of blocking the response.",
    )

    fallback_on_error: Literal["block", "allow"] = Field(
        default="block",
        description="Action when PANW API is unavailable (timeout, rate limit, network error): 'block' (default, maximum security) rejects requests; 'allow' (high availability) proceeds without scanning. Authentication and configuration errors always block.",
    )

    timeout: float = Field(
        default=10.0,
        ge=1.0,
        le=60.0,
        description="PANW API call timeout in seconds (1-60).",
    )

    experimental_use_latest_role_message_only: bool | None = Field(
        default=None,
        description="Scan only the latest user/developer message on the request side instead of "
        "the full conversation history. Set true to enable for every request shape (chat completions, "
        "Anthropic /v1/messages, /v1/responses); set false to always scan all user/system/developer "
        "messages. When unset: latest-only for Anthropic /v1/messages, full history otherwise. "
        "Latest-only trusts caller-supplied history: earlier turns are not rescanned, so enable it only "
        "where each turn was scanned when it was the latest message or history is server-controlled.",
    )

    @staticmethod
    def ui_friendly_name() -> str:
        return "PANW Prisma AIRS"
