from typing import TYPE_CHECKING, Final

from litellm.types.guardrails import SupportedGuardrailIntegrations

from .prompt_security import PromptSecurityGuardrail

if TYPE_CHECKING:
    from litellm.types.guardrails import Guardrail, LitellmParams


def initialize_guardrail(litellm_params: "LitellmParams", guardrail: "Guardrail"):
    import litellm
    from litellm.proxy.guardrails.guardrail_hooks.prompt_security import (
        PromptSecurityGuardrail,
    )

    _prompt_security_callback: Final = PromptSecurityGuardrail(
        api_base=litellm_params.api_base,
        api_key=litellm_params.api_key,
        guardrail_name=guardrail.get("guardrail_name", ""),
        event_hook=litellm_params.mode,
        default_on=litellm_params.default_on,
        streaming_transform_mode=getattr(litellm_params, "streaming_transform_mode", None),
        file_sanitization_fail_open=getattr(litellm_params, "file_sanitization_fail_open", None),
        block_on_file_modify=getattr(litellm_params, "block_on_file_modify", None),
        timeout=litellm_params.timeout,
    )
    litellm.logging_callback_manager.add_litellm_callback(_prompt_security_callback)

    return _prompt_security_callback


guardrail_initializer_registry: Final = {
    SupportedGuardrailIntegrations.PROMPT_SECURITY.value: initialize_guardrail,
}


guardrail_class_registry: Final = {
    SupportedGuardrailIntegrations.PROMPT_SECURITY.value: PromptSecurityGuardrail,
}
