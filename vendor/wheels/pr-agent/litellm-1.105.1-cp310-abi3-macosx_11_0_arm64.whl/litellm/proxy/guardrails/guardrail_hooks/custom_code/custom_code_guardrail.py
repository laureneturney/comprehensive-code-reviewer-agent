"""
Custom code guardrail for LiteLLM.

This module provides a guardrail that executes user-defined Python-like code
to implement custom guardrail logic. The code runs in a sandboxed environment
with access to LiteLLM-provided primitives for common guardrail operations.

Example custom code (sync):

    def apply_guardrail(inputs, request_data, input_type):
        '''Block messages containing SSNs'''
        for text in inputs["texts"]:
            if regex_match(text, r"\\d{3}-\\d{2}-\\d{4}"):
                return block("Social Security Number detected")
        return allow()

Example custom code (async with HTTP):

    async def apply_guardrail(inputs, request_data, input_type):
        '''Call external moderation API'''
        for text in inputs["texts"]:
            response = await http_post(
                "https://api.example.com/moderate",
                body={"text": text}
            )
            if response["success"] and response["body"].get("flagged"):
                return block("Content flagged by moderation API")
        return allow()

Example: block when response rejects the user (input_type response only):

    Use RESPONSE_REJECTION_GUARDRAIL_CODE from .response_rejection_code — it
    checks response texts for phrases like "That's not something I can help with"
    and returns block() so the guardrail raises a block error.
"""

import asyncio
import functools
import inspect
import threading
import time
from collections.abc import Callable, Mapping
from types import MappingProxyType
from typing import TYPE_CHECKING, Final, Literal, Optional, cast

from fastapi import HTTPException
from pydantic import Field
from typing_extensions import TypedDict, Unpack

from litellm._logging import verbose_proxy_logger
from litellm.exceptions import ModifyResponseException
from litellm.integrations.custom_guardrail import (
    CustomGuardrail,
    log_guardrail_information,
)
from litellm.types.guardrails import GuardrailEventHooks
from litellm.types.proxy.guardrails.guardrail_hooks.base import GuardrailConfigModel
from litellm.types.utils import GenericGuardrailAPIInputs

from .bounded_execution import (
    ExecutionTimeoutError,
    await_with_timeout,
    call_off_loop_with_timeout,
    call_with_timeout,
)
from .sandbox import build_sandbox_globals, compile_sandboxed

if TYPE_CHECKING:
    from litellm.litellm_core_utils.litellm_logging import Logging as LiteLLMLoggingObj

DEFAULT_EXECUTION_TIMEOUT_SECONDS: Final = 30.0


def _metadata_bucket(request_data: Mapping[str, object], key: str) -> Mapping[str, object]:
    bucket: Final = request_data.get(key)
    return bucket if isinstance(bucket, Mapping) else {}


class CustomCodeGuardrailError(Exception):
    """Raised when custom code guardrail execution fails."""

    def __init__(self, message: str, details: Mapping[str, object] | None = None) -> None:
        super().__init__(message)
        self.details: Mapping[str, object] = details or {}


class CustomCodeCompilationError(CustomCodeGuardrailError):
    """Raised when custom code fails to compile. Deliberately not a ValueError: a config-file guardrail whose
    code does not compile must stop startup instead of being skipped, so the guardrail endpoints catch it by name."""


class CustomCodeExecutionError(CustomCodeGuardrailError):
    """Raised when custom code fails during execution."""


class _CustomGuardrailOptions(TypedDict, total=False, extra_items=object):
    """Base-class constructor options this guardrail forwards untouched to CustomGuardrail."""


class CustomCodeGuardrailConfigModel(GuardrailConfigModel):
    """Configuration parameters for the custom code guardrail."""

    custom_code: str
    """The Python-like code containing the apply_guardrail function."""

    timeout: float | None = Field(
        default=DEFAULT_EXECUTION_TIMEOUT_SECONDS,
        gt=0.0,
        description=(
            "Wall-clock limit in seconds for one run of apply_guardrail, module-level code included. "
            "A run that exceeds it fails the request instead of stalling the proxy."
        ),
    )


class CustomCodeGuardrail(CustomGuardrail):
    """
    Guardrail that executes user-defined Python-like code.

    The code runs in a sandboxed environment that provides:
    - Access to LiteLLM primitives (regex_match, json_parse, etc.)
    - No file I/O; network access only through `http_get`/`http_post`/`http_request`, which refuse
      private, link-local and loopback destinations unless the host is allowlisted
    - No imports allowed

    Users write an `apply_guardrail(inputs, request_data, input_type)` function
    that returns one of:
    - allow() - let the request/response through
    - block(reason) - reject with a message
    - flag(reason) - let it through but log a non-blocking violation
    - modify(texts=...) - transform the content

    Example:
        def apply_guardrail(inputs, request_data, input_type):
            for text in inputs["texts"]:
                if regex_match(text, r"password"):
                    return block("Sensitive content detected")
            return allow()
    """

    def __init__(
        self,
        custom_code: str,
        guardrail_name: str | None = "custom_code",
        execution_timeout: float | None = None,
        **kwargs: Unpack[_CustomGuardrailOptions],
    ) -> None:
        """
        Initialize the custom code guardrail.

        Args:
            custom_code: The source code containing apply_guardrail function
            guardrail_name: Name of this guardrail instance
            execution_timeout: Wall-clock budget in seconds for one run of the code
            **kwargs: Additional arguments passed to CustomGuardrail
        """
        if execution_timeout is not None and not execution_timeout > 0:
            raise ValueError(f"execution_timeout must be positive, got {execution_timeout}")
        self.custom_code: str = custom_code
        self.execution_timeout: float = (
            DEFAULT_EXECUTION_TIMEOUT_SECONDS if execution_timeout is None else execution_timeout
        )
        self._compiled_function: Callable[..., object] | None = None
        self._compile_lock = threading.Lock()
        self._compile_error: str | None = None

        super().__init__(
            guardrail_name=guardrail_name,
            supported_event_hooks=list(self.get_supported_event_hooks()),
            **kwargs,
        )

        # Compile the code on initialization
        self._compile_custom_code()

    @staticmethod
    def get_config_model() -> type[GuardrailConfigModel] | None:
        """Returns the config model for the UI."""
        return CustomCodeGuardrailConfigModel

    @classmethod
    def get_supported_event_hooks(cls) -> list[GuardrailEventHooks]:
        return [
            GuardrailEventHooks.pre_call,
            GuardrailEventHooks.during_call,
            GuardrailEventHooks.post_call,
            GuardrailEventHooks.pre_mcp_call,
            GuardrailEventHooks.during_mcp_call,
            GuardrailEventHooks.logging_only,
        ]

    def _do_compile(self) -> None:
        """Internal compilation method without lock. Expected to run inside _compile_lock."""
        exec_globals: Final = build_sandbox_globals()
        compiled: Final = compile_sandboxed(self.custom_code)

        def load_module() -> None:
            exec(compiled, exec_globals)  # noqa: S102

        call_with_timeout(load_module, self.execution_timeout, label=f"{self.guardrail_name}:load")

        if "apply_guardrail" not in exec_globals:
            raise CustomCodeCompilationError(
                "Custom code must define an 'apply_guardrail' function. "
                "Expected signature: apply_guardrail(inputs, request_data, input_type)"
            )

        apply_fn: Final = exec_globals["apply_guardrail"]
        if not callable(apply_fn):
            raise CustomCodeCompilationError("'apply_guardrail' must be a callable function")

        self._compiled_function = apply_fn

    def _compile_custom_code(self) -> None:
        """
        Compile the custom code and extract the apply_guardrail function.

        The code runs in a sandboxed environment with only the allowed primitives.
        """
        with self._compile_lock:
            if self._compiled_function is not None:
                return

            try:
                self._do_compile()
                verbose_proxy_logger.debug("Custom code guardrail '%s' compiled successfully", self.guardrail_name)

            except SyntaxError as e:
                self._compile_error = f"Syntax error in custom code: {e}"
                raise CustomCodeCompilationError(self._compile_error) from e
            except CustomCodeCompilationError:
                raise
            except Exception as e:
                self._compile_error = f"Failed to compile custom code: {e}"
                raise CustomCodeCompilationError(self._compile_error) from e

    @log_guardrail_information
    async def apply_guardrail(
        self,
        inputs: GenericGuardrailAPIInputs,
        request_data: dict[str, object],
        input_type: Literal["request", "response"],
        logging_obj: Optional["LiteLLMLoggingObj"] = None,
    ) -> GenericGuardrailAPIInputs:
        """
        Apply the custom code guardrail to the inputs.

        This method calls the user-defined apply_guardrail function and
        processes its result to determine the appropriate action.

        The user-defined function can be either sync or async:
        - Sync: def apply_guardrail(inputs, request_data, input_type): ...
        - Async: async def apply_guardrail(inputs, request_data, input_type): ...

        Async functions are recommended when using http_request, http_get, or
        http_post primitives to avoid blocking the event loop.

        Args:
            inputs: Dictionary containing texts, images, tool_calls
            request_data: The original request data with metadata
            input_type: "request" for pre-call, "response" for post-call
            logging_obj: Optional logging object

        Returns:
            GenericGuardrailAPIInputs - possibly modified

        Raises:
            HTTPException: If content is blocked
            CustomCodeExecutionError: If execution fails
        """
        if self._compiled_function is None:
            if self._compile_error:
                raise CustomCodeExecutionError(f"Custom code guardrail not compiled: {self._compile_error}")
            raise CustomCodeExecutionError("Custom code guardrail not compiled")

        start_time: Final = time.time()
        try:
            safe_request_data: Final = self._prepare_safe_request_data(request_data)
            resolved_result: Final = await self._call_compiled(
                self._compiled_function, inputs, safe_request_data, input_type
            )
            return self._process_result(
                result=resolved_result,
                inputs=inputs,
                request_data=request_data,
                input_type=input_type,
                start_time=start_time,
            )

        except HTTPException:
            # Re-raise HTTP exceptions (from block action)
            raise
        except ModifyResponseException:
            # Pre-call block uses passthrough; must not wrap as execution error (500)
            raise
        except ExecutionTimeoutError:
            verbose_proxy_logger.error(
                "Custom code guardrail '%s' exceeded its %gs execution timeout",
                self.guardrail_name,
                self.execution_timeout,
            )
            raise CustomCodeExecutionError(
                f"Custom code guardrail '{self.guardrail_name}' exceeded its "
                f"{self.execution_timeout:g}s execution timeout",
                details=MappingProxyType(
                    {"guardrail_name": self.guardrail_name, "input_type": input_type, "timeout": self.execution_timeout}
                ),
            ) from None
        except Exception as e:
            verbose_proxy_logger.error("Custom code guardrail '%s' execution error: %s", self.guardrail_name, e)
            raise CustomCodeExecutionError(
                f"Custom code guardrail execution failed: {e}",
                details={
                    "guardrail_name": self.guardrail_name,
                    "input_type": input_type,
                },
            ) from e

    async def _call_compiled(
        self,
        compiled_function: Callable[..., object],
        inputs: GenericGuardrailAPIInputs,
        safe_request_data: Mapping[str, object],
        input_type: Literal["request", "response"],
    ) -> object:
        """Run the user's function under the execution budget.

        A coroutine function is awaited on the event loop, so the budget bounds it at its
        await points and it is given up at the deadline even if it swallows cancellation. A
        plain function runs on a worker thread, which keeps a busy loop from stalling every
        other request and lets the runner interrupt it at the deadline.
        """
        label: Final = str(self.guardrail_name)
        if inspect.iscoroutinefunction(compiled_function):
            pending: Final = compiled_function(inputs, safe_request_data, input_type)
            return await await_with_timeout(pending, self.execution_timeout, label)
        call: Final = functools.partial(compiled_function, inputs, safe_request_data, input_type)
        deadline: Final = time.monotonic() + self.execution_timeout
        raw_result: Final = await call_off_loop_with_timeout(call, self.execution_timeout, label)
        if not asyncio.iscoroutine(raw_result):
            return raw_result
        return await await_with_timeout(raw_result, max(deadline - time.monotonic(), 0.0), label)

    def _prepare_safe_request_data(self, request_data: Mapping[str, object]) -> dict[str, object]:
        """
        Prepare a safe subset of request_data for code execution.

        This filters out sensitive information and provides only what's
        needed for guardrail logic.

        Args:
            request_data: The full request data

        Returns:
            Safe subset of request data
        """
        metadata: Final = {
            **_metadata_bucket(request_data, "metadata"),
            **_metadata_bucket(request_data, "litellm_metadata"),
        }
        return {
            "model": request_data.get("model"),
            "user_id": metadata.get("user_api_key_user_id"),
            "team_id": metadata.get("user_api_key_team_id"),
            "end_user_id": metadata.get("user_api_key_end_user_id"),
            "metadata": metadata,
        }

    def _process_result(
        self,
        result: object,
        inputs: GenericGuardrailAPIInputs,
        request_data: dict[str, object],
        input_type: Literal["request", "response"],
        start_time: float,
    ) -> GenericGuardrailAPIInputs:
        """
        Process the result from the custom code function.

        Args:
            result: The return value from apply_guardrail
            inputs: The original inputs
            request_data: The request data
            input_type: "request" or "response"
            start_time: Unix timestamp of when the guardrail started running, used for the flagged log entry

        Returns:
            GenericGuardrailAPIInputs - possibly modified

        Raises:
            HTTPException: If action is "block"
        """
        if not isinstance(result, dict):
            verbose_proxy_logger.warning(
                "Custom code guardrail '%s': Expected dict result, got %s. Treating as allow.",
                self.guardrail_name,
                type(result).__name__,
            )
            return inputs

        action: Final = result.get("action", "allow")

        if action == "allow":
            verbose_proxy_logger.debug("Custom code guardrail '%s': Allowing %s", self.guardrail_name, input_type)
            return inputs

        elif action == "block":
            reason: Final = result.get("reason", "Blocked by custom code guardrail")
            detection_info: Final = result.get("detection_info", {})

            verbose_proxy_logger.info(
                "Custom code guardrail '%s': Blocking %s - %s", self.guardrail_name, input_type, reason
            )

            is_output: Final = input_type == "response"

            # For pre-call, raise passthrough exception to return synthetic response
            if not is_output:
                self.raise_passthrough_exception(
                    violation_message=reason,
                    request_data=request_data,
                    detection_info=detection_info,
                )

            # For post-call, raise HTTP exception
            raise HTTPException(
                status_code=400,
                detail={
                    "error": reason,
                    "guardrail": self.guardrail_name,
                    "detection_info": detection_info,
                },
            )

        elif action == "flag":
            flag_reason: Final = result.get("reason", "Flagged by custom code guardrail")
            verbose_proxy_logger.info(
                "Custom code guardrail '%s': Flagging %s - %s", self.guardrail_name, input_type, flag_reason
            )
            end_time: Final = time.time()
            self.add_standard_logging_guardrail_information_to_request_data(
                guardrail_json_response={
                    "action": "flag",
                    "reason": flag_reason,
                    "input_type": input_type,
                    "metadata": result.get("metadata") or {},
                },
                request_data=request_data,
                guardrail_status="guardrail_flagged",
                start_time=start_time,
                end_time=end_time,
                duration=end_time - start_time,
            )
            return inputs

        elif action == "modify":
            verbose_proxy_logger.debug("Custom code guardrail '%s': Modifying %s", self.guardrail_name, input_type)

            # Apply modifications
            modified_inputs: Final = dict(inputs)

            if "texts" in result and result["texts"] is not None:
                modified_inputs["texts"] = result["texts"]

            if "images" in result and result["images"] is not None:
                modified_inputs["images"] = result["images"]

            if "tool_calls" in result and result["tool_calls"] is not None:
                modified_inputs["tool_calls"] = result["tool_calls"]

            return cast(GenericGuardrailAPIInputs, modified_inputs)

        else:
            verbose_proxy_logger.warning(
                "Custom code guardrail '%s': Unknown action '%s'. Treating as allow.", self.guardrail_name, action
            )
            return inputs

    def update_custom_code(self, new_code: str) -> None:
        """
        Update the custom code and recompile.

        This method allows hot-reloading of guardrail logic without
        restarting the server.

        Args:
            new_code: The new source code

        Raises:
            CustomCodeCompilationError: If the new code fails to compile
        """
        with self._compile_lock:
            # Reset state
            old_function: Final = self._compiled_function
            old_code: Final = self.custom_code
            self._compiled_function = None
            self._compile_error = None

            try:
                self.custom_code = new_code
                self._do_compile()
                verbose_proxy_logger.info("Custom code guardrail '%s': Code updated successfully", self.guardrail_name)
            except SyntaxError as e:
                # Rollback on failure
                self.custom_code = old_code
                self._compiled_function = old_function
                self._compile_error = f"Syntax error in custom code: {e}"
                raise CustomCodeCompilationError(self._compile_error) from e
            except CustomCodeCompilationError:
                # Rollback on failure
                self.custom_code = old_code
                self._compiled_function = old_function
                raise
            except Exception as e:
                # Rollback on failure
                self.custom_code = old_code
                self._compiled_function = old_function
                self._compile_error = f"Failed to compile custom code: {e}"
                raise CustomCodeCompilationError(self._compile_error) from e
