import os
from collections.abc import Mapping
from types import MappingProxyType
from typing import Final, Protocol

import httpx
from typing_extensions import ReadOnly, TypedDict

import litellm
from litellm._logging import verbose_logger
from litellm.caching import InMemoryCache
from litellm.constants import SECRET_MANAGER_REFRESH_INTERVAL
from litellm.llms.custom_httpx.http_handler import (
    _get_httpx_client,
    get_async_httpx_client,
    httpxSpecialProvider,
)
from litellm.proxy._types import KeyManagementSystem
from litellm.rust_bridge.secret_manager import resolve_native_provider_reader, resolve_native_provider_writer

from .base_secret_manager import BaseSecretManager, raise_if_unsafe_secret_name


class _VaultAuthData(TypedDict):
    """The ``auth`` block Vault returns from a login endpoint."""

    client_token: ReadOnly[str]
    lease_duration: ReadOnly[int]


class _VaultLoginResponse(TypedDict):
    """Body of a Vault ``/v1/auth/.../login`` response."""

    auth: ReadOnly[_VaultAuthData]


class _VaultSecretTarget(TypedDict):
    """Resolved coordinates of one Vault KV v2 secret."""

    url: ReadOnly[str]
    data_key: ReadOnly[str]
    secret_name: ReadOnly[str]


class _VaultSecretDataBlock(TypedDict, total=False):
    """The inner ``data`` block of a Vault KV v2 read body."""

    data: ReadOnly[Mapping[str, object]]


class _VaultSecretReadResponse(TypedDict, total=False):
    """Body of a Vault KV v2 secret read, narrowed to the nesting this module walks."""

    data: ReadOnly[_VaultSecretDataBlock]


class _VaultLoginResponseSource(Protocol):
    """A Vault login call's HTTP response, read for the auth block it carries."""

    def json(self) -> _VaultLoginResponse: ...


class _VaultSecretReadSource(Protocol):
    """A Vault KV v2 read response, read for the nested secret data it carries."""

    def json(self) -> _VaultSecretReadResponse: ...


class _JsonObjectSource(Protocol):
    """A Vault response whose body is a JSON object nothing further is assumed about."""

    def json(self) -> dict[str, object]: ...


def _vault_login_body(response: _VaultLoginResponseSource) -> _VaultLoginResponse:
    """Decode the body of a Vault login response."""
    return response.json()


def _vault_secret_read_body(response: _VaultSecretReadSource) -> _VaultSecretReadResponse:
    """Decode the body of a Vault KV v2 secret read response."""
    return response.json()


def _json_object_body(response: _JsonObjectSource) -> dict[str, object]:
    """Decode a Vault response body as a plain JSON object."""
    return response.json()


def _as_json_object(value: object) -> Mapping[str, object] | None:
    return value if isinstance(value, Mapping) else None


class HashicorpSecretManager(BaseSecretManager):
    def __init__(self):
        from litellm.proxy.proxy_server import CommonProxyErrors, premium_user

        # Vault-specific config
        self.vault_addr = os.getenv("HCP_VAULT_ADDR", "http://127.0.0.1:8200")
        self.vault_token = os.getenv("HCP_VAULT_TOKEN", "")
        self.vault_namespace = os.getenv("HCP_VAULT_NAMESPACE", None)
        self.login_namespace_override = os.getenv("HCP_VAULT_LOGIN_NAMESPACE", None)
        self.secret_namespace_override = os.getenv("HCP_VAULT_SECRET_NAMESPACE", None)
        # KV engine mount name (default: "secret")
        # If your KV engine is mounted somewhere other than "secret", set HCP_VAULT_MOUNT_NAME
        self.vault_mount_name = os.getenv("HCP_VAULT_MOUNT_NAME", "secret")
        # Optional path prefix for secrets (e.g., "myapp" -> secret/data/myapp/{secret_name})
        self.vault_path_prefix = os.getenv("HCP_VAULT_PATH_PREFIX", None)

        # Optional config for TLS cert auth
        self.tls_cert_path = os.getenv("HCP_VAULT_CLIENT_CERT", "")
        self.tls_key_path = os.getenv("HCP_VAULT_CLIENT_KEY", "")
        self.vault_cert_role = os.getenv("HCP_VAULT_CERT_ROLE", None)

        # Optional config for AppRole auth
        self.approle_role_id = os.getenv("HCP_VAULT_APPROLE_ROLE_ID", "")
        self.approle_secret_id = os.getenv("HCP_VAULT_APPROLE_SECRET_ID", "")
        self.approle_mount_path = os.getenv("HCP_VAULT_APPROLE_MOUNT_PATH", "approle")

        self._verify_required_credentials_exist()

        if premium_user is not True:
            raise ValueError(
                f"Hashicorp secret manager is only available for premium users. {CommonProxyErrors.not_premium_user.value}"
            )

        litellm.secret_manager_client = self
        litellm._key_management_system = KeyManagementSystem.HASHICORP_VAULT
        _refresh_interval = os.environ.get("HCP_VAULT_REFRESH_INTERVAL", SECRET_MANAGER_REFRESH_INTERVAL)
        _refresh_interval = int(_refresh_interval) if _refresh_interval else SECRET_MANAGER_REFRESH_INTERVAL
        self.cache = InMemoryCache(default_ttl=_refresh_interval)  # store in memory for 1 day

    def _verify_required_credentials_exist(self) -> None:
        """
        Validate that at least one authentication method is configured.

        Raises:
            ValueError: If no valid authentication credentials are provided
        """
        has_token: Final = bool(self.vault_token)
        has_approle: Final = bool(self.approle_role_id and self.approle_secret_id)
        has_tls_cert: Final = bool(self.tls_cert_path and self.tls_key_path)

        if not has_token and not has_approle and not has_tls_cert:
            raise ValueError(
                "Missing Vault authentication credentials. Please set either:\n"
                "  - HCP_VAULT_TOKEN for token-based auth, or\n"
                "  - HCP_VAULT_APPROLE_ROLE_ID and HCP_VAULT_APPROLE_SECRET_ID for AppRole auth, or\n"
                "  - HCP_VAULT_CLIENT_CERT and HCP_VAULT_CLIENT_KEY for TLS certificate auth"
            )

    def _auth_via_approle(self) -> str:
        """
        Authenticate to Vault using AppRole auth method.
        
        Ref: https://developer.hashicorp.com/vault/api-docs/auth/approle

        Request:
        ```
        curl \
            --request POST \
            --header "X-Vault-Namespace: mynamespace/" \
            --data '{"role_id": "...", "secret_id": "..."}' \
            http://127.0.0.1:8200/v1/auth/approle/login
        ```

        Response:
        ```
        {
            "auth": {
                "client_token": "hvs.CAESI...",
                "accessor": "hmac-sha256...",
                "policies": ["default", "dev-policy"],
                "token_policies": ["default", "dev-policy"],
                "lease_duration": 2764800,
                "renewable": true
            }
        }
        ```
        """
        verbose_logger.debug("Using AppRole auth for Hashicorp Vault")

        # Check cache first
        cached_token: Final = self.cache.get_cache(key="hcp_vault_approle_token")
        if cached_token:
            verbose_logger.debug("Using cached Vault token from AppRole auth")
            return cached_token

        # Vault endpoint for AppRole login
        login_url: Final = f"{self.vault_addr}/v1/auth/{self.approle_mount_path}/login"

        headers: Final = self._get_login_headers()

        try:
            client: Final = _get_httpx_client()
            resp: Final = client.post(
                url=login_url,
                headers=headers,
                json={
                    "role_id": self.approle_role_id,
                    "secret_id": self.approle_secret_id,
                },
            )
            resp.raise_for_status()

            login_response: Final = _vault_login_body(resp)
            auth_data: Final = login_response["auth"]
            token: Final = auth_data["client_token"]
            _lease_duration: Final = auth_data["lease_duration"]

            verbose_logger.debug(
                "Successfully obtained Vault token via AppRole auth. Lease duration: %ss", _lease_duration
            )

            # Cache the token with its lease duration
            self.cache.set_cache(key="hcp_vault_approle_token", value=token, ttl=_lease_duration)
            return token
        except Exception as e:
            raise RuntimeError(f"Could not authenticate to Vault via AppRole: {e}")

    def _auth_via_tls_cert(self) -> str:
        """
        Ref: https://developer.hashicorp.com/vault/api-docs/auth/cert

        Request:
        ```
        curl \
            --request POST \
            --cacert vault-ca.pem \
            --cert cert.pem \
            --key key.pem \
            --header "X-Vault-Namespace: mynamespace/" \
            --data '{"name": "my-cert-role"}' \
            https://127.0.0.1:8200/v1/auth/cert/login
        ```

        Response:
        ```
        {
            "auth": {
                "client_token": "cf95f87d-f95b-47ff-b1f5-ba7bff850425",
                "policies": ["web", "stage"],
                "lease_duration": 3600,
                "renewable": true
            }
        }
        ```
        """
        verbose_logger.debug("Using TLS cert auth for Hashicorp Vault")
        # Vault endpoint for cert-based login, e.g. '/v1/auth/cert/login'
        login_url: Final = f"{self.vault_addr}/v1/auth/cert/login"

        headers: Final = self._get_login_headers()
        try:
            # We use the client cert and key for mutual TLS
            client: Final = httpx.Client(cert=(self.tls_cert_path, self.tls_key_path))
            resp: Final = client.post(
                login_url,
                headers=headers,
                json=self._get_tls_cert_auth_body(),
            )
            resp.raise_for_status()
            token_response: Final = _vault_login_body(resp)
            token: Final = token_response["auth"]["client_token"]
            lease_response: Final = _vault_login_body(resp)
            _lease_duration: Final = lease_response["auth"]["lease_duration"]
            verbose_logger.debug("Successfully obtained Vault token via TLS cert auth.")
            self.cache.set_cache(key="hcp_vault_token", value=token, ttl=_lease_duration)
            return token
        except Exception as e:
            raise RuntimeError(f"Could not authenticate to Vault via TLS cert: {e}")

    def _get_tls_cert_auth_body(self) -> dict:
        return {"name": self.vault_cert_role}

    @property
    def vault_login_namespace(self) -> str | None:
        if self.login_namespace_override is not None:
            return self.login_namespace_override
        return self.vault_namespace

    @property
    def vault_secret_namespace(self) -> str | None:
        if self.secret_namespace_override is not None:
            return self.secret_namespace_override
        return self.vault_namespace

    def _get_login_headers(self) -> Mapping[str, str]:
        if self.vault_login_namespace:
            return MappingProxyType({"X-Vault-Namespace": self.vault_login_namespace})
        return MappingProxyType({})

    def get_url(
        self,
        secret_name: str,
        namespace: object = None,
        mount_name: object = None,
        path_prefix: object = None,
    ) -> str:
        """
        Constructs the Vault URL for KV v2 secrets.

        Format: {VAULT_ADDR}/v1/{NAMESPACE}/{MOUNT_NAME}/data/{PATH_PREFIX}/{SECRET_NAME}

        Examples:
        - Default: http://127.0.0.1:8200/v1/secret/data/mykey
        - With namespace: http://127.0.0.1:8200/v1/mynamespace/secret/data/mykey
        - With custom mount: http://127.0.0.1:8200/v1/kv/data/mykey
        - With path prefix: http://127.0.0.1:8200/v1/secret/data/myapp/mykey
        """
        raise_if_unsafe_secret_name(secret_name)
        resolved_namespace = self._sanitize_path_component(
            namespace if namespace is not None else self.vault_secret_namespace
        )
        resolved_mount = self._sanitize_path_component(mount_name if mount_name is not None else self.vault_mount_name)
        if resolved_mount is None:
            resolved_mount = "secret"
        resolved_path_prefix: Final = self._sanitize_path_component(
            path_prefix if path_prefix is not None else self.vault_path_prefix
        )

        _url = f"{self.vault_addr}/v1/"
        if resolved_namespace:
            _url += f"{resolved_namespace}/"
        _url += f"{resolved_mount}/data/"
        if resolved_path_prefix:
            _url += f"{resolved_path_prefix}/"
        _url += secret_name
        return _url

    def _sanitize_plain_value(self, value: object) -> str | None:
        if value is None:
            return None
        value_str: Final = str(value).strip()
        if value_str == "":
            return None
        return value_str

    def _sanitize_path_component(self, value: object) -> str | None:
        sanitized_value = self._sanitize_plain_value(value)
        if sanitized_value is None:
            return None
        sanitized_value = sanitized_value.strip("/")
        return sanitized_value or None

    def _extract_secret_manager_settings(self, optional_params: dict | None) -> dict[str, object]:
        if not isinstance(optional_params, dict):
            return {}

        candidate: Final = optional_params.get("secret_manager_settings")
        source: Final[Mapping[str, object]] = candidate if isinstance(candidate, dict) else optional_params
        allowed_keys: Final = {"namespace", "mount", "path_prefix", "data"}
        return {k: source[k] for k in allowed_keys if k in source}

    def _build_secret_target(self, secret_name: str, optional_params: dict | None) -> _VaultSecretTarget:
        settings: Final = self._extract_secret_manager_settings(optional_params)

        namespace: Final = settings.get("namespace", self.vault_secret_namespace)
        mount: Final = settings.get("mount", self.vault_mount_name)
        path_prefix: Final = settings.get("path_prefix", self.vault_path_prefix)
        data_key_override: Final = settings.get("data")

        data_key: Final = self._sanitize_plain_value(data_key_override) or "key"

        url: Final = self.get_url(
            secret_name=secret_name,
            namespace=namespace,
            mount_name=mount,
            path_prefix=path_prefix,
        )

        return {
            "url": url,
            "data_key": data_key,
            "secret_name": secret_name,
        }

    def _get_request_headers(self) -> dict:
        """
        Get the headers for Vault API requests.

        Authentication priority:
        1. AppRole (if role_id and secret_id are configured)
        2. TLS Certificate (if cert paths are configured)
        3. Direct token (if HCP_VAULT_TOKEN is set)
        """
        # Priority 1: AppRole auth
        if self.approle_role_id and self.approle_secret_id:
            return {"X-Vault-Token": self._auth_via_approle()}

        # Priority 2: TLS cert auth
        if self.tls_cert_path and self.tls_key_path:
            return {"X-Vault-Token": self._auth_via_tls_cert()}

        # Priority 3: Direct token
        return {"X-Vault-Token": self.vault_token}

    async def async_read_secret(
        self,
        secret_name: str,
        optional_params: dict | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> str | None:
        """
        Reads a secret from Vault KV v2 using an async HTTPX client.
        secret_name is just the path inside the KV mount (e.g., 'myapp/config').
        Returns the entire data dict from data.data, or None on failure.
        """
        native: Final = resolve_native_provider_reader(self, "hashicorp_vault")
        if native is not None:
            return await native.async_read_secret(secret_name, optional_params, timeout)

        async_client: Final = get_async_httpx_client(
            llm_provider=httpxSpecialProvider.SecretManager,
        )
        try:
            target: Final = self._build_secret_target(secret_name, optional_params)
            cached_body: Final = self.cache.get_cache(target["url"])
            if cached_body is not None:
                return self._get_secret_value_from_json_response(cached_body, target["data_key"])

            response: Final = await async_client.get(target["url"], headers=self._get_request_headers())
            response.raise_for_status()

            json_resp: Final = _json_object_body(response)
            self.cache.set_cache(target["url"], json_resp)
            return self._get_secret_value_from_json_response(json_resp, target["data_key"])

        except Exception as e:
            verbose_logger.exception("Error reading secret from Hashicorp Vault: %s", e)
            return None

    def sync_read_secret(
        self,
        secret_name: str,
        optional_params: dict | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> str | None:
        """
        Reads a secret from Vault KV v2 using a sync HTTPX client.
        secret_name is just the path inside the KV mount (e.g., 'myapp/config').
        Returns the entire data dict from data.data, or None on failure.
        """
        native: Final = resolve_native_provider_reader(self, "hashicorp_vault")
        if native is not None:
            return native.sync_read_secret(secret_name, optional_params, timeout)

        sync_client: Final = _get_httpx_client()
        try:
            target: Final = self._build_secret_target(secret_name, optional_params)
            cached_body: Final = self.cache.get_cache(target["url"])
            if cached_body is not None:
                return self._get_secret_value_from_json_response(cached_body, target["data_key"])

            response: Final = sync_client.get(target["url"], headers=self._get_request_headers())
            response.raise_for_status()

            json_resp: Final = _json_object_body(response)
            self.cache.set_cache(target["url"], json_resp)
            return self._get_secret_value_from_json_response(json_resp, target["data_key"])

        except Exception as e:
            verbose_logger.exception("Error reading secret from Hashicorp Vault: %s", e)
            return None

    async def async_write_secret(
        self,
        secret_name: str,
        secret_value: str,
        description: str | None = None,
        optional_params: dict | None = None,
        timeout: float | httpx.Timeout | None = None,
        tags: dict | list | None = None,
    ) -> dict[str, object]:
        """
        Writes a secret to Vault KV v2 using an async HTTPX client.

        Args:
            secret_name: Path inside the KV mount (e.g., 'myapp/config')
            secret_value: Value to store
            description: Optional description for the secret
            optional_params: Additional parameters to include in the secret data
            timeout: Request timeout

        Returns:
            dict: Response containing status and details of the operation
        """
        native: Final = resolve_native_provider_writer(self, "hashicorp_vault")
        if native is not None:
            return await native.async_write_secret(
                secret_name, secret_value, description, optional_params, timeout, tags
            )

        async_client: Final = get_async_httpx_client(
            llm_provider=httpxSpecialProvider.SecretManager,
            params={"timeout": timeout},
        )

        try:
            target: Final = self._build_secret_target(secret_name, optional_params)

            # Prepare the secret data
            data: Final = {"data": {target["data_key"]: secret_value}}

            if description:
                data["data"]["description"] = description

            response: Final = await async_client.post(
                url=target["url"],
                headers=self._get_request_headers(),
                json=data,
            )
            response.raise_for_status()
            return _json_object_body(response)
        except Exception as e:
            verbose_logger.exception("Error writing secret to Hashicorp Vault: %s", e)
            return {"status": "error", "message": str(e)}

    async def async_rotate_secret(
        self,
        current_secret_name: str,
        new_secret_name: str,
        new_secret_value: str,
        optional_params: dict | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> dict:
        """
        Rotates a secret by creating a new one and deleting the old one.
        Uses _build_secret_target to handle optional_params for namespace, mount, path_prefix customization.

        Args:
            current_secret_name: Current name of the secret
            new_secret_name: New name for the secret
            new_secret_value: New value for the secret
            optional_params: Additional parameters (namespace, mount, path_prefix, data)
            timeout: Request timeout

        Returns:
            dict: Response containing status and details of the operation.
                  On success, returns the response from async_write_secret.
                  On error, returns {"status": "error", "message": "error message"}
        """
        native: Final = resolve_native_provider_writer(self, "hashicorp_vault")
        if native is not None:
            return await native.async_rotate_secret(
                current_secret_name, new_secret_name, new_secret_value, optional_params, timeout
            )

        async_client: Final = get_async_httpx_client(
            llm_provider=httpxSpecialProvider.SecretManager,
            params={"timeout": timeout},
        )

        try:
            # First verify the old secret exists using _build_secret_target
            current_target: Final = self._build_secret_target(current_secret_name, optional_params)
            try:
                response = await async_client.get(
                    url=current_target["url"],
                    headers=self._get_request_headers(),
                )
                response.raise_for_status()
                # Secret exists, we can proceed
            except httpx.HTTPStatusError as e:
                if e.response.status_code == 404:
                    verbose_logger.exception("Current secret %s not found", current_secret_name)
                    return {
                        "status": "error",
                        "message": f"Current secret {current_secret_name} not found",
                    }
                verbose_logger.exception(
                    "Error checking current secret existence: %s", e.response.text if hasattr(e, "response") else str(e)
                )
                return {
                    "status": "error",
                    "message": f"HTTP error occurred while checking current secret: {e.response.text if hasattr(e, 'response') else str(e)}",
                }
            except Exception as e:
                verbose_logger.exception("Error checking current secret existence: %s", e)
                return {
                    "status": "error",
                    "message": f"Error checking current secret: {e}",
                }

            # Create new secret with new name and value
            # Use _build_secret_target to handle optional_params
            create_response: Final = await self.async_write_secret(
                secret_name=new_secret_name,
                secret_value=new_secret_value,
                description=f"Rotated from {current_secret_name}",
                optional_params=optional_params,
                timeout=timeout,
            )

            # Check if async_write_secret returned an error
            if isinstance(create_response, dict) and create_response.get("status") == "error":
                return create_response

            # Verify new secret was created successfully using _build_secret_target
            new_target: Final = self._build_secret_target(new_secret_name, optional_params)
            try:
                response = await async_client.get(
                    url=new_target["url"],
                    headers=self._get_request_headers(),
                )
                response.raise_for_status()
                json_resp: Final = _vault_secret_read_body(response)
                # Use data_key from target to get the correct value
                data_key: Final = new_target["data_key"]
                new_secret_value_from_vault: Final = json_resp.get("data", {}).get("data", {}).get(data_key, None)
                if new_secret_value_from_vault != new_secret_value:
                    verbose_logger.exception(
                        "New secret value mismatch. Expected: %s, Got: %s",
                        new_secret_value,
                        new_secret_value_from_vault,
                    )
                    return {
                        "status": "error",
                        "message": f"New secret value mismatch. Expected: {new_secret_value}, Got: {new_secret_value_from_vault}",
                    }
            except httpx.HTTPStatusError as e:
                if e.response.status_code == 404:
                    verbose_logger.exception("Failed to verify new secret %s", new_secret_name)
                    return {
                        "status": "error",
                        "message": f"Failed to verify new secret {new_secret_name}",
                    }
                verbose_logger.exception(
                    "Error verifying new secret: %s", e.response.text if hasattr(e, "response") else str(e)
                )
                return {
                    "status": "error",
                    "message": f"HTTP error occurred while verifying new secret: {e.response.text if hasattr(e, 'response') else str(e)}",
                }
            except Exception as e:
                verbose_logger.exception("Error verifying new secret: %s", e)
                return {
                    "status": "error",
                    "message": f"Error verifying new secret: {e}",
                }

            # If everything is successful, delete the old secret
            # Only delete if the names are different (same name means we're just updating the value)
            if current_secret_name != new_secret_name:
                delete_response: Final = await self.async_delete_secret(
                    secret_name=current_secret_name,
                    recovery_window_in_days=7,  # Keep for recovery if needed
                    optional_params=optional_params,
                    timeout=timeout,
                )
                # Check if async_delete_secret returned an error
                if isinstance(delete_response, dict) and delete_response.get("status") == "error":
                    # Log the error but don't fail the rotation since new secret was created successfully
                    verbose_logger.warning(
                        "Failed to delete old secret %s after rotation: %s",
                        current_secret_name,
                        delete_response.get("message"),
                    )
                else:
                    # Clear cache for the old secret only if deletion was successful
                    self.cache.delete_cache(current_target["url"])

            # Clear cache for the new secret (or updated secret if names are the same)
            self.cache.delete_cache(new_target["url"])

            return create_response

        except httpx.TimeoutException:
            verbose_logger.exception("Timeout error occurred during secret rotation")
            return {"status": "error", "message": "Timeout error occurred"}
        except Exception as e:
            verbose_logger.exception("Error rotating secret in Hashicorp Vault: %s", e)
            return {"status": "error", "message": str(e)}

    async def async_delete_secret(
        self,
        secret_name: str,
        recovery_window_in_days: int | None = 7,
        optional_params: dict | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> dict:
        """
        Async function to delete a secret from Hashicorp Vault.
        In KV v2, this marks the latest version of the secret as deleted.

        Args:
            secret_name: Name of the secret to delete
            recovery_window_in_days: Not used for Vault (Vault handles this internally)
            optional_params: Additional parameters specific to the secret manager
            timeout: Request timeout

        Returns:
            dict: Response containing status and details of the operation
        """
        native: Final = resolve_native_provider_writer(self, "hashicorp_vault")
        if native is not None:
            return await native.async_delete_secret(secret_name, recovery_window_in_days, optional_params, timeout)

        async_client: Final = get_async_httpx_client(
            llm_provider=httpxSpecialProvider.SecretManager,
            params={"timeout": timeout},
        )

        try:
            target: Final = self._build_secret_target(secret_name, optional_params)
            response: Final = await async_client.delete(url=target["url"], headers=self._get_request_headers())
            response.raise_for_status()

            self.cache.delete_cache(target["url"])

            return {
                "status": "success",
                "message": f"Secret {target['secret_name']} deleted successfully",
            }
        except Exception as e:
            verbose_logger.exception("Error deleting secret from Hashicorp Vault: %s", e)
            return {"status": "error", "message": str(e)}

    def _get_secret_value_from_json_response(
        self, json_resp: Mapping[str, object] | None, data_key: str = "key"
    ) -> str | None:
        """
        Get the secret value from the JSON response

        Json response from hashicorp vault is of the form:

        {
            "request_id":"036ba77c-018b-31dd-047b-323bcd0cd332",
            "lease_id":"",
            "renewable":false,
            "lease_duration":0,
            "data":
                {"data":
                    {"key":"Vault Is The Way"},
                    "metadata":{"created_time":"2025-01-01T22:13:50.93942388Z","custom_metadata":null,"deletion_time":"","destroyed":false,"version":1}
                },
            "wrap_info":null,
            "warnings":null,
            "auth":null,
            "mount_type":"kv"
        }

        Note: LiteLLM assumes that all secrets are stored as under the key "key"
        """
        if json_resp is None:
            return None
        outer: Final = _as_json_object(json_resp.get("data"))
        if outer is None:
            return None
        inner: Final = _as_json_object(outer.get("data"))
        if inner is None:
            return None
        value: Final = inner.get(data_key)
        return value if isinstance(value, str) else None
