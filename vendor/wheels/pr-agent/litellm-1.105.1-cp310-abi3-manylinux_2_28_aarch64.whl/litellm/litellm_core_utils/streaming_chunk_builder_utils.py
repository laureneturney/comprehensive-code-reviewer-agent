import base64
import time
from collections.abc import Callable, Iterator, Mapping, Sequence
from itertools import groupby
from types import MappingProxyType
from typing import TYPE_CHECKING, Any, Final, TypeAlias, TypedDict, Union, cast

from typing_extensions import ReadOnly, Required

from litellm._logging import verbose_logger
from litellm.types.llms.openai import (
    ChatCompletionAssistantContentValue,
    ChatCompletionAudioDelta,
)
from litellm.types.utils import (
    CacheCreationTokenDetails,
    ChatCompletionAudioResponse,
    ChatCompletionCustomToolCallPayload,
    ChatCompletionDeltaCustomToolCall,
    ChatCompletionDeltaCustomToolCallPayload,
    ChatCompletionDeltaToolCall,
    ChatCompletionMessageCustomToolCall,
    ChatCompletionMessageToolCall,
    Choices,
    CompletionTokensDetails,
    CompletionTokensDetailsWrapper,
    Delta,
    Function,
    FunctionCall,
    ModelResponse,
    ModelResponseStream,
    PromptTokensDetailsWrapper,
    ServerToolUse,
    StreamingChoices,
    Usage,
)
from litellm.utils import print_verbose, token_counter

if TYPE_CHECKING:
    from openai.types.completion_usage import CompletionUsage

    from litellm.litellm_core_utils.litellm_logging import Logging
    from litellm.types.litellm_core_utils.streaming_chunk_builder_utils import (
        UsagePerChunk,
    )
    from litellm.types.llms.openai import (
        ChatCompletionRedactedThinkingBlock,
        ChatCompletionThinkingBlock,
    )


class _ThinkingBlockFragment(TypedDict, total=False):
    type: str | None
    data: str | None
    thinking: str | None
    signature: str | None


class _ThinkingDelta(TypedDict, total=False):
    thinking_blocks: Sequence[_ThinkingBlockFragment]


class _ThinkingChoice(TypedDict, total=False):
    delta: _ThinkingDelta


class _ThinkingChunk(TypedDict):
    choices: Sequence[_ThinkingChoice]


class _ContentChoice(TypedDict, total=False):
    delta: Mapping[str, str | None]


class _ContentChunk(TypedDict):
    choices: Sequence[_ContentChoice]


class _FunctionCallDelta(TypedDict):
    function_call: ReadOnly[FunctionCall]


class _FunctionCallChoice(TypedDict):
    delta: ReadOnly[_FunctionCallDelta]


class _FunctionCallChunk(TypedDict):
    choices: ReadOnly[Sequence[_FunctionCallChoice]]


class _AudioDelta(TypedDict, total=False):
    audio: ChatCompletionAudioDelta | None


class _AudioChoice(TypedDict, total=False):
    delta: _AudioDelta


class _AudioChunk(TypedDict):
    choices: Sequence[_AudioChoice]


_ChunkHiddenParams: TypeAlias = dict[str, object]


class _BaseChunk(TypedDict, total=False):
    id: ReadOnly[str]
    object: ReadOnly[str]
    created: ReadOnly[int]
    model: ReadOnly[str]
    system_fingerprint: ReadOnly[str | None]
    service_tier: ReadOnly[str | None]
    choices: ReadOnly[Required[Sequence[StreamingChoices]]]
    _hidden_params: ReadOnly[_ChunkHiddenParams]


class _ToolCallFunctionFragment(TypedDict, total=False):
    name: ReadOnly[str]
    arguments: ReadOnly[str]
    provider_specific_fields: ReadOnly[dict[str, object]]


class _ToolCallCustomFragment(TypedDict, total=False):
    name: ReadOnly[str]
    input: ReadOnly[str]


class _ToolCallFragment(TypedDict, total=False):
    index: ReadOnly[int]
    id: ReadOnly[str | None]
    type: ReadOnly[str | None]
    function: ReadOnly[_ToolCallFunctionFragment | Function | None]
    custom: ReadOnly[_ToolCallCustomFragment | None]
    provider_specific_fields: ReadOnly[dict[str, object] | None]


class _ToolCallDelta(TypedDict, total=False):
    tool_calls: ReadOnly[Sequence[_ToolCallFragment | ChatCompletionDeltaToolCall | ChatCompletionDeltaCustomToolCall]]


class _ToolCallChoice(TypedDict, total=False):
    index: ReadOnly[int]
    delta: ReadOnly[_ToolCallDelta]


_ToolCallKey: TypeAlias = tuple[int, int]


class _ToolCallChunk(TypedDict):
    choices: ReadOnly[Sequence[_ToolCallChoice]]


class _UsageBearingChunk(TypedDict, total=False):
    usage: Usage | None
    _hidden_params: Mapping[str, str]
    choices: ReadOnly[Sequence[StreamingChoices | Mapping[str, object]]]


class _UsageSummary(TypedDict):
    prompt_tokens: int | None
    completion_tokens: int | None
    cache_creation_input_tokens: int | None
    cache_read_input_tokens: int | None
    completion_tokens_details: CompletionTokensDetails | None
    prompt_tokens_details: PromptTokensDetailsWrapper | None
    cost: float | None


def _reports_prompt_side_usage(usage_summary: "_UsageSummary") -> bool:
    return (
        (usage_summary["prompt_tokens"] or 0) > 0
        or (usage_summary["cache_creation_input_tokens"] or 0) > 0
        or (usage_summary["cache_read_input_tokens"] or 0) > 0
    )


def capture_cache_creation_token_details(
    prompt_tokens_details: PromptTokensDetailsWrapper | None,
    current: CacheCreationTokenDetails | None,
) -> CacheCreationTokenDetails | None:
    incoming: Final = cast(
        CacheCreationTokenDetails | None,
        getattr(prompt_tokens_details, "cache_creation_token_details", None),
    )
    if incoming is not None:
        return incoming
    return current


def attach_cache_creation_token_details(
    prompt_tokens_details: PromptTokensDetailsWrapper | None,
    cache_creation_token_details: CacheCreationTokenDetails | None,
) -> PromptTokensDetailsWrapper | None:
    if prompt_tokens_details is None or cache_creation_token_details is None:
        return prompt_tokens_details
    existing: Final = cast(
        CacheCreationTokenDetails | None,
        getattr(prompt_tokens_details, "cache_creation_token_details", None),
    )
    if existing is not None:
        return prompt_tokens_details
    return prompt_tokens_details.model_copy(update={"cache_creation_token_details": cache_creation_token_details})


def apply_grounding_request_counts(
    prompt_tokens_details: PromptTokensDetailsWrapper | None,
    web_search_requests: int | None,
    google_maps_grounding_requests: int | None,
) -> PromptTokensDetailsWrapper | None:
    updates: Final = MappingProxyType(
        {
            field: value
            for field, value in (
                ("web_search_requests", web_search_requests),
                ("google_maps_grounding_requests", google_maps_grounding_requests),
            )
            if value is not None
        }
    )
    if not updates:
        return prompt_tokens_details
    counted: Final = prompt_tokens_details if prompt_tokens_details is not None else PromptTokensDetailsWrapper()
    return counted.model_copy(update=updates)


class ChunkProcessor:
    def __init__(self, chunks: list, messages: Sequence | None = None):
        self.chunks = self._sort_chunks(chunks)
        self.messages = messages
        self.first_chunk = chunks[0]

    def _sort_chunks(self, chunks: list) -> list:
        if not chunks:
            return []

        first_chunk: Final = chunks[0]
        first_hidden_params: dict[str, object] = {}
        if isinstance(first_chunk, dict):
            candidate = first_chunk.get("_hidden_params", {})
            if isinstance(candidate, dict):
                first_hidden_params = candidate
        else:
            candidate = getattr(first_chunk, "_hidden_params", {})
            if isinstance(candidate, dict):
                first_hidden_params = candidate

        if first_hidden_params.get("created_at"):

            def _created_at(chunk: object) -> int | float:
                if isinstance(chunk, dict):
                    params = chunk.get("_hidden_params", {})
                else:
                    params = getattr(chunk, "_hidden_params", {})
                if isinstance(params, dict):
                    return cast(int | float, params.get("created_at", float("inf")))
                return float("inf")

            return sorted(chunks, key=_created_at)
        return chunks

    def update_model_response_with_hidden_params(
        self, model_response: ModelResponse, chunk: "_BaseChunk | None" = None
    ) -> ModelResponse:
        if chunk is None:
            return model_response
        # set hidden params from chunk to model_response
        if model_response is not None and hasattr(model_response, "_hidden_params"):
            model_response._hidden_params = chunk.get("_hidden_params", {})
        return model_response

    @staticmethod
    def _get_provider_response_model(
        chunks: Sequence["_BaseChunk"],
        first_chunk_model: str,
    ) -> str | None:
        models: Final = tuple(
            model
            for chunk in chunks
            if isinstance((hidden_params := chunk.get("_hidden_params")), Mapping)
            if isinstance((model := hidden_params.get("provider_response_model")), str) and model
        )
        return next(
            (model for model in models if model != first_chunk_model),
            models[0] if models else None,
        )

    @staticmethod
    def apply_provider_assembled_streaming_metadata(
        response: ModelResponse,
        chunks: list[object],
        logging_obj: "Logging | None" = None,
    ) -> None:
        if not chunks:
            return

        model: Final[str | None] = getattr(response, "model", None)
        if not model:
            return

        custom_llm_provider = None
        if logging_obj is not None:
            custom_llm_provider = logging_obj.model_call_details.get("custom_llm_provider")

        try:
            from litellm.litellm_core_utils.get_llm_provider_logic import (
                get_llm_provider,
            )
            from litellm.types.utils import LlmProviders
            from litellm.utils import ProviderConfigManager

            if custom_llm_provider:
                provider = LlmProviders(custom_llm_provider)
            else:
                _, provider_str, _, _ = get_llm_provider(model)
                provider = LlmProviders(provider_str)

            provider_config: Final = ProviderConfigManager.get_provider_chat_config(
                model=model,
                provider=provider,
            )
            if provider_config is not None:
                provider_config.apply_assembled_streaming_response_metadata(
                    response=response,
                    chunks=chunks,
                )
        except Exception as e:
            verbose_logger.debug(
                "apply_provider_assembled_streaming_metadata failed for model=%s: %s",
                model,
                e,
            )

    @staticmethod
    def _get_chunk_id(chunks: Sequence["_BaseChunk"]) -> str:
        """
        Chunks:
        [{"id": ""}, {"id": "1"}, {"id": "1"}]
        """
        for chunk in chunks:
            if chunk_id := chunk.get("id"):
                return chunk_id
        return ""

    @staticmethod
    def _get_role_from_chunks(chunks: Sequence["_BaseChunk"]) -> str:
        return ChunkProcessor._role_of_choice(next((c["choices"][0] for c in chunks if c.get("choices")), None))

    @staticmethod
    def _role_of_choice(choice: object) -> str:
        match choice:
            case StreamingChoices(delta=Delta(role=str() as role)) | {"delta": {"role": str() as role}} if role:
                return role
            case _:
                return "assistant"

    @staticmethod
    def _get_model_from_chunks(chunks: Sequence["_BaseChunk"], first_chunk_model: str) -> str:
        """
        Get the actual model from chunks, preferring a model that differs from the first chunk.

        For Azure Model Router, the first chunk may have the request model (e.g., 'azure-model-router')
        while subsequent chunks have the actual model (e.g., 'gpt-4.1-nano-2025-04-14').
        This method finds the actual model for accurate cost calculation.
        """
        # Look for a model in chunks that differs from the first chunk's model
        for chunk in chunks:
            chunk_model = chunk.get("model")
            if chunk_model and chunk_model != first_chunk_model:
                return chunk_model
        # Fall back to first chunk's model if no different model found
        return first_chunk_model

    @staticmethod
    def _get_service_tier_from_chunks(chunks: Sequence["_BaseChunk"]) -> str | None:
        return next(
            (tier for chunk in reversed(chunks) if isinstance(tier := chunk.get("service_tier"), str) and tier),
            None,
        )

    def build_base_response(self, chunks: Sequence["_BaseChunk"]) -> ModelResponse:
        chunk = self.first_chunk
        id: Final = ChunkProcessor._get_chunk_id(chunks)
        object: Final = chunk["object"]
        created: Final = chunk["created"]
        first_chunk_model: Final = chunk["model"]
        # Get the actual model - for Azure Model Router, this finds the real model from later chunks
        model: Final = ChunkProcessor._get_model_from_chunks(chunks, first_chunk_model)
        system_fingerprint: Final = chunk.get("system_fingerprint", None)
        service_tier: Final = ChunkProcessor._get_service_tier_from_chunks(chunks)

        role: Final = ChunkProcessor._get_role_from_chunks(chunks)
        finish_reason = "stop"
        for chunk in chunks:
            if "choices" in chunk and len(chunk["choices"]) > 0:
                chunk_finish_reason = None
                if hasattr(chunk["choices"][0], "finish_reason"):
                    chunk_finish_reason = chunk["choices"][0].finish_reason
                elif "finish_reason" in chunk["choices"][0]:
                    chunk_finish_reason = chunk["choices"][0]["finish_reason"]
                if chunk_finish_reason is not None:
                    finish_reason = chunk_finish_reason

        # Initialize the response dictionary
        response = ModelResponse(
            **{
                "id": id,
                "object": object,
                "created": created,
                "model": model,
                "system_fingerprint": system_fingerprint,
                **(
                    MappingProxyType({"service_tier": service_tier})
                    if service_tier is not None
                    else MappingProxyType({})
                ),
                "choices": [
                    {
                        "index": 0,
                        "message": {"role": role, "content": ""},
                        "finish_reason": finish_reason,
                    }
                ],
                "usage": {
                    "prompt_tokens": 0,  # Modify as needed
                    "completion_tokens": 0,  # Modify as needed
                    "total_tokens": 0,  # Modify as needed
                },
            }
        )

        response = self.update_model_response_with_hidden_params(model_response=response, chunk=chunk)
        provider_response_model: Final = self._get_provider_response_model(
            chunks,
            first_chunk_model,
        )
        if provider_response_model is not None:
            response._hidden_params = dict(  # pyright: ignore[reportPrivateUsage]  # ModelResponse exposes no public hidden-params setter
                response._hidden_params,  # pyright: ignore[reportPrivateUsage]  # ModelResponse exposes no public hidden-params getter
                provider_response_model=provider_response_model,
            )
        return response

    @staticmethod
    def _iter_tool_call_fragments(
        tool_call_chunks: Sequence["_ToolCallChunk"],
    ) -> Iterator[tuple[_ToolCallKey, str, str]]:
        for chunk in tool_call_chunks:
            for choice in chunk["choices"]:
                delta = choice.get("delta")
                if not delta:
                    continue
                choice_index = choice.get("index", 0)
                for tool_call in delta.get("tool_calls") or ():
                    if not tool_call:
                        continue
                    if isinstance(tool_call, dict):
                        key = (choice_index, tool_call.get("index", 0))
                        function = tool_call.get("function")
                        if isinstance(function, dict):
                            if fragment_arguments := function.get("arguments"):
                                yield key, "arguments", fragment_arguments
                        elif function_arguments := getattr(function, "arguments", None):
                            yield key, "arguments", function_arguments
                        custom = tool_call.get("custom")
                        if isinstance(custom, dict) and (custom_input := custom.get("input")):
                            yield key, "custom_input", custom_input
                    else:
                        key = (choice_index, getattr(tool_call, "index", 0))
                        function = getattr(tool_call, "function", None)
                        if object_arguments := getattr(function, "arguments", None):
                            yield key, "arguments", object_arguments
                        custom = getattr(tool_call, "custom", None)
                        if object_custom_input := getattr(custom, "input", None):
                            yield key, "custom_input", object_custom_input

    @staticmethod
    def _join_fragments_by_key_and_field(
        fragment_records: Iterator[tuple[_ToolCallKey, str, str]],
    ) -> Mapping[tuple[_ToolCallKey, str], str]:
        def group_key(record: tuple[_ToolCallKey, str, str]) -> tuple[_ToolCallKey, str]:
            return record[0], record[1]

        return MappingProxyType(
            {
                key: "".join(fragment for _, _, fragment in group)
                for key, group in groupby(sorted(fragment_records, key=group_key), key=group_key)
            }
        )

    def get_combined_tool_content(
        self, tool_call_chunks: Sequence["_ToolCallChunk"]
    ) -> list[ChatCompletionMessageToolCall | ChatCompletionMessageCustomToolCall]:
        tool_calls_list: list[ChatCompletionMessageToolCall | ChatCompletionMessageCustomToolCall] = []
        tool_call_map: Final[dict[_ToolCallKey, dict[str, Any]]] = {}

        for chunk in tool_call_chunks:
            choices = chunk["choices"]
            for choice in choices:
                delta = choice.get("delta", {})
                tool_calls = delta.get("tool_calls") or ()
                choice_index = choice.get("index", 0)

                for tool_call in tool_calls:
                    # Handle both dict and object formats
                    if not tool_call:
                        continue

                    # Check if tool_call has function (either as attribute or dict key)
                    has_function = False
                    has_custom = False
                    if isinstance(tool_call, dict):
                        has_function = "function" in tool_call and tool_call["function"] is not None
                        has_custom = "custom" in tool_call and tool_call["custom"] is not None
                    else:
                        has_function = getattr(tool_call, "function", None) is not None
                        has_custom = getattr(tool_call, "custom", None) is not None

                    if not has_function and not has_custom:
                        continue

                    # Get index (handle both dict and object)
                    if isinstance(tool_call, dict):
                        index = (choice_index, tool_call.get("index", 0))
                    else:
                        index = (choice_index, getattr(tool_call, "index", 0))

                    if index not in tool_call_map:
                        tool_call_map[index] = {
                            "id": None,
                            "name": None,
                            "type": None,
                            "custom_name": None,
                            "provider_specific_fields": None,
                        }

                    # Extract id, type, and function data (handle both dict and object)
                    if isinstance(tool_call, dict):
                        if fragment_id := tool_call.get("id"):
                            tool_call_map[index]["id"] = fragment_id
                        if fragment_type := tool_call.get("type"):
                            tool_call_map[index]["type"] = fragment_type

                        function = tool_call.get("function", {})
                        if isinstance(function, dict):
                            if fragment_name := function.get("name"):
                                tool_call_map[index]["name"] = fragment_name
                        else:
                            # function is an object
                            if function_name := getattr(function, "name", None):
                                tool_call_map[index]["name"] = function_name

                        custom = tool_call.get("custom")
                        if isinstance(custom, dict):
                            if custom_name := custom.get("name"):
                                tool_call_map[index]["custom_name"] = custom_name
                    else:
                        # tool_call is an object
                        if hasattr(tool_call, "id") and tool_call.id:
                            tool_call_map[index]["id"] = tool_call.id
                        if hasattr(tool_call, "type") and tool_call.type:
                            tool_call_map[index]["type"] = tool_call.type
                        if object_function_name := getattr(getattr(tool_call, "function", None), "name", None):
                            tool_call_map[index]["name"] = object_function_name

                        object_custom: ChatCompletionDeltaCustomToolCallPayload | None = getattr(
                            tool_call, "custom", None
                        )
                        if object_custom is not None:
                            if getattr(object_custom, "name", None):
                                tool_call_map[index]["custom_name"] = object_custom.name

                    # Preserve provider_specific_fields from streaming chunks
                    provider_fields: object = None
                    if isinstance(tool_call, dict):
                        provider_fields = tool_call.get("provider_specific_fields")
                        if not provider_fields and isinstance(fragment_function := tool_call.get("function"), dict):
                            provider_fields = fragment_function.get("provider_specific_fields")
                    else:
                        object_provider_fields: object = getattr(tool_call, "provider_specific_fields", None)
                        if object_provider_fields:
                            provider_fields = object_provider_fields
                        else:
                            function_provider_fields: object = getattr(
                                getattr(tool_call, "function", None),
                                "provider_specific_fields",
                                None,
                            )
                            if function_provider_fields:
                                provider_fields = function_provider_fields

                    if provider_fields:
                        # Merge provider_specific_fields if multiple chunks have them
                        merged_provider_fields = tool_call_map[index]["provider_specific_fields"]
                        if merged_provider_fields is None:
                            merged_provider_fields = {}
                            tool_call_map[index]["provider_specific_fields"] = merged_provider_fields
                        if isinstance(provider_fields, dict):
                            merged_provider_fields.update(provider_fields)

        joined_fragments: Final = self._join_fragments_by_key_and_field(
            self._iter_tool_call_fragments(tool_call_chunks)
        )

        # Convert the map to a list of tool calls
        for index in sorted(tool_call_map.keys()):
            tool_call_data = tool_call_map[index]
            if tool_call_data["id"] and tool_call_data["custom_name"]:
                tool_calls_list.append(
                    ChatCompletionMessageCustomToolCall(
                        id=tool_call_data["id"],
                        custom=ChatCompletionCustomToolCallPayload(
                            name=tool_call_data["custom_name"],
                            input=joined_fragments.get((index, "custom_input"), ""),
                        ),
                    )
                )
            elif tool_call_data["id"] and tool_call_data["name"]:
                combined_arguments = joined_fragments.get((index, "arguments"), "") or "{}"

                # Build function - provider_specific_fields should be on tool_call level, not function level
                function = Function(
                    arguments=combined_arguments,
                    name=tool_call_data["name"],
                )

                # Prepare params for ChatCompletionMessageToolCall
                tool_call_params = {
                    "id": tool_call_data["id"],
                    "function": function,
                    "type": tool_call_data["type"] or "function",
                }

                # Add provider_specific_fields if present (for thought signatures in Gemini 3)
                if tool_call_data.get("provider_specific_fields"):
                    tool_call_params["provider_specific_fields"] = tool_call_data["provider_specific_fields"]

                tool_call = ChatCompletionMessageToolCall(**tool_call_params)
                tool_calls_list.append(tool_call)

        return tool_calls_list

    def get_combined_function_call_content(self, function_call_chunks: Sequence["_FunctionCallChunk"]) -> FunctionCall:
        argument_list: Final = []
        delta = function_call_chunks[0]["choices"][0]["delta"]
        function_call = delta.get("function_call", "")
        function_call_name: Final = function_call.name

        for chunk in function_call_chunks:
            choices = chunk["choices"]
            for choice in choices:
                delta = choice.get("delta", {})
                function_call = delta.get("function_call", "")

                # Check if a function call is present
                if function_call:
                    # Now, function_call is expected to be a dictionary
                    arguments = function_call.arguments
                    argument_list.append(arguments)

        combined_arguments: Final = "".join(argument_list)

        return FunctionCall(
            name=function_call_name,
            arguments=combined_arguments,
        )

    def get_combined_content(
        self, chunks: Sequence["_ContentChunk"], delta_key: str = "content"
    ) -> ChatCompletionAssistantContentValue:
        content_list: Final[list[str]] = []
        for chunk in chunks:
            choices = chunk["choices"]
            for choice in choices:
                delta = choice.get("delta", {})
                content = delta.get(delta_key, "")
                if content is None:
                    continue  # openai v1.0.0 sets content = None for chunks
                content_list.append(content)

        # Combine the "content" strings into a single string || combine the 'function' strings into a single string
        combined_content: Final = "".join(content_list)

        # Update the "content" field within the response dictionary
        return combined_content

    def get_combined_thinking_content(
        self, chunks: Sequence["_ThinkingChunk"]
    ) -> list[Union["ChatCompletionThinkingBlock", "ChatCompletionRedactedThinkingBlock"]] | None:
        from litellm.types.llms.openai import (
            ChatCompletionRedactedThinkingBlock,
            ChatCompletionThinkingBlock,
        )

        thinking_blocks: Final[list[ChatCompletionThinkingBlock | ChatCompletionRedactedThinkingBlock]] = []
        current_thinking_text_parts: list[str] = []
        current_signature: str | None = None

        def _flush_thinking_block() -> None:
            nonlocal current_thinking_text_parts, current_signature
            if current_signature:
                thinking_blocks.append(
                    ChatCompletionThinkingBlock(
                        type="thinking",
                        thinking="".join(current_thinking_text_parts),
                        signature=current_signature,
                    )
                )
            current_thinking_text_parts = []
            current_signature = None

        for chunk in chunks:
            choices = chunk["choices"]
            for choice in choices:
                delta = choice.get("delta", {})
                thinking = delta.get("thinking_blocks", None)
                if thinking and isinstance(thinking, list):
                    for thinking_block in thinking:
                        thinking_type = thinking_block.get("type", None)
                        if thinking_type and thinking_type == "redacted_thinking":
                            _flush_thinking_block()
                            redacted_data = thinking_block.get("data", None)
                            if redacted_data:
                                thinking_blocks.append(
                                    ChatCompletionRedactedThinkingBlock(
                                        type="redacted_thinking",
                                        data=redacted_data,
                                    )
                                )
                        else:
                            thinking_text = thinking_block.get("thinking", None)
                            if thinking_text:
                                current_thinking_text_parts.append(thinking_text)
                            signature = thinking_block.get("signature", None)
                            if signature:
                                current_signature = signature
                                _flush_thinking_block()

        _flush_thinking_block()

        if len(thinking_blocks) > 0:
            return thinking_blocks
        return None

    def get_combined_reasoning_content(self, chunks: Sequence["_ContentChunk"]) -> ChatCompletionAssistantContentValue:
        return self.get_combined_content(chunks, delta_key="reasoning_content")

    def get_combined_audio_content(self, chunks: Sequence["_AudioChunk"]) -> ChatCompletionAudioResponse:
        base64_data_list: Final[list[str]] = []
        transcript_list: Final[list[str]] = []
        expires_at: int | None = None
        id: str | None = None

        for chunk in chunks:
            choices = chunk["choices"]
            for choice in choices:
                delta: _AudioDelta = choice.get("delta") or {}
                audio: ChatCompletionAudioDelta | None = delta.get("audio")
                if audio is not None:
                    for k, v in audio.items():
                        if k == "data" and v is not None and isinstance(v, str):
                            base64_data_list.append(v)
                        elif k == "transcript" and v is not None and isinstance(v, str):
                            transcript_list.append(v)
                        elif k == "expires_at" and v is not None and isinstance(v, int):
                            expires_at = v
                        elif k == "id" and v is not None and isinstance(v, str):
                            id = v

        concatenated_audio: Final = concatenate_base64_list(base64_data_list)
        return ChatCompletionAudioResponse(
            data=concatenated_audio,
            expires_at=expires_at or int(time.time() + 3600),
            transcript="".join(transcript_list),
            id=id,
        )

    def _usage_chunk_calculation_helper(self, usage_chunk: Usage) -> "_UsageSummary":
        prompt_tokens = 0
        completion_tokens = 0
        ## anthropic prompt caching information ##
        cache_creation_input_tokens: int | None = None
        cache_read_input_tokens: int | None = None
        completion_tokens_details: CompletionTokensDetails | None = None
        prompt_tokens_details: PromptTokensDetailsWrapper | None = None
        cost: float | None = None

        if "prompt_tokens" in usage_chunk:
            prompt_tokens = usage_chunk.get("prompt_tokens", 0) or 0
        if "completion_tokens" in usage_chunk:
            completion_tokens = usage_chunk.get("completion_tokens", 0) or 0
        if "cache_creation_input_tokens" in usage_chunk:
            cache_creation_input_tokens = usage_chunk.get("cache_creation_input_tokens")
        if "cache_read_input_tokens" in usage_chunk:
            cache_read_input_tokens = usage_chunk.get("cache_read_input_tokens")
        if "cost" in usage_chunk:
            cost = usage_chunk.get("cost")
        if hasattr(usage_chunk, "completion_tokens_details"):
            if isinstance(usage_chunk.completion_tokens_details, dict):
                completion_tokens_details = CompletionTokensDetails(**usage_chunk.completion_tokens_details)
            elif isinstance(usage_chunk.completion_tokens_details, CompletionTokensDetails):
                completion_tokens_details = usage_chunk.completion_tokens_details
        if hasattr(usage_chunk, "prompt_tokens_details"):
            if isinstance(usage_chunk.prompt_tokens_details, dict):
                prompt_tokens_details = PromptTokensDetailsWrapper(**usage_chunk.prompt_tokens_details)
            elif isinstance(usage_chunk.prompt_tokens_details, PromptTokensDetailsWrapper):
                prompt_tokens_details = usage_chunk.prompt_tokens_details

        return {
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "cache_creation_input_tokens": cache_creation_input_tokens,
            "cache_read_input_tokens": cache_read_input_tokens,
            "completion_tokens_details": completion_tokens_details,
            "prompt_tokens_details": prompt_tokens_details,
            "cost": cost,
        }

    def count_reasoning_tokens(self, response: ModelResponse) -> int | None:
        reasoning_tokens: int | None = None
        for choice in response.choices:
            if (
                hasattr(cast(Choices, choice).message, "reasoning_content")
                and cast(Choices, choice).message.reasoning_content
            ):
                if reasoning_tokens is None:
                    reasoning_tokens = 0
                reasoning_tokens += token_counter(
                    text=cast(Choices, choice).message.reasoning_content,
                    count_response_tokens=True,
                )

        return reasoning_tokens

    @staticmethod
    def _extract_usage_chunk(chunk: "_UsageBearingChunk | ModelResponse | ModelResponseStream") -> Usage | None:
        usage_chunk: Usage | CompletionUsage | None = None
        if hasattr(chunk, "usage") and chunk.usage is not None:
            usage_chunk = chunk.usage
        elif "usage" in chunk:
            usage_chunk = chunk["usage"]
        elif (isinstance(chunk, ModelResponse) or isinstance(chunk, ModelResponseStream)) and hasattr(
            chunk, "_hidden_params"
        ):
            usage_chunk = chunk._hidden_params.get("usage", None)

        if isinstance(usage_chunk, dict):
            return Usage(**usage_chunk)
        if usage_chunk is None or isinstance(usage_chunk, Usage):
            return usage_chunk
        return Usage(**usage_chunk.model_dump())

    def _calculate_usage_per_chunk(
        self,
        chunks: Sequence["_UsageBearingChunk | ModelResponse"],
    ) -> "UsagePerChunk":
        from litellm.types.litellm_core_utils.streaming_chunk_builder_utils import (
            UsagePerChunk,
        )

        # None means no usage chunk reported the count, which is the only case
        # calculate_usage() estimates with the tokenizer. An explicit provider 0
        # is a reported count and stays 0; a reported count is never replaced by
        # a later chunk's 0 (Ollama sends 0/0 on every chunk before the done one).
        prompt_tokens: int | None = None
        completion_tokens: int | None = None
        # Anthropic's `message_start` SSE event carries usage.output_tokens=1 as a
        # cursor/placeholder; the real value only arrives in `message_delta`.
        # If a stream is cancelled before `message_delta` lands, the accumulator
        # below leaves completion_tokens stuck at 1, a reported count that
        # calculate_usage() would keep. Count the completion-bearing
        # usage events so `_reset_anthropic_cursor_completion_tokens` can tell a
        # legitimate single-token reply (Anthropic emits 1 in BOTH message_start
        # AND message_delta, so >=2 events is positive evidence message_delta
        # arrived) from a stale lone cursor.
        completion_usage_updates = 0
        ## anthropic prompt caching information ##
        cache_creation_input_tokens: int | None = None
        cache_read_input_tokens: int | None = None

        server_tool_use: ServerToolUse | None = None
        web_search_requests: int | None = None
        google_maps_grounding_requests: int | None = None
        completion_tokens_details: CompletionTokensDetails | None = None
        prompt_tokens_details: PromptTokensDetailsWrapper | None = None
        # Anthropic emits the cache-creation TTL breakdown (5m/1h split) only on
        # the `message_start` event; the later `message_delta` carries the flat
        # cache-creation count but drops the nested breakdown. prompt_tokens_details
        # is last-wins, so without preserving this separately the 1h breakdown is
        # lost and 1h cache writes get billed at the 5m rate.
        cache_creation_token_details: CacheCreationTokenDetails | None = None
        cost: float | None = None

        for chunk in chunks:
            usage_chunk = self._extract_usage_chunk(chunk)

            if usage_chunk is not None:
                usage_chunk_dict = self._usage_chunk_calculation_helper(usage_chunk)
                if usage_chunk_dict["prompt_tokens"] is not None and (
                    usage_chunk_dict["prompt_tokens"] > 0 or prompt_tokens is None
                ):
                    prompt_tokens = usage_chunk_dict["prompt_tokens"]
                if usage_chunk_dict["completion_tokens"] is not None and (
                    usage_chunk_dict["completion_tokens"] > 0 or completion_tokens is None
                ):
                    completion_tokens = usage_chunk_dict["completion_tokens"]
                if usage_chunk_dict["completion_tokens"] is not None and usage_chunk_dict["completion_tokens"] > 0:
                    completion_usage_updates += 1
                if usage_chunk_dict["cache_creation_input_tokens"] is not None and (
                    _reports_prompt_side_usage(usage_chunk_dict) or cache_creation_input_tokens is None
                ):
                    cache_creation_input_tokens = usage_chunk_dict["cache_creation_input_tokens"]
                if usage_chunk_dict["cache_read_input_tokens"] is not None and (
                    _reports_prompt_side_usage(usage_chunk_dict) or cache_read_input_tokens is None
                ):
                    cache_read_input_tokens = usage_chunk_dict["cache_read_input_tokens"]
                if usage_chunk_dict["completion_tokens_details"] is not None:
                    completion_tokens_details = usage_chunk_dict["completion_tokens_details"]
                if hasattr(usage_chunk, "server_tool_use") and usage_chunk.server_tool_use is not None:
                    # Coerce dict to ServerToolUse so downstream cost-calc code
                    # (which accesses .web_search_requests as an attribute)
                    # doesn't raise AttributeError. Some providers / streaming
                    # paths leave server_tool_use as a plain dict on the chunk.
                    if isinstance(usage_chunk.server_tool_use, dict):
                        server_tool_use = ServerToolUse(**usage_chunk.server_tool_use)
                    elif isinstance(usage_chunk.server_tool_use, ServerToolUse):
                        server_tool_use = usage_chunk.server_tool_use
                    else:
                        server_tool_use = ServerToolUse.model_validate(usage_chunk.server_tool_use)
                if usage_chunk_dict["prompt_tokens_details"] is not None:
                    chunk_web_search_requests: int | None = getattr(
                        usage_chunk_dict["prompt_tokens_details"],
                        "web_search_requests",
                        None,
                    )
                    if chunk_web_search_requests is not None:
                        web_search_requests = chunk_web_search_requests
                    chunk_google_maps_grounding_requests: int | None = getattr(
                        usage_chunk_dict["prompt_tokens_details"],
                        "google_maps_grounding_requests",
                        None,
                    )
                    if chunk_google_maps_grounding_requests is not None:
                        google_maps_grounding_requests = chunk_google_maps_grounding_requests

                prompt_tokens_details = usage_chunk_dict["prompt_tokens_details"] or prompt_tokens_details

                cache_creation_token_details = capture_cache_creation_token_details(
                    prompt_tokens_details, cache_creation_token_details
                )

                if usage_chunk_dict["cost"] is not None:
                    cost = usage_chunk_dict["cost"]

        prompt_tokens_details = attach_cache_creation_token_details(prompt_tokens_details, cache_creation_token_details)

        recovered_completion_tokens: Final = self._reset_anthropic_cursor_completion_tokens(
            chunks=chunks,
            completion_tokens=completion_tokens,
            completion_usage_updates=completion_usage_updates,
        )
        cursor_was_reset: Final = recovered_completion_tokens != completion_tokens

        return UsagePerChunk(
            prompt_tokens=prompt_tokens,
            completion_tokens=recovered_completion_tokens,
            cache_creation_input_tokens=cache_creation_input_tokens,
            cache_read_input_tokens=cache_read_input_tokens,
            server_tool_use=server_tool_use,
            web_search_requests=web_search_requests,
            google_maps_grounding_requests=google_maps_grounding_requests,
            completion_tokens_details=None if cursor_was_reset else completion_tokens_details,
            prompt_tokens_details=prompt_tokens_details,
            cost=cost,
            inference_geo=self._last_provider_pricing_field(chunks, "inference_geo"),
            speed=self._last_provider_pricing_field(chunks, "speed"),
        )

    def _last_provider_pricing_field(
        self,
        chunks: Sequence["_UsageBearingChunk | ModelResponse"],
        field: str,
    ) -> str | None:
        """
        Last value of a provider-specific usage field that changes pricing but is not a
        declared ``Usage`` field, e.g. Anthropic's ``speed`` (fast mode multiplies
        non-cache token cost) and ``inference_geo``.
        """
        values: Final = [
            value
            for chunk in chunks
            if (usage_chunk := self._extract_usage_chunk(chunk)) is not None
            and isinstance(value := getattr(usage_chunk, field, None), str)
        ]
        return values[-1] if values else None

    @staticmethod
    def _finish_reason_of_choice(choice: object) -> str | None:
        match choice:
            case StreamingChoices(finish_reason=reason) | Choices(finish_reason=reason):
                return reason
            case {"finish_reason": str() as reason}:
                return reason
            case _:
                return None

    @staticmethod
    def _chunk_choices(chunk: "_UsageBearingChunk | ModelResponse | ModelResponseStream") -> Sequence[object]:
        if isinstance(chunk, dict):
            return chunk.get("choices", ())
        return getattr(chunk, "choices", ())

    @staticmethod
    def _saw_finish_reason(chunks: Sequence["_UsageBearingChunk | ModelResponse"]) -> bool:
        return any(
            ChunkProcessor._finish_reason_of_choice(choice) is not None
            for chunk in chunks
            for choice in ChunkProcessor._chunk_choices(chunk)
        )

    @staticmethod
    def _reset_anthropic_cursor_completion_tokens(
        chunks: Sequence["_UsageBearingChunk | ModelResponse"],
        completion_tokens: int | None,
        completion_usage_updates: int,
    ) -> int | None:
        """Reset a stale Anthropic ``message_start`` cursor placeholder to unreported.

        See the ``completion_usage_updates`` comment in
        ``_calculate_usage_per_chunk``. The accumulated value is NOT a stale
        cursor when we saw >= 2 completion-bearing usage events or any chunk
        carried a ``finish_reason`` (positive evidence ``message_delta``
        arrived). Otherwise the only completion update we ever saw was the
        Anthropic ``message_start`` cursor, a small placeholder whose magnitude
        varies per request (1 and 8 both observed live), so reset to None and let
        ``calculate_usage()``'s ``token_counter(...)`` fallback estimate from
        the actually-received text and reasoning instead. Gated on
        ``custom_llm_provider == "anthropic"`` so the heuristic (which encodes
        Anthropic's specific message_start SSE shape) does not silently affect
        other providers that legitimately report usage from a single event.
        """
        saw_non_cursor_completion: Final = completion_usage_updates >= 2 or ChunkProcessor._saw_finish_reason(chunks)
        if saw_non_cursor_completion:
            return completion_tokens

        custom_llm_provider: str | None = None
        if chunks:
            first_chunk: Final = chunks[0]
            if isinstance(first_chunk, dict):
                hp = first_chunk.get("_hidden_params")
            else:
                hp = getattr(first_chunk, "_hidden_params", None)
            if isinstance(hp, dict):
                custom_llm_provider = hp.get("custom_llm_provider")

        if custom_llm_provider == "anthropic":
            return None
        return completion_tokens

    def calculate_usage(
        self,
        chunks: Sequence["_UsageBearingChunk | ModelResponse"],
        model: str,
        completion_output: str,
        messages: Sequence | None = None,
        reasoning_tokens: int | None = None,
        count_prompt_tokens: Callable[[], int] | None = None,
    ) -> Usage:
        """
        Calculate usage for the given chunks.
        """
        returned_usage = Usage()
        # # Update usage information if needed

        calculated_usage_per_chunk: Final = self._calculate_usage_per_chunk(chunks=chunks)
        prompt_tokens: Final = calculated_usage_per_chunk["prompt_tokens"]
        completion_tokens: Final = calculated_usage_per_chunk["completion_tokens"]
        ## anthropic prompt caching information ##
        cache_creation_input_tokens: Final[int | None] = calculated_usage_per_chunk["cache_creation_input_tokens"]
        cache_read_input_tokens: Final[int | None] = calculated_usage_per_chunk["cache_read_input_tokens"]

        server_tool_use: Final[ServerToolUse | None] = calculated_usage_per_chunk["server_tool_use"]
        web_search_requests: Final[int | None] = calculated_usage_per_chunk["web_search_requests"]
        google_maps_grounding_requests: Final[int | None] = calculated_usage_per_chunk["google_maps_grounding_requests"]
        completion_tokens_details: Final[CompletionTokensDetails | None] = calculated_usage_per_chunk[
            "completion_tokens_details"
        ]
        prompt_tokens_details: PromptTokensDetailsWrapper | None = calculated_usage_per_chunk["prompt_tokens_details"]
        cost: Final[float | None] = calculated_usage_per_chunk["cost"]

        try:
            returned_usage.prompt_tokens = (
                prompt_tokens
                if prompt_tokens is not None
                else (count_prompt_tokens() if count_prompt_tokens else token_counter(model=model, messages=messages))
            )
        except Exception:  # don't allow this failing to block a complete streaming response from being returned
            print_verbose("token_counter failed, assuming prompt tokens is 0")
            returned_usage.prompt_tokens = 0
        returned_usage.completion_tokens = (
            completion_tokens
            if completion_tokens is not None
            else (
                token_counter(
                    model=model,
                    text=completion_output,
                    count_response_tokens=True,  # count_response_tokens is a Flag to tell token counter this is a response, No need to add extra tokens we do for input messages
                )
                + (reasoning_tokens or 0)
            )
        )
        returned_usage.total_tokens = returned_usage.prompt_tokens + returned_usage.completion_tokens

        if cache_creation_input_tokens is not None:
            returned_usage._cache_creation_input_tokens = cache_creation_input_tokens
            setattr(
                returned_usage,
                "cache_creation_input_tokens",
                cache_creation_input_tokens,
            )  # for anthropic
        if cache_read_input_tokens is not None:
            returned_usage._cache_read_input_tokens = cache_read_input_tokens
            setattr(returned_usage, "cache_read_input_tokens", cache_read_input_tokens)  # for anthropic
        if completion_tokens_details is not None:
            if isinstance(completion_tokens_details, CompletionTokensDetails):
                returned_usage.completion_tokens_details = CompletionTokensDetailsWrapper.model_validate(
                    completion_tokens_details.model_dump()
                )
            else:
                returned_usage.completion_tokens_details = completion_tokens_details

        if reasoning_tokens is not None:
            capped_reasoning_tokens: Final = min(max(0, reasoning_tokens), returned_usage.completion_tokens)
            if returned_usage.completion_tokens_details is None:
                returned_usage.completion_tokens_details = CompletionTokensDetailsWrapper(
                    reasoning_tokens=capped_reasoning_tokens,
                    text_tokens=returned_usage.completion_tokens - capped_reasoning_tokens,
                )
            elif (
                returned_usage.completion_tokens_details is not None
                and returned_usage.completion_tokens_details.reasoning_tokens is None
            ):
                returned_usage.completion_tokens_details.reasoning_tokens = capped_reasoning_tokens
                if returned_usage.completion_tokens_details.text_tokens is None:
                    returned_usage.completion_tokens_details.text_tokens = (
                        returned_usage.completion_tokens - capped_reasoning_tokens
                    )
        if prompt_tokens_details is not None:
            returned_usage.prompt_tokens_details = prompt_tokens_details

        if server_tool_use is not None:
            returned_usage.server_tool_use = server_tool_use
        returned_usage.prompt_tokens_details = apply_grounding_request_counts(
            returned_usage.prompt_tokens_details,
            web_search_requests,
            google_maps_grounding_requests,
        )

        if cost is not None:
            setattr(returned_usage, "cost", cost)

        # Return a new usage object with the new values

        provider_pricing_fields: Final = {
            field: value
            for field, value in (
                ("inference_geo", calculated_usage_per_chunk["inference_geo"]),
                ("speed", calculated_usage_per_chunk["speed"]),
            )
            if value is not None
        }

        returned_usage = Usage(**returned_usage.model_dump(), **provider_pricing_fields)

        return returned_usage


def concatenate_base64_list(base64_strings: list[str]) -> str:
    """
    Concatenates a list of base64-encoded strings.

    Args:
        base64_strings (List[str]): A list of base64 strings to concatenate.

    Returns:
        str: The concatenated result as a base64-encoded string.
    """
    # Decode each base64 string and collect the resulting bytes
    combined_bytes: Final = b"".join(base64.b64decode(b64_str) for b64_str in base64_strings)

    # Encode the concatenated bytes back to base64
    return base64.b64encode(combined_bytes).decode("utf-8")
