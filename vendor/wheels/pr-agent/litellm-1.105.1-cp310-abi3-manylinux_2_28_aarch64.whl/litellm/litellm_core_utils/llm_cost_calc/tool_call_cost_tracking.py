"""
Helper utilities for tracking the cost of built-in tools.
"""

from collections.abc import Mapping
from typing import Final, Literal

from pydantic import ValidationError

import litellm
from litellm.constants import OPENAI_FILE_SEARCH_COST_PER_1K_CALLS
from litellm.litellm_core_utils.llm_cost_calc.utils import (
    get_web_search_requests_from_usage,
)
from litellm.types.llms.openai import (
    FileSearchTool,
    ResponsesAPIResponse,
    ResponsesToolUsage,
    WebSearchOptions,
)
from litellm.types.utils import (
    ChatCompletionAnnotation,
    Message,
    ModelInfo,
    ModelResponse,
    SearchContextCostPerQuery,
    ServerToolUse,
    StandardBuiltInToolsParams,
    Usage,
)


def _output_item_type(output_item: object) -> str | None:
    item_type: Final = output_item.get("type") if isinstance(output_item, dict) else getattr(output_item, "type", None)
    return item_type if isinstance(item_type, str) else None


def _reported_web_search_requests(response_object: ResponsesAPIResponse) -> int | None:
    tool_usage: Final = getattr(response_object, "tool_usage", None)
    if tool_usage is None:
        return None
    try:
        web_search: Final = ResponsesToolUsage.model_validate(tool_usage).web_search
    except ValidationError:
        return None
    return None if web_search is None else web_search.num_requests


def _usage_reports_server_side_web_search_calls(usage: Usage) -> bool:
    details: Final = getattr(usage, "server_side_tool_usage_details", None)
    if not isinstance(details, Mapping):
        return False
    calls: Final = details.get("web_search_calls")
    return isinstance(calls, int) and calls > 0


class StandardBuiltInToolCostTracking:
    """
    Helper class for tracking the cost of built-in tools

    Example: Web Search
    """

    @staticmethod
    def get_cost_for_built_in_tools(
        model: str,
        response_object: object,
        usage: Usage | None = None,
        custom_llm_provider: str | None = None,
        standard_built_in_tools_params: StandardBuiltInToolsParams | None = None,
    ) -> float:
        """
        Get the cost of using built-in tools.

        Supported tools:
        - Web Search
        - File Search
        - Vector Store (Azure)
        - Computer Use (Azure)
        - Code Interpreter (Azure)
        """
        standard_built_in_tools_params = standard_built_in_tools_params or {}

        google_maps_grounding_cost: Final = StandardBuiltInToolCostTracking._handle_google_maps_grounding_cost(
            model=model,
            custom_llm_provider=custom_llm_provider,
            usage=usage,
        )

        # Handle web search
        if StandardBuiltInToolCostTracking.response_object_includes_web_search_call(
            response_object=response_object, usage=usage
        ):
            return google_maps_grounding_cost + StandardBuiltInToolCostTracking._handle_web_search_cost(
                model=model,
                custom_llm_provider=custom_llm_provider,
                usage=usage,
                standard_built_in_tools_params=standard_built_in_tools_params,
                response_object=response_object,
            )

        # Handle file search
        if StandardBuiltInToolCostTracking.response_object_includes_file_search_call(response_object=response_object):
            return google_maps_grounding_cost + StandardBuiltInToolCostTracking._handle_file_search_cost(
                model=model,
                custom_llm_provider=custom_llm_provider,
                standard_built_in_tools_params=standard_built_in_tools_params,
            )

        # Handle Azure assistant features
        return google_maps_grounding_cost + StandardBuiltInToolCostTracking._handle_azure_assistant_costs(
            model=model,
            custom_llm_provider=custom_llm_provider,
            standard_built_in_tools_params=standard_built_in_tools_params,
        )

    @staticmethod
    def _resolve_model_info(model: str, custom_llm_provider: str | None) -> tuple[ModelInfo | None, str | None]:
        direct: Final = StandardBuiltInToolCostTracking._safe_get_model_info(
            model=model, custom_llm_provider=custom_llm_provider
        )
        if direct is not None:
            return direct, custom_llm_provider or direct["litellm_provider"]
        if "/" not in model:
            return None, custom_llm_provider
        by_prefix: Final = StandardBuiltInToolCostTracking._safe_get_model_info(model=model)
        if by_prefix is None:
            return None, custom_llm_provider
        return by_prefix, by_prefix["litellm_provider"]

    @staticmethod
    def _handle_google_maps_grounding_cost(
        model: str,
        custom_llm_provider: str | None,
        usage: Usage | None,
    ) -> float:
        from litellm.llms import get_cost_for_google_maps_grounding_request
        from litellm.llms.gemini.cost_calculator import google_maps_grounding_requests

        if usage is None or google_maps_grounding_requests(usage) is None:
            return 0.0
        model_info, resolved_provider = StandardBuiltInToolCostTracking._resolve_model_info(
            model=model, custom_llm_provider=custom_llm_provider
        )
        if model_info is None or resolved_provider is None:
            return 0.0
        return (
            get_cost_for_google_maps_grounding_request(
                custom_llm_provider=resolved_provider, usage=usage, model_info=model_info
            )
            or 0.0
        )

    @staticmethod
    def _handle_web_search_cost(
        model: str,
        custom_llm_provider: str | None,
        usage: Usage | None,
        standard_built_in_tools_params: StandardBuiltInToolsParams,
        response_object: object = None,
    ) -> float:
        """Handle web search cost calculation."""
        from litellm.llms import get_cost_for_web_search_request

        # A provider-prefixed model (e.g. gemini/gemini-3.1-flash-lite) may not map under the
        # request's custom_llm_provider. _resolve_model_info re-resolves from the prefix and adopts
        # that provider so the cost is routed and priced with the model_info that was actually
        # resolved, instead of feeding a re-resolved model into the original provider's calculator.
        model_info, resolved_provider = StandardBuiltInToolCostTracking._resolve_model_info(
            model=model, custom_llm_provider=custom_llm_provider
        )

        resolved_usage: Final = StandardBuiltInToolCostTracking._usage_with_anthropic_web_search(
            usage=usage, response_object=response_object
        )

        if model_info is not None and resolved_usage is not None and resolved_provider is not None:
            result: Final = get_cost_for_web_search_request(
                custom_llm_provider=resolved_provider,
                usage=resolved_usage,
                model_info=model_info,
            )
            if result is not None:
                return result

        per_call_cost = StandardBuiltInToolCostTracking.get_cost_for_web_search(
            web_search_options=standard_built_in_tools_params.get("web_search_options", None),
            model_info=model_info,
        )
        return per_call_cost * StandardBuiltInToolCostTracking._count_web_search_calls(response_object)

    @staticmethod
    def _count_web_search_calls(response_object: object) -> int:
        """
        Number of web searches to bill for on the per-call pricing path.

        Providers that report a request count in usage (gemini, anthropic, xai, vertex) are handled by
        get_cost_for_web_search_request and never reach here. This path prices per call, so it must count
        the web_search_call items, unless the response reports the billable count itself
        (Bedrock's tool_usage.web_search.num_requests, which excludes open_page fetches). Chat-completions
        responses only expose url_citation annotations with no count, so they floor to a single billable search.
        """
        if not isinstance(response_object, ResponsesAPIResponse):
            return 1
        reported: Final = _reported_web_search_requests(response_object)
        if reported is not None:
            return reported
        count: Final = sum(
            1 for output_item in response_object.output if _output_item_type(output_item) == "web_search_call"
        )
        return max(count, 1)

    @staticmethod
    def _handle_file_search_cost(
        model: str,
        custom_llm_provider: str | None,
        standard_built_in_tools_params: StandardBuiltInToolsParams,
    ) -> float:
        """Handle file search cost calculation."""
        model_info: Final = StandardBuiltInToolCostTracking._safe_get_model_info(
            model=model, custom_llm_provider=custom_llm_provider
        )
        file_search_usage: Final[FileSearchTool | None] = standard_built_in_tools_params.get("file_search") or None

        # Convert model_info to dict and extract usage parameters
        model_info_dict: Final = dict(model_info) if model_info is not None else None
        storage_gb, days = StandardBuiltInToolCostTracking._extract_file_search_params(file_search_usage)

        return StandardBuiltInToolCostTracking.get_cost_for_file_search(
            file_search=file_search_usage,
            provider=custom_llm_provider,
            model_info=model_info_dict,
            storage_gb=storage_gb,
            days=days,
        )

    @staticmethod
    def _handle_azure_assistant_costs(
        model: str,
        custom_llm_provider: str | None,
        standard_built_in_tools_params: StandardBuiltInToolsParams,
    ) -> float:
        """Handle Azure assistant features cost calculation."""
        if custom_llm_provider != "azure":
            return 0.0

        model_info: Final = StandardBuiltInToolCostTracking._safe_get_model_info(
            model=model, custom_llm_provider=custom_llm_provider
        )

        total_cost = 0.0
        total_cost += StandardBuiltInToolCostTracking._get_vector_store_cost(
            model_info, custom_llm_provider, standard_built_in_tools_params
        )
        total_cost += StandardBuiltInToolCostTracking._get_computer_use_cost(
            model_info, custom_llm_provider, standard_built_in_tools_params
        )
        total_cost += StandardBuiltInToolCostTracking._get_code_interpreter_cost(
            model_info, custom_llm_provider, standard_built_in_tools_params
        )

        return total_cost

    @staticmethod
    def _extract_file_search_params(
        file_search_usage: object,
    ) -> tuple[float | None, float | None]:
        """Extract and convert file search parameters safely."""
        storage_gb = None
        days = None

        if isinstance(file_search_usage, dict):
            storage_gb_val: Final = file_search_usage.get("storage_gb")
            days_val: Final = file_search_usage.get("days")

            if storage_gb_val is not None:
                try:
                    storage_gb = float(storage_gb_val)
                except (TypeError, ValueError):
                    storage_gb = None

            if days_val is not None:
                try:
                    days = float(days_val)
                except (TypeError, ValueError):
                    days = None

        return storage_gb, days

    @staticmethod
    def _get_vector_store_cost(
        model_info: ModelInfo | None,
        custom_llm_provider: str | None,
        standard_built_in_tools_params: StandardBuiltInToolsParams,
    ) -> float:
        """Calculate vector store cost."""
        vector_store_usage: Final = standard_built_in_tools_params.get("vector_store_usage", None)
        if not vector_store_usage:
            return 0.0

        model_info_dict: Final = dict(model_info) if model_info is not None else None
        vector_store_dict: Final = vector_store_usage if isinstance(vector_store_usage, dict) else {}

        return StandardBuiltInToolCostTracking.get_cost_for_vector_store(
            vector_store_usage=vector_store_dict,
            provider=custom_llm_provider,
            model_info=model_info_dict,
        )

    @staticmethod
    def _get_computer_use_cost(
        model_info: ModelInfo | None,
        custom_llm_provider: str | None,
        standard_built_in_tools_params: StandardBuiltInToolsParams,
    ) -> float:
        """Calculate computer use cost."""
        computer_use_usage: Final = standard_built_in_tools_params.get("computer_use_usage", {})
        if not computer_use_usage:
            return 0.0

        model_info_dict: Final = dict(model_info) if model_info is not None else None
        (
            input_tokens,
            output_tokens,
        ) = StandardBuiltInToolCostTracking._extract_token_counts(computer_use_usage)

        return StandardBuiltInToolCostTracking.get_cost_for_computer_use(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            provider=custom_llm_provider,
            model_info=model_info_dict,
        )

    @staticmethod
    def _get_code_interpreter_cost(
        model_info: ModelInfo | None,
        custom_llm_provider: str | None,
        standard_built_in_tools_params: StandardBuiltInToolsParams,
    ) -> float:
        """Calculate code interpreter cost."""
        code_interpreter_sessions: Final = standard_built_in_tools_params.get("code_interpreter_sessions", None)
        if not code_interpreter_sessions:
            return 0.0

        model_info_dict: Final = dict(model_info) if model_info is not None else None
        sessions: Final = StandardBuiltInToolCostTracking._safe_convert_to_int(code_interpreter_sessions)

        return StandardBuiltInToolCostTracking.get_cost_for_code_interpreter(
            sessions=sessions,
            provider=custom_llm_provider,
            model_info=model_info_dict,
        )

    @staticmethod
    def _extract_token_counts(
        computer_use_usage: object,
    ) -> tuple[int | None, int | None]:
        """Extract and convert token counts safely."""
        input_tokens = None
        output_tokens = None

        if isinstance(computer_use_usage, dict):
            input_tokens_val: Final = computer_use_usage.get("input_tokens")
            output_tokens_val: Final = computer_use_usage.get("output_tokens")

            input_tokens = StandardBuiltInToolCostTracking._safe_convert_to_int(input_tokens_val)
            output_tokens = StandardBuiltInToolCostTracking._safe_convert_to_int(output_tokens_val)

        return input_tokens, output_tokens

    @staticmethod
    def _safe_convert_to_int(value: object) -> int | None:
        """Safely convert a value to int."""
        if isinstance(value, (int, float, str)):
            try:
                return int(value)
            except (TypeError, ValueError):
                return None
        return None

    @staticmethod
    def _usage_with_anthropic_web_search(usage: Usage | None, response_object: object) -> Usage | None:
        """Return a Usage carrying server_tool_use.web_search_requests sourced from a
        raw Anthropic /v1/messages response dict when the reconstructed Usage dropped
        it (or was never supplied). The original Usage is returned unchanged when it
        already exposes the field or the response is not an Anthropic dict."""
        from litellm.llms.anthropic.cost_calculation import (
            get_anthropic_web_search_requests_from_response,
        )

        if usage is not None and (get_web_search_requests_from_usage(usage) is not None):
            return usage
        web_search_requests: Final = get_anthropic_web_search_requests_from_response(response_object)
        if web_search_requests is None:
            return usage
        server_tool_use: Final = ServerToolUse(web_search_requests=web_search_requests)
        if usage is None:
            return Usage(server_tool_use=server_tool_use)
        return usage.model_copy(update={"server_tool_use": server_tool_use})

    @staticmethod
    def response_object_includes_web_search_call(response_object: object, usage: Usage | None = None) -> bool:
        """
        Check if the response object includes a web search call.

        This covers:
        - Chat Completion Response (ModelResponse)
        - ResponsesAPIResponse (streaming + non-streaming)
        - Anthropic /v1/messages raw response dict
        """
        from litellm.llms.anthropic.cost_calculation import (
            get_anthropic_web_search_requests_from_response,
        )
        from litellm.types.utils import PromptTokensDetailsWrapper

        if get_anthropic_web_search_requests_from_response(response_object) is not None:
            return True

        if isinstance(response_object, ModelResponse):
            # chat completions only include url_citation annotations when a web search call is made
            has_url_citations: Final = StandardBuiltInToolCostTracking.response_includes_annotation_type(
                response_object=response_object, annotation_type="url_citation"
            )
            if has_url_citations:
                return True
            if usage is not None:
                # Vertex AI Gemini uses usage.prompt_tokens_details.web_search_requests
                if (
                    hasattr(usage, "prompt_tokens_details")
                    and usage.prompt_tokens_details is not None
                    and isinstance(usage.prompt_tokens_details, PromptTokensDetailsWrapper)
                    and hasattr(usage.prompt_tokens_details, "web_search_requests")
                    and usage.prompt_tokens_details.web_search_requests is not None
                ):
                    return True
                # Anthropic Claude (direct API and Vertex AI) uses server_tool_use.web_search_requests.
                # Without this check, Claude ModelResponse always falls through to return False
                # and _handle_web_search_cost() is never called.
                if get_web_search_requests_from_usage(usage) is not None:
                    return True
                # xAI reports usage.server_side_tool_usage_details.web_search_calls; a searched
                # answer with no url_citation annotations has no other chat-path signal
                if _usage_reports_server_side_web_search_calls(usage):
                    return True
            return False
        elif isinstance(response_object, ResponsesAPIResponse):
            # response api explicitly includes web_search_call in the output
            return StandardBuiltInToolCostTracking.response_includes_output_type(
                response_object=response_object, output_type="web_search_call"
            )
        elif usage is not None:
            if get_web_search_requests_from_usage(usage) is not None or (
                hasattr(usage, "prompt_tokens_details")
                and usage.prompt_tokens_details is not None
                and isinstance(usage.prompt_tokens_details, PromptTokensDetailsWrapper)
                and hasattr(usage.prompt_tokens_details, "web_search_requests")
                and usage.prompt_tokens_details.web_search_requests is not None
            ):
                return True
            if _usage_reports_server_side_web_search_calls(usage):
                return True

        return False

    @staticmethod
    def response_object_includes_file_search_call(
        response_object: object,
    ) -> bool:
        """
        Check if the response object includes a file search call.

        This covers:
            - Chat Completion Response (ModelResponse)
            - ResponsesAPIResponse (streaming + non-streaming)
        """
        if isinstance(response_object, ModelResponse):
            # chat completions only include file_citation annotations when a file search call is made
            return StandardBuiltInToolCostTracking.response_includes_annotation_type(
                response_object=response_object, annotation_type="file_citation"
            )
        elif isinstance(response_object, ResponsesAPIResponse):
            # response api explicitly includes file_search_call in the output
            return StandardBuiltInToolCostTracking.response_includes_output_type(
                response_object=response_object, output_type="file_search_call"
            )
        return False

    @staticmethod
    def response_includes_annotation_type(
        response_object: ModelResponse,
        annotation_type: Literal["url_citation", "file_citation"],
    ) -> bool:
        if isinstance(response_object, ModelResponse):
            for choice in response_object.choices:
                message: Message | None = getattr(choice, "message", None)
                if message is None:
                    continue
                annotations: list[ChatCompletionAnnotation] | None = getattr(message, "annotations", None)
                if annotations:
                    for annotation in annotations:
                        if annotation.get("type", None) == annotation_type:
                            return True
        return False

    @staticmethod
    def response_includes_output_type(
        response_object: ResponsesAPIResponse,
        output_type: Literal["web_search_call", "file_search_call"],
    ) -> bool:
        """
        Check if the ResponsesAPIResponse includes one of the specified output types.

        This is used for cost tracking of built-in tools.

        Args:
            response_object: The ResponsesAPIResponse object to check.
            output_type: The type of output to check for.

        Returns:
            True if the ResponsesAPIResponse includes one of the specified output types, False otherwise.
        """
        return any(_output_item_type(output_item) == output_type for output_item in response_object.output)

    @staticmethod
    def _safe_get_model_info(model: str, custom_llm_provider: str | None = None) -> ModelInfo | None:
        try:
            return litellm.get_model_info(model=model, custom_llm_provider=custom_llm_provider)
        except Exception:
            return None

    @staticmethod
    def get_cost_for_web_search(
        web_search_options: WebSearchOptions | None = None,
        model_info: ModelInfo | None = None,
    ) -> float:
        """
        If request includes `web_search_options`, calculate the cost of the web search.
        """
        web_search_options = web_search_options or {}
        if model_info is None:
            return 0.0

        search_context_raw: Final = model_info.get("search_context_cost_per_query")
        search_context_pricing: Final[SearchContextCostPerQuery] = search_context_raw or SearchContextCostPerQuery()
        if web_search_options.get("search_context_size", None) == "low":
            return search_context_pricing.get("search_context_size_low", 0.0)
        elif web_search_options.get("search_context_size", None) == "medium":
            return search_context_pricing.get("search_context_size_medium", 0.0)
        elif web_search_options.get("search_context_size", None) == "high":
            return search_context_pricing.get("search_context_size_high", 0.0)
        return StandardBuiltInToolCostTracking.get_default_cost_for_web_search(model_info)

    @staticmethod
    def get_default_cost_for_web_search(
        model_info: ModelInfo | None = None,
    ) -> float:
        """
        If no web search options are provided, use the `search_context_size_medium` pricing.

        https://platform.openai.com/docs/pricing#web-search
        """
        if model_info is None:
            return 0.0
        search_context_raw: Final = model_info.get("search_context_cost_per_query")
        search_context_pricing: Final[SearchContextCostPerQuery] = search_context_raw or SearchContextCostPerQuery()
        return search_context_pricing.get("search_context_size_medium", 0.0)

    @staticmethod
    def get_cost_for_file_search(
        file_search: FileSearchTool | None = None,
        provider: str | None = None,
        model_info: dict | None = None,
        storage_gb: float | None = None,
        days: float | None = None,
    ) -> float:
        """ "
        OpenAI: $2.50/1k calls
        Azure: $0.1 USD per 1 GB/Day (storage-based pricing)

        Doc: https://platform.openai.com/docs/pricing#built-in-tools
        """
        if file_search is None:
            return 0.0

        # Check if model-specific pricing is available
        if model_info and "file_search_cost_per_gb_per_day" in model_info and provider == "azure":
            if storage_gb and days:
                return storage_gb * days * model_info["file_search_cost_per_gb_per_day"]
        elif model_info and "file_search_cost_per_1k_calls" in model_info:
            return model_info["file_search_cost_per_1k_calls"]

        # Azure has storage-based pricing for file search
        if provider == "azure":
            from litellm.constants import AZURE_FILE_SEARCH_COST_PER_GB_PER_DAY

            if storage_gb and days:
                return storage_gb * days * AZURE_FILE_SEARCH_COST_PER_GB_PER_DAY
            # Default to 0 if no storage info provided
            return 0.0

        # Default to OpenAI pricing (per-call based)
        return OPENAI_FILE_SEARCH_COST_PER_1K_CALLS

    @staticmethod
    def get_cost_for_vector_store(
        vector_store_usage: dict | None = None,
        provider: str | None = None,
        model_info: dict | None = None,
    ) -> float:
        """
        Calculate cost for vector store usage.

        Azure charges based on storage size and duration.
        """
        if vector_store_usage is None:
            return 0.0

        storage_gb: Final = vector_store_usage.get("storage_gb", 0.0)
        days: Final = vector_store_usage.get("days", 0.0)

        # Check if model-specific pricing is available
        if model_info and "vector_store_cost_per_gb_per_day" in model_info:
            return storage_gb * days * model_info["vector_store_cost_per_gb_per_day"]

        # Azure has different pricing structure for vector store
        if provider == "azure":
            from litellm.constants import AZURE_VECTOR_STORE_COST_PER_GB_PER_DAY

            return storage_gb * days * AZURE_VECTOR_STORE_COST_PER_GB_PER_DAY

        # OpenAI doesn't charge separately for vector store (included in embeddings)
        return 0.0

    @staticmethod
    def get_cost_for_computer_use(
        input_tokens: int | None = None,
        output_tokens: int | None = None,
        provider: str | None = None,
        model_info: dict | None = None,
    ) -> float:
        """
        Calculate cost for computer use feature.

        Azure: $0.003 USD per 1K input tokens, $0.012 USD per 1K output tokens
        """
        if provider == "azure" and (input_tokens or output_tokens):
            # Check if model-specific pricing is available
            if model_info:
                input_cost: Final = model_info.get("computer_use_input_cost_per_1k_tokens", 0.0)
                output_cost: Final = model_info.get("computer_use_output_cost_per_1k_tokens", 0.0)
                if input_cost or output_cost:
                    total_cost = 0.0
                    if input_tokens:
                        total_cost += (input_tokens / 1000.0) * input_cost
                    if output_tokens:
                        total_cost += (output_tokens / 1000.0) * output_cost
                    return total_cost

            # Azure default pricing
            from litellm.constants import (
                AZURE_COMPUTER_USE_INPUT_COST_PER_1K_TOKENS,
                AZURE_COMPUTER_USE_OUTPUT_COST_PER_1K_TOKENS,
            )

            total_cost = 0.0
            if input_tokens:
                total_cost += (input_tokens / 1000.0) * AZURE_COMPUTER_USE_INPUT_COST_PER_1K_TOKENS
            if output_tokens:
                total_cost += (output_tokens / 1000.0) * AZURE_COMPUTER_USE_OUTPUT_COST_PER_1K_TOKENS
            return total_cost

        # OpenAI doesn't charge separately for computer use yet
        return 0.0

    @staticmethod
    def _get_code_interpreter_cost_from_model_map(
        provider: str,
    ) -> float | None:
        """
        Get code interpreter cost per session from model cost map.
        """
        import litellm

        try:
            container_model: Final = f"{provider}/container"
            model_info: Final = litellm.get_model_info(model=container_model, custom_llm_provider=provider)
            model_key = model_info.get("key") if isinstance(model_info, dict) else getattr(model_info, "key", None)

            if model_key and model_key in litellm.model_cost:
                return litellm.model_cost[model_key].get("code_interpreter_cost_per_session")

        except Exception:
            pass

        return None

    @staticmethod
    def get_cost_for_code_interpreter(
        sessions: int | None = None,
        provider: str | None = None,
        model_info: dict | None = None,
    ) -> float:
        """
        Calculate cost for code interpreter feature.

        Azure: $0.03 USD per session (from model cost map)
        OpenAI: $0.03 USD per session (from model cost map)
        """
        if sessions is None or sessions == 0:
            return 0.0

        # Check if model-specific pricing is available
        if model_info and "code_interpreter_cost_per_session" in model_info:
            return sessions * model_info["code_interpreter_cost_per_session"]

        # Try to get cost from model cost map for any provider
        if provider:
            cost_per_session: Final = StandardBuiltInToolCostTracking._get_code_interpreter_cost_from_model_map(
                provider=provider
            )
            if cost_per_session is not None:
                return sessions * cost_per_session

        return 0.0

    @staticmethod
    def chat_completion_response_includes_annotations(
        response_object: ModelResponse,
    ) -> bool:
        for _choice in response_object.choices:
            message: Message | None = getattr(_choice, "message", None)
            if (
                message is not None
                and hasattr(message, "annotations")
                and message.annotations is not None
                and len(message.annotations) > 0
            ):
                return True
        return False

    @staticmethod
    def _get_web_search_options(kwargs: dict) -> WebSearchOptions | None:
        if "web_search_options" in kwargs:
            return WebSearchOptions(**kwargs.get("web_search_options", {}))

        tools: Final = StandardBuiltInToolCostTracking._get_tools_from_kwargs(
            kwargs=kwargs, tool_type="web_search_preview"
        ) or StandardBuiltInToolCostTracking._get_tools_from_kwargs(kwargs=kwargs, tool_type="web_search")
        if tools:
            # Look for web search tool in the tools array
            for tool in tools:
                if isinstance(tool, dict):
                    if StandardBuiltInToolCostTracking._is_web_search_tool_call(tool):
                        return WebSearchOptions(**tool)
        return None

    @staticmethod
    def _get_tools_from_kwargs(kwargs: dict, tool_type: str) -> list[dict] | None:
        if "tools" in kwargs:
            return kwargs.get("tools", [])
        return None

    @staticmethod
    def _get_file_search_tool_call(kwargs: dict) -> FileSearchTool | None:
        tools: Final = StandardBuiltInToolCostTracking._get_tools_from_kwargs(kwargs, "file_search")
        if tools:
            for tool in tools:
                if isinstance(tool, dict):
                    if StandardBuiltInToolCostTracking._is_file_search_tool_call(tool):
                        return FileSearchTool(**tool)
        return None

    @staticmethod
    def _is_web_search_tool_call(tool: dict) -> bool:
        if tool.get("type", None) == "web_search_preview":
            return True
        if tool.get("type", None) == "web_search":
            return True
        if "search_context_size" in tool:
            return True
        return False

    @staticmethod
    def _is_file_search_tool_call(tool: dict) -> bool:
        if tool.get("type", None) == "file_search":
            return True
        return False
